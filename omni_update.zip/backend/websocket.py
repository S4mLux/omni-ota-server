from fastapi import WebSocket, WebSocketDisconnect
from typing import List, Dict, Any
import json

class ConnectionManager:
    def __init__(self):
        # active_connections maps staff_id or session to WebSocket
        # For simplicity, we'll broadcast to all connected staff for now
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        print(f"[WS] New connection. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            print(f"[WS] Connection closed. Total: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        """Sends a JSON message to all connected clients."""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception as e:
                print(f"[WS] Broadcast error: {e}")
                disconnected.append(connection)
        
        for conn in disconnected:
            self.disconnect(conn)

manager = ConnectionManager()
