"""
BCV Driver — Obtiene la tasa oficial del Banco Central de Venezuela
Scraping robusto de https://www.bcv.org.ve/ con múltiples estrategias
"""
import httpx
import re
from bs4 import BeautifulSoup
from datetime import datetime
from typing import Optional
import asyncio


class BCVDriver:

    BCV_URL = "https://www.bcv.org.ve/"
    TIMEOUT = 15.0
    # Tasa de emergencia actualizada — se usa solo si el scraping falla
    EMERGENCY_RATE = 478.58

    @staticmethod
    async def fetch_rate() -> Optional[float]:
        """
        Obtiene la tasa USD actual desde el BCV.
        Retorna el valor en Bs/USD o None si falla.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, BCVDriver._fetch_sync)

    @staticmethod
    def _clean_number(raw: str) -> Optional[float]:
        """Convierte '478,58110000' o '478.58' a float correctamente."""
        raw = raw.strip().replace("\xa0", "").replace(" ", "")
        # Formato venezolano: punto como separador de miles, coma como decimal
        # Ej: 478,58110000  →  478.58
        if "," in raw and "." not in raw:
            raw = raw.replace(",", ".")
        elif "," in raw and "." in raw:
            # Tiene ambos: 1.234,56 → 1234.56
            raw = raw.replace(".", "").replace(",", ".")
        try:
            val = float(raw)
            # Sanity check: la tasa BCV debe ser > 1 Bs/$ en Venezuela
            if val > 1:
                return val
        except (ValueError, TypeError):
            pass
        return None

    @staticmethod
    def _fetch_sync() -> Optional[float]:
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                              "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "es-VE,es;q=0.9,en;q=0.8",
                "Cache-Control": "no-cache",
            }
            # verify=False: El BCV usa un certificado raíz que a veces no está
            # en el store de Python/Windows. Seguro para un site gubernamental conocido.
            with httpx.Client(
                timeout=BCVDriver.TIMEOUT,
                headers=headers,
                follow_redirects=True,
                verify=False          # ← bypass SSL para BCV
            ) as client:
                response = client.get(BCVDriver.BCV_URL)
                if response.status_code != 200:
                    print(f"[BCV] HTTP {response.status_code}")
                    return None

            html = response.text
            soup = BeautifulSoup(html, "html.parser")

            # ── Estrategia 1: regex agresivo sobre el HTML completo ─────────
            # Busca patrones tipo 482,75860000 cerca de "USD"
            patterns = [
                r"USD[\s\S]{0,50}(\d{2,3}[.,]\d{2,10})",
                r"USD[\s\S]{0,50}(\d{3}[.,]\d{5,10})",
            ]
            for pattern in patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    val = BCVDriver._clean_number(match.group(1))
                    if val and val > 50:  # La tasa venezolana es > 50 Bs/$
                        print(f"[BCV] Estrategia 1 (regex) OK: {val} Bs/$")
                        return val

            # ── Estrategia 2: selector clásico #dolar strong ──────────────
            dolar_div = soup.find(id="dolar")
            if dolar_div:
                strong = dolar_div.find("strong")
                if strong:
                    val = BCVDriver._clean_number(strong.get_text())
                    if val:
                        print(f"[BCV] Estrategia 2 OK: {val} Bs/$")
                        return val

            # ── Estrategia 3: selector por clase 'centrado' (BCV 2024-2025) ──
            for tag in soup.find_all(class_="centrado"):
                text = tag.get_text()
                # Busca el bloque que contiene "USD" cerca de un número grande
                if "USD" in text or "Dólar" in text or "dolar" in text.lower():
                    match = re.search(r"(\d{2,3}[.,]\d{2,8})", text)
                    if match:
                        val = BCVDriver._clean_number(match.group(1))
                        if val:
                            print(f"[BCV] Estrategia 3 OK: {val} Bs/$")
                            return val

            # ── Estrategia 4: buscar la tabla de tasas ─────────────────────
            tables = soup.find_all("table")
            for table in tables:
                rows = table.find_all("tr")
            # ── Estrategia 4: buscar la tabla de tasas ─────────────────────
            tables = soup.find_all("table")
            for table in tables:
                rows = table.find_all("tr")
                for row in rows:
                    cells = [c.get_text(strip=True) for c in row.find_all(["td", "th"])]
                    row_text = " ".join(cells)
                    if "USD" in row_text or "Dólar" in row_text:
                        for cell in cells:
                            val = BCVDriver._clean_number(cell)
                            if val and val > 10:
                                print(f"[BCV] Estrategia 4 (tabla) OK: {val} Bs/$")
                                return val

            print("[BCV] Ninguna estrategia extrajo la tasa del HTML")
            return None

        except httpx.TimeoutException:
            print("[BCV] Timeout al conectar con el BCV")
            return None
        except Exception as e:
            print(f"[BCV ERROR] {e}")
            return None

    @staticmethod
    async def get_or_fetch_rate(session) -> float:
        """
        Retorna la tasa del día desde DB, o la busca en BCV si no existe/es de otro día.
        """
        from sqlmodel import select
        from backend.models import BcvRate

        today = datetime.utcnow().date()
        existing = session.exec(
            select(BcvRate).where(BcvRate.date >= datetime(today.year, today.month, today.day))
            .order_by(BcvRate.date.desc())
        ).first()

        if existing and existing.usd_rate > 1:
            print(f"[BCV] DB hit: {existing.usd_rate} Bs/$")
            return existing.usd_rate

        # Fetch fresco desde BCV
        rate = await BCVDriver.fetch_rate()
        if rate and rate > 1:
            # Actualizar o crear registro del día
            if existing:
                existing.usd_rate = rate
                session.add(existing)
            else:
                new_rate = BcvRate(usd_rate=rate, source="BCV")
                session.add(new_rate)
            session.commit()
            return rate

        # Fallback: usar la última registrada válida
        last = session.exec(
            select(BcvRate).where(BcvRate.usd_rate > 1).order_by(BcvRate.date.desc())
        ).first()
        if last:
            print(f"[BCV] Usando última tasa válida en DB: {last.usd_rate}")
            return last.usd_rate

        # Emergencia absoluta: tasa actualizada manualmente
        print(f"[BCV] EMERGENCIA: usando {BCVDriver.EMERGENCY_RATE} Bs/$")
        return BCVDriver.EMERGENCY_RATE
