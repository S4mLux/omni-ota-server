"""
Suspension Engine — Event-Driven (asyncio-based)
=================================================
Reemplaza el polling de 60 segundos con tareas de asyncio.sleep precisas.

Flujo:
  1. Al crear una factura con cut_off_date → schedule_suspension(id, fecha)
  2. La tarea duerme exactamente hasta esa fecha/hora
  3. Al despertar → ejecuta el corte (DHCP address-list → MOROSOS / PPPoE → disable)
  4. Al pagar → cancel_suspension(id) cancela la tarea si aún no ejecutó
  5. Al reiniciar el server → recover_pending_suspensions() reprograma todo desde DB

DHCP:
  - Guarda el address-list actual del cliente en client.prev_address_list
  - Cambia address-list a "MOROSOS" en el lease del MikroTik
  - Al pagar → restore_dhcp_client usa prev_address_list para revertir
"""
import asyncio
import json
from datetime import datetime
from sqlmodel import Session, select

from backend.database import engine
from backend.models import Invoice, Client, Router, ONU, OLT, MikrotikPendingChange

# Registry de tareas activas: invoice_id → asyncio.Task
_active_tasks: dict[int, asyncio.Task] = {}


# ─────────────────────────────────────────────────────────────────
# API PÚBLICA
# ─────────────────────────────────────────────────────────────────

async def schedule_suspension(invoice_id: int, cut_off_date: datetime):
    """
    Programa la suspensión de la factura para la fecha exacta de corte.
    Si ya había una tarea registrada, la cancela primero.
    Si cut_off_date ya pasó, ejecuta inmediatamente.
    """
    # Cancelar tarea previa si existe
    if invoice_id in _active_tasks:
        old = _active_tasks[invoice_id]
        if not old.done():
            old.cancel()

    task = asyncio.create_task(_wait_and_suspend(invoice_id, cut_off_date))
    _active_tasks[invoice_id] = task
    
    # Usamos datetime.now() para comparar con la hora local del sistema
    wait_s = max(0, (cut_off_date - datetime.now()).total_seconds())
    print(f"[SUSPEND ENGINE] [PLAN] Factura #{invoice_id} programada -> corte en {wait_s:.0f}s "
          f"({cut_off_date.strftime('%d/%m/%Y %H:%M')} Local)")




async def cancel_suspension(invoice_id: int):
    """
    Cancela la tarea de suspensión (cuando la factura es pagada o anulada).
    """
    task = _active_tasks.pop(invoice_id, None)
    if task and not task.done():
        task.cancel()
        print(f"[SUSPEND ENGINE] ❌ Suspensión cancelada para factura #{invoice_id}")


async def recover_pending_suspensions():
    """
    Llamado al arrancar el servidor. Recarga todas las facturas PENDING con
    cut_off_date futuro y las reprograma. Las ya vencidas se ejecutan de inmediato.
    Garantiza que un reinicio del servidor NO pierda suspensiones pendientes.
    """
    with Session(engine) as session:
        now = datetime.now()


        future_invoices = session.exec(
            select(Invoice).where(
                Invoice.status == "PENDING",
                Invoice.deleted_at == None,
                Invoice.cut_off_date != None,
                Invoice.cut_off_date > now,
            )
        ).all()

        overdue_invoices = session.exec(
            select(Invoice).where(
                Invoice.status == "PENDING",
                Invoice.deleted_at == None,
                Invoice.cut_off_date != None,
                Invoice.cut_off_date <= now,
            )
        ).all()

    # Programar las futuras
    for inv in future_invoices:
        await schedule_suspension(inv.id, inv.cut_off_date)

    # Ejecutar inmediatamente las que ya vencieron mientras el server estaba caído
    for inv in overdue_invoices:
        asyncio.create_task(_execute_suspension(inv.id))

    print(
        f"[SUSPEND ENGINE] 🔄 Recuperación al arranque: "
        f"{len(future_invoices)} programadas, {len(overdue_invoices)} ejecutadas de inmediato."
    )


def get_active_tasks_info() -> list[dict]:
    """Devuelve info de las tareas activas (para debug/API)."""
    result = []
    for inv_id, task in _active_tasks.items():
        result.append({
            "invoice_id": inv_id,
            "done": task.done(),
            "cancelled": task.cancelled() if task.done() else False,
        })
    return result


# ─────────────────────────────────────────────────────────────────
# LÓGICA INTERNA
# ─────────────────────────────────────────────────────────────────

async def _wait_and_suspend(invoice_id: int, cut_off_date: datetime):
    """Tarea asyncio: duerme hasta cut_off_date y luego corta."""
    try:
        now = datetime.now()
        wait_seconds = (cut_off_date - now).total_seconds()


        if wait_seconds > 0:
            await asyncio.sleep(wait_seconds)

        # Verificar que la factura sigue PENDING antes de cortar
        with Session(engine) as session:
            inv = session.get(Invoice, invoice_id)
            if not inv or inv.status != "PENDING":
                print(f"[SUSPEND ENGINE] Factura #{invoice_id} ya no está PENDING — corte omitido.")
                return

        print(f"[SUSPEND ENGINE] ⚡ Hora de corte alcanzada para factura #{invoice_id}")
        await _execute_suspension(invoice_id)

    except asyncio.CancelledError:
        print(f"[SUSPEND ENGINE] ⚠️ Tarea cancelada para factura #{invoice_id} (pago recibido o factura anulada)")
    except Exception as e:
        print(f"[SUSPEND ENGINE] ❌ Error en suspensión de factura #{invoice_id}: {e}")
    finally:
        _active_tasks.pop(invoice_id, None)


async def _execute_suspension(invoice_id: int):
    """
    Ejecuta el corte real:
    - DHCP: guarda address-list actual → cambia a MOROSOS en el lease
    - PPPoE: deshabilita el secret
    - OLT: suspende la ONU si aplica
    - Cambia client.status = MOROSO
    - Si el router no responde, guarda MikrotikPendingChange
    """
    # Importaciones diferidas para evitar circular imports
    from backend.mikrotik_driver import MikroTikDriver
    from backend.olt_driver import OLTDriver
    from backend.notifications import NotificationDispatcher, EVENTS

    with Session(engine) as session:
        invoice = session.get(Invoice, invoice_id)
        if not invoice:
            print(f"[SUSPEND ENGINE] ⚠️ Factura #{invoice_id} no encontrada en DB.")
            return

        if invoice.status != "PENDING":
            print(f"[SUSPEND ENGINE] Factura #{invoice_id} ya procesada ({invoice.status}). Omitiendo.")
            return

        client = session.get(Client, invoice.client_id)
        if not client:
            print(f"[SUSPEND ENGINE] ⚠️ Cliente de factura #{invoice_id} no encontrado.")
            return

        if client.status in ("MOROSO", "SUSPENDED"):
            print(f"[SUSPEND ENGINE] {client.full_name} ya está suspendido. Omitiendo.")
            return

        print(f"[SUSPEND ENGINE] 🔪 Cortando servicio: {client.full_name} — Factura #{invoice_id}")

        router_obj = session.get(Router, client.router_id) if client.router_id else None
        success = False

        if router_obj:
            if client.connection_type == "PPPOE" and client.pppoe_user:
                # PPPoE: deshabilitar secret
                success = await MikroTikDriver.suspend_pppoe_client(router_obj, client.pppoe_user)

            elif client.connection_type == "DHCP":
                # DHCP: Capturar el address-list real del MikroTik en el momento del corte
                captured_list = await MikroTikDriver.suspend_dhcp_client(
                    router_obj,
                    client.ip_address
                )
                
                # Si es distinto de False, el router respondio y capturamos la lista
                if captured_list is not False:
                    client.prev_address_list = captured_list
                    success = True
                    print(f"[SUSPEND ENGINE] DHCP {client.ip_address}: Capturado real-time '{captured_list}' -> 'MOROSOS'")
                else:
                    success = False

        else:
            print(f"[SUSPEND ENGINE] ⚠️ {client.full_name} no tiene router asignado.")

        if not success and router_obj:
            # Router no respondió → guardar cambio pendiente para aplicar después
            pending = MikrotikPendingChange(
                router_id=client.router_id,
                action="SUSPEND_DHCP" if client.connection_type == "DHCP" else "SUSPEND_PPPOE",
                payload=json.dumps({
                    "ip": client.ip_address,
                    "user": client.pppoe_user,
                    "prev_address_list": client.prev_address_list or "",
                }),
                description=f"Corte automático (cut_off_date): {client.full_name}",
                created_by="SUSPENSION_ENGINE"
            )
            session.add(pending)
            print(f"[SUSPEND ENGINE] ⚠️ Router offline — cambio guardado como PENDIENTE.")

        # Cortar OLT/ONU si aplica
        if client.onu_id:
            onu = session.get(ONU, client.onu_id)
            if onu:
                olt = session.get(OLT, onu.olt_id)
                if olt:
                    await OLTDriver.suspend_onu(olt, onu.pon_port, onu.onu_index)
                    print(f"[SUSPEND ENGINE] OLT ONU {onu.serial_number} suspendida.")

        # Actualizar estado del cliente
        client.status = "MOROSO"
        session.add(client)

        # Notificación
        await NotificationDispatcher.dispatch(
            EVENTS["CLIENT_SUSPENDED"],
            f"⛔ Corte automático: {client.full_name} — Factura #{invoice_id} vencida.",
            session,
            client_id=client.id
        )

        session.commit()
        status_router = "✅ Aplicado" if success else "⚠️ Pendiente (router offline)"
        print(f"[SUSPEND ENGINE] ✅ {client.full_name} → MOROSO | Router: {status_router}")
