from backend.database import engine
from sqlalchemy import text

def update_db():
    with engine.connect() as conn:
        # Add brand column if not exists
        try:
            conn.execute(text("ALTER TABLE router ADD COLUMN brand VARCHAR DEFAULT 'mikrotik'"))
            conn.commit()
            print("Added 'brand' column to 'router' table.")
        except Exception as e:
            print(f"Column 'brand' might already exist: {e}")

        # Add model column if not exists
        try:
            conn.execute(text("ALTER TABLE router ADD COLUMN model VARCHAR DEFAULT 'auto'"))
            conn.commit()
            print("Added 'model' column to 'router' table.")
        except Exception as e:
            print(f"Column 'model' might already exist: {e}")

if __name__ == "__main__":
    update_db()
