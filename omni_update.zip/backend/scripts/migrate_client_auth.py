import sqlite3
import os

def migrate():
    db_path = r"c:\laragon\www\X\omni_isp.db"
    if not os.path.exists(db_path):
        print(f"Database not found at {db_path}")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    columns_to_add = [
        ("portal_user", "TEXT"),
        ("portal_password", "TEXT")
    ]

    for col_name, col_type in columns_to_add:
        try:
            print(f"Adding column {col_name} to client table...")
            cursor.execute(f"ALTER TABLE client ADD COLUMN {col_name} {col_type}")
            print(f"Column {col_name} added.")
        except sqlite3.OperationalError as e:
            if "duplicate column name" in str(e).lower():
                print(f"Column {col_name} already exists.")
            else:
                print(f"Error adding column {col_name}: {e}")

    conn.commit()
    conn.close()
    print("Migration finished.")

if __name__ == "__main__":
    migrate()
