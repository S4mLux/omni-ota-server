from sqlmodel import Session, select
from backend.database import engine
from backend.models import Staff

def init_admin():
    with Session(engine) as session:
        # Buscar si ya existe el usuario admin
        admin_staff = session.exec(select(Staff).where(Staff.dni == "admin")).first()
        
        if not admin_staff:
            print("Creating default administrator user...")
            admin_staff = Staff(
                full_name="Administrador de Sistema",
                dni="admin",
                email="admin@omni-isp.com",
                phone="0424-0000000",
                address="Sede Principal",
                position="ADMINISTRADOR",
                permissions="*",
                status="ACTIVE",
                pin="1234"
            )
            session.add(admin_staff)
            session.commit()
            print("Admin user created successfully (DNI: admin, PIN: 1234)")
        else:
            print(f"Admin user already exists: {admin_staff.full_name}")
            # Ensure it has the correct position and pin if already exists for local testing
            admin_staff.position = "ADMINISTRADOR"
            admin_staff.pin = "1234"
            session.add(admin_staff)
            session.commit()
            print("Admin user credentials reset to DNI: admin, PIN: 1234")

if __name__ == "__main__":
    init_admin()
