import asyncio
import sys
import os

# Add parent directory to path to import backend modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from backend.models import OLT
from backend.olt_driver import OLTDriver

async def verify_olt_connectivity(ip, user, password, community):
    print(f"--- OMNI NEURAL DIAGNOSTIC: OLT VSOL ---")
    print(f"Target: {ip}")
    print(f"User:   {user}")
    print(f"SNMP:   {community}")
    print("-" * 40)

    olt = OLT(
        name="VERIFICATION_NODE",
        ip_address=ip,
        username=user,
        password=password,
        snmp_community=community
    )

    # 1. Test SSH
    print("[*] Testing SSH Connectivity...")
    client = await OLTDriver.get_client(olt)
    if client:
        print("[+] SUCCESS: SSH Connection established.")
        print("[*] Testing Command: show onu unauthentication")
        output = OLTDriver.execute_command(client, "show onu unauthentication")
        if output:
            print(f"[+] SUCCESS: Command response received ({len(output)} chars).")
        client.close()
    else:
        print("[!] FAILED: SSH Connection timeout or auth error.")

    # 2. Test Telemetry (Signal) fallback
    print("\n[*] Testing Signal Extraction Fallback (CLI)...")
    signal = await OLTDriver.get_onu_signal(olt, 1, 1)
    if signal != 0.0:
        print(f"[+] SUCCESS: Extracted signal: {signal} dBm")
    else:
        print("[?] NOTE: No signal extracted (Node might not have ONU at 1/1/1).")

    print("-" * 40)
    print("[?] DIAGNOSTIC COMPLETE.")

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: python verify_olt.py <IP> <USER> <PASS> <SNMP_COMMUNITY>")
    else:
        asyncio.run(verify_olt_connectivity(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]))
