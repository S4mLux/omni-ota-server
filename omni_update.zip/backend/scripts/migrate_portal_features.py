import sqlite3
import os

def migrate():
    db_path = r"c:\laragon\www\X\omni_isp.db"
    if not os.path.exists(db_path):
        print(f"Database not found at {db_path}")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    migrations = [
        ("paymentreceipt", "sender_phone", "TEXT"),
        ("supportticket", "photo_path", "TEXT")
    ]

    for table, col_name, col_type in migrations:
        try:
            print(f"Adding column {col_name} to {table} table...")
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
            print(f"Column {col_name} added.")
        except sqlite3.OperationalError as e:
            if "duplicate column name" in str(e).lower():
                print(f"Column {col_name} already exists in {table}.")
            else:
                print(f"Error adding column {col_name} to {table}: {e}")

    conn.commit()
    conn.close()
    print("Portal migration finished.")

if __name__ == "__main__":
    migrate()
