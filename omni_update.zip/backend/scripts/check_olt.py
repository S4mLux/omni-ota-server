import asyncio
import sys
import os

# Add root directory to path to import backend modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from backend.models import OLT
from backend.olt_driver import OLTDriver

async def check_olt():
    olt = OLT(
        id=1,
        name="VSOL V1600GS-F",
        ip_address="10.255.255.106",
        username="admin",
        password="internat*2026",
        snmp_community="private"
    )

    print(f"[*] Testing connection to OLT {olt.name} ({olt.ip_address})...")
    
    # 1. Probe Status
    is_online = await OLTDriver.probe_status(olt)
    if not is_online:
        print("[!] OLT is OFFLINE.")
        return

    print("[+] OLT is ONLINE.")

    # 2. Get Port States
    print("[*] Fetching Port States...")
    ports = await OLTDriver.get_port_states(olt)
    print(f"[+] Ports found: {len(ports)}")
    for p in ports:
        print(f"  - {p['label']}: {p['status']} ({p['type']})")

    # 3. Scan Unauthenticated ONUs
    print("[*] Scanning Unauthenticated ONUs...")
    unauth = await OLTDriver.scan_unauthenticated_onus(olt)
    if unauth:
        print(f"[+] Found {len(unauth)} unauthenticated ONUs:")
        for o in unauth:
            print(f"  - PON {o['pon_port']}, Index {o['onu_index']}, SN: {o['serial_number']}")
    else:
        print("[+] No unauthenticated ONUs found.")

    # 4. Get some system info if possible
    client = await OLTDriver.get_client(olt)
    if client:
        try:
            print("[*] Fetching System Info...")
            output = await OLTDriver.execute_command_safe(client, "show version")
            print("[+] System Version:")
            print(output.strip())
            
            output = await OLTDriver.execute_command_safe(client, "show system-info")
            print("[+] System Info:")
            print(output.strip())
        finally:
            client.close()

if __name__ == "__main__":
    asyncio.run(check_olt())
