import sys
import os
from librouteros import connect

def diagnose(host, user, password, port=8728):
    print(f"--- OMNI NEURAL DIAGNOSTIC: MIKROTIK LEGACY API ---")
    print(f"Target: {host}:{port}")
    print(f"User:   {user}")
    print(f"---------------------------------------------------")
    
    try:
        print("[*] Attempting raw connection via librouteros...")
        api = connect(
            host=host,
            username=user,
            password=password,
            port=port,
            timeout=10
        )
        
        print("[+] SUCCESS: Connection established.")
        
        # Fetch Identity
        identity = list(api.path('/system/identity'))[0]
        print(f"[+] IDENTITY: {identity.get('name', 'Unknown')}")
        
        # Fetch Resources
        resource = list(api.path('/system/resource'))[0]
        print(f"[+] PLATFORM: {resource.get('board-name', 'Unknown')}")
        print(f"[+] VERSION:  {resource.get('version', 'Unknown')}")
        print(f"[+] CPU_LOAD: {resource.get('cpu-load', '0')}%")
        
        api.close()
        print("---------------------------------------------------")
        print("[!] DIAGNOSTIC COMPLETE: Hardware communication is NOMINAL.")
        
    except Exception as e:
        print(f"[!] FAILED: {str(e)}")
        print("---------------------------------------------------")
        print("[?] TROUBLESHOOTING TIPS:")
        print("1. Ensure 'api' service is enabled in IP -> Services.")
        print("2. Ensure port 8728 is open in the MikroTik Firewall.")
        print("3. Verify that the User has 'api' and 'read' permissions.")
        print("4. Check if your IP is allowed in 'Available From' in IP -> Services -> api.")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python diagnose_mikrotik.py <IP> <USER> <PASS> [PORT]")
        sys.exit(1)
        
    ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    port = int(sys.argv[4]) if len(sys.argv) > 4 else 8728
    
    diagnose(ip, username, password, port)
