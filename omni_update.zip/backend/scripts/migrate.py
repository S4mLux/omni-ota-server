import sqlite3
import os

db_path = "omni_isp.db"

def migrate():
    if not os.path.exists(db_path):
        print("DB not found at", db_path)
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    print("[*] Checking for migrations...")

    # Add onu_id to client table
    cursor.execute("PRAGMA table_info(client)")
    columns = [col[1] for col in cursor.fetchall()]
    
    if "onu_id" not in columns:
        print("[+] Adding 'onu_id' column to 'client' table...")
        cursor.execute("ALTER TABLE client ADD COLUMN onu_id INTEGER REFERENCES onu(id)")
    else:
        print("[.] 'onu_id' column already exists.")

    conn.commit()
    conn.close()
    print("[+] Migration finished.")

if __name__ == "__main__":
    migrate()
