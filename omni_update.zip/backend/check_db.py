import sqlite3
conn = sqlite3.connect('omni_isp.db')
cursor = conn.cursor()
cursor.execute('PRAGMA table_info(olt)')
columns = [row[1] for row in cursor.fetchall()]
print("Columnas en tabla OLT:", columns)
if 'snmp_version' in columns:
    print("✓ snmp_version existe")
else:
    print("✗ snmp_version NO existe")
conn.close()