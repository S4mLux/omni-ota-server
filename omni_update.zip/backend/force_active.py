import asyncio
from backend.database import engine
from sqlmodel import Session
from backend.root_api import force_client_status, ForceStatusRequest

async def main():
    with Session(engine) as session:
        print("Forzando restauración de ADM (ID: 126)...")
        res = await force_client_status(
            ForceStatusRequest(client_id=126, status="ACTIVE"), 
            session=session
        )
        print(f"Resultado: {res}")

if __name__ == "__main__":
    asyncio.run(main())
