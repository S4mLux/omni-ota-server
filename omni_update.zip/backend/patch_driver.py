import asyncio
import os
import sys

# Script para inyectar la mejora de captura de address-list en el driver
file_path = r"c:\laragon\www\X\backend\mikrotik_driver.py"

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
skip = False
in_function = False

for i, line in enumerate(lines):
    if "async def suspend_dhcp_client(router, ip_address: str):" in line:
        in_function = True
        new_lines.append(line)
        new_lines.append("        \"\"\"\n")
        new_lines.append("        Pone al cliente DHCP en el address-list 'MOROSOS'.\n")
        new_lines.append("        Retorna la lista que tenia antes para poder restaurarla despues.\n")
        new_lines.append("        \"\"\"\n")
        continue
    
    if in_function:
        if "leases = MikroTikDriver._legacy_get" in line:
            new_lines.append(line)
            new_lines.append("            print(f\"[MK DEBUG] Buscando lease para IP: {ip_address} para capturar estado previo...\")\n")
            new_lines.append("            for lease in leases:\n")
            new_lines.append("                if lease.get(\"address\") == ip_address:\n")
            new_lines.append("                    lid = lease.get(\".id\", \"\")\n")
            new_lines.append("                    current_list = lease.get(\"address-lists\", lease.get(\"address-list\", \"\"))\n")
            new_lines.append("                    print(f\"[MK DEBUG] Lista actual detectada en MikroTik: '{current_list}'\")\n")
            new_lines.append("                    update_params = {\"address-lists\": \"MOROSOS\"}\n")
            new_lines.append("                    if isinstance(api, RestApiWrapper):\n")
            new_lines.append("                        api.post(f\"/ip/dhcp-server/lease/{lid}/set\", update_params)\n")
            new_lines.append("                    else:\n")
            new_lines.append("                        MikroTikDriver._legacy_set(api, \"/ip/dhcp-server/lease\", lid, update_params)\n")
            new_lines.append("                    print(f\"[MK SUSPEND DHCP] OK - {ip_address} -> MOROSOS (Capturado: '{current_list}')\")\n")
            new_lines.append("                    return current_list if current_list else \"\"\n")
            skip = True
        
        if "return False" in line and skip:
            new_lines.append(line)
            in_function = False
            skip = False
            continue
            
        if skip:
            continue

    new_lines.append(line)

with open(file_path, "w", encoding="utf-8") as f:
    f.writelines(new_lines)
print("Driver actualizado con éxito.")
