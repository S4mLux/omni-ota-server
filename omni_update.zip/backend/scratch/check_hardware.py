import sqlite3
import os

db_path = r"c:\laragon\www\X\omni_isp.db"
if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("Checking routers...")
    try:
        cursor.execute("SELECT id, name, ip_address FROM router")
        routers = cursor.fetchall()
        for r in routers:
            print(f"Router: {r}")
    except Exception as e:
        print(f"Error checking routers: {e}")
        
    print("\nChecking OLTs...")
    try:
        cursor.execute("SELECT id, name, ip_address FROM olt")
        olts = cursor.fetchall()
        for o in olts:
            print(f"OLT: {o}")
    except Exception as e:
        print(f"Error checking OLTs: {e}")
        
    conn.close()
else:
    print(f"Database {db_path} not found.")
