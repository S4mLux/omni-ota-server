import os

path = r'c:\laragon\www\X\backend\models.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Limpiar el error anterior (si existe)
content = content.replace("    sent_at: Optional[datetime] = Field(default_factory=datetime.utcnow)\n    intensive_monitoring_until: Optional[datetime] = Field(default=None)", "    sent_at: Optional[datetime] = Field(default_factory=datetime.utcnow)")

# 2. Añadir campo a ONU
old_onu_end = "    last_seen: datetime = Field(default_factory=datetime.utcnow)"
new_onu_end = "    last_seen: datetime = Field(default_factory=datetime.utcnow)\n    intensive_monitoring_until: Optional[datetime] = Field(default=None)"

if old_onu_end in content:
    # OJO: ONU es la primera ocurrencia de last_seen después de class ONU
    start_onu = content.find("class ONU")
    target_pos = content.find(old_onu_end, start_onu)
    if target_pos != -1:
        content = content[:target_pos] + new_onu_end + content[target_pos + len(old_onu_end):]
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        print("Campo intensive_monitoring_until añadido correctamente a ONU.")
    else:
        print("Error: No se encontró last_seen dentro de la clase ONU.")
else:
    print("Error: No se encontró la estructura esperada en models.py")
