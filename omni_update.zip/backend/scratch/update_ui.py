import os

path = r'c:\laragon\www\X\frontend\src\components\ONUDetailsModal.tsx'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Bloque a reemplazar (el cierre de la columna izquierda)
old_block = """              </div>
            </div>

            {/* Right: History Chart & Client Info */}"""

new_block = """              </div>

              {/* Monitoreo Crítico (Trace Mode) */}
              <div 
                className="p-6 rounded-3xl border space-y-4" 
                style={{ 
                  backgroundColor: "var(--surface-lighter)", 
                  borderColor: details?.intensive_monitoring_until && new Date(details.intensive_monitoring_until) > new Date() ? "rgba(59, 130, 246, 0.4)" : "var(--border)" 
                }}
              >
                <h3 className="text-[10px] font-mono uppercase tracking-widest flex items-center gap-2" style={{ color: "var(--accent)" }}>
                  <Activity size={14} className={details?.intensive_monitoring_until && new Date(details.intensive_monitoring_until) > new Date() ? "text-blue-500 animate-pulse" : ""} /> 
                  MONITOREO_CRITICO_DETALLADO
                </h3>

                {details?.intensive_monitoring_until && new Date(details.intensive_monitoring_until) > new Date() ? (
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4">
                    <p className="text-[9px] font-mono text-blue-400 font-bold mb-1 uppercase">MODO_TRAZA_ACTIVO</p>
                    <p className="text-lg font-black font-mono text-blue-500">
                      {new Date(details.intensive_monitoring_until).toLocaleTimeString()}
                    </p>
                    <p className="text-[8px] font-mono opacity-50 mt-1 uppercase italic">Capturando datos cada 30 segundos hasta el fin del ciclo.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-[9px] font-mono opacity-50 leading-relaxed uppercase">Activar seguimiento de alta frecuencia para diagnóstico de fallas intermitentes:</p>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 6, 24].map(h => (
                        <button
                          key={h}
                          onClick={() => handleEnableIntensive(h)}
                          className="py-2 rounded-xl text-[9px] font-black font-mono border border-white/5 bg-white/5 hover:bg-blue-500 hover:text-white transition-all uppercase"
                        >
                          {h}H
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right: History Chart & Client Info */}"""

if old_block in content:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.replace(old_block, new_block))
    print("UI de Monitoreo Crítico añadida con éxito.")
else:
    print("Error: No se pudo localizar el bloque de la columna izquierda.")
