import requests
import json

def test_unified_endpoint():
    url = "http://localhost:8000/api/v2/admin/olts/test-connection-v2"
    payload = {
        "ip_address": "10.255.255.106",
        "username": "admin",
        "password": "",
        "snmp_version": "v2c",
        "snmp_community": "panel-isp"
    }
    
    print(f"Testing unified endpoint v2 with full payload...")
    try:
        response = requests.post(url, json=payload, timeout=25)
        print(f"STATUS CODE: {response.status_code}")
        print(f"RESPONSE: {json.dumps(response.json(), indent=2)}")
    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    test_unified_endpoint()
