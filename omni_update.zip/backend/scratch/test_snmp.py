import asyncio
import sys
import os

# Añadir el directorio raíz al path para poder importar backend
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from backend.database import engine
from backend.models import OLT
from backend.olt_driver import OLTDriver
from sqlmodel import Session, select

async def test_onus():
    print("--- Iniciando prueba SNMP ---")
    with Session(engine) as session:
        olts = session.exec(select(OLT)).all()
        if not olts:
            print("No hay OLTs registradas en la base de datos.")
            return

        for olt in olts:
            print(f"\nProbando OLT: {olt.name} ({olt.ip_address})")
            
            # 1. Probar estado básico
            print("  - Sondeando estado...")
            status = await OLTDriver.probe_status(olt)
            print(f"    Respuesta: {'ONLINE' if status else 'OFFLINE (o SNMP no configurado)'}")
            
            if status:
                # 2. Intentar walk de ONUs
                print("  - Escaneando ONUs vía SNMP...")
                onus = await OLTDriver.scan_unauthenticated_onus(olt)
                print(f"    ONUs encontradas: {len(onus)}")
                for onu in onus[:5]: # Mostrar primeras 5
                    print(f"      * PON {onu['pon_port']} / IDX {onu['onu_index']} -> SN: {onu['serial_number']} ({onu['status']})")
                
                if len(onus) > 0:
                    # 3. Probar señal de la primera ONU
                    o = onus[0]
                    print(f"  - Obteniendo detalles de la primera ONU (PON {o['pon_port']} IDX {o['onu_index']})...")
                    details = await OLTDriver.get_onu_details(olt, o['pon_port'], o['onu_index'])
                    print(f"    Señal: {details['signal_dbm']} dBm")
                    print(f"    Distancia: {details['distance']}")

if __name__ == "__main__":
    asyncio.run(test_onus())
