import os

path = r'c:\laragon\www\X\backend\main.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Bloque a reemplazar
old_block = """            while True:
                await telemetry_step()
                await asyncio.sleep(60)"""

new_block = """            while True:
                now = datetime.now()
                # 1. Ejecutar telemetría cada 30 segundos para datos "Live"
                await telemetry_step()
                
                # 2. Guardar en Historial solo una vez por hora (Snapshot)
                try:
                    with Session(engine) as session:
                        onus = session.exec(select(ONU)).all()
                        for onu in onus:
                            # Buscar el último registro de historial para esta ONU
                            last_h = session.exec(
                                select(ONUSignalHistory)
                                .where(ONUSignalHistory.onu_id == onu.id)
                                .order_by(ONUSignalHistory.timestamp.desc())
                                .limit(1)
                            ).first()
                            
                            should_save = False
                            if not last_h:
                                should_save = True
                            else:
                                diff = (now - last_h.timestamp).total_seconds()
                                if diff >= 3600: # 1 hora
                                    should_save = True
                            
                            if should_save and onu.status == "ONLINE":
                                session.add(ONUSignalHistory(
                                    onu_id=onu.id,
                                    signal_dbm=onu.signal_dbm,
                                    bandwidth_rx=onu.bandwidth_rx,
                                    bandwidth_tx=onu.bandwidth_tx
                                ))
                        
                        # 3. Limpieza automática (Borrar datos de más de 48 horas)
                        from sqlalchemy import text
                        session.execute(text("DELETE FROM onusignalhistory WHERE timestamp < datetime('now', '-48 hours')"))
                        session.commit()
                except Exception as e:
                    print(f"[CLEANUP/HISTORY ERROR] {e}")

                await asyncio.sleep(30)"""

if old_block in content:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.replace(old_block, new_block))
    print("Ciclo de telemetría actualizado a 30s con snapshot horario.")
else:
    # Intento alternativo si los espacios fallan
    print("No se encontró el bloque exacto, intentando reemplazo por patrón...")
    import re
    new_content = re.sub(r'while True:\s+await telemetry_step\(\)\s+await asyncio\.sleep\(60\)', new_block, content)
    if new_content != content:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("Ciclo actualizado mediante expresión regular.")
    else:
        print("Error: No se pudo localizar el bucle principal en main.py")
