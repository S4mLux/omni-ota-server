import asyncio
import sys
import os

# Add parent dir to path
sys.path.append(os.getcwd())

from backend.models import OLT
from backend.olt_driver import OLTDriver

async def main():
    # Known OLT in user's DB
    olt = OLT(
        name="test",
        ip_address="10.255.255.106",
        snmp_version="v2c",
        snmp_community="panel-isp"
    )
    
    print(f"Testing SNMP connection to {olt.ip_address} with community '{olt.snmp_community}'...")
    res = await OLTDriver.snmp_get(olt, "1.3.6.1.2.1.1.1.0")
    print(f"RESULT: {res}")
    
    if res is None:
        # Try with 'public' just in case
        print("Retrying with 'public'...")
        olt.snmp_community = "public"
        res = await OLTDriver.snmp_get(olt, "1.3.6.1.2.1.1.1.0")
        print(f"RESULT (public): {res}")

if __name__ == "__main__":
    asyncio.run(main())
