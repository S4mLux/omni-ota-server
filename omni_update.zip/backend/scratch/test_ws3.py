import asyncio
import websockets

async def test_ws():
    uri = "ws://localhost:8000/ws/notifications"
    print(f"Connecting to {uri}")
    try:
        async with websockets.connect(uri, origin="http://localhost:3000", ping_timeout=None) as websocket:
            print("Connected")
            await websocket.send("Hello")
            print("Sent Hello")
    except Exception as e:
        print(f"Error: {e}")

asyncio.run(test_ws())
