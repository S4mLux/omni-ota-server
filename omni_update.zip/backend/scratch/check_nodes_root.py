import sqlite3
import os

db_path = 'omni_isp.db'
if not os.path.exists(db_path):
    print(f"Error: {db_path} not found")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print("--- ROUTERS ---")
try:
    cursor.execute("SELECT id, name, ip_address FROM router")
    for row in cursor.fetchall():
        print(row)
except Exception as e:
    print(f"Error reading router table: {e}")

print("\n--- OLTS ---")
try:
    cursor.execute("SELECT id, name, ip_address FROM olt")
    for row in cursor.fetchall():
        print(row)
except Exception as e:
    print(f"Error reading olt table: {e}")

conn.close()
