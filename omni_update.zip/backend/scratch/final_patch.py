import os

path = r'c:\laragon\www\X\backend\main.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Modificar la inserción de historial (Snapshots horarios)
old_history = """                                        session.add(ONUSignalHistory(
                                            onu_id=onu.id, 
                                            signal_dbm=sig,
                                            bandwidth_rx=onu.bandwidth_rx,
                                            bandwidth_tx=onu.bandwidth_tx
                                        ))"""

new_history = """                                        # Snapshot horario: Guardar historial solo cada 1 hora
                                        last_h = session.exec(
                                            select(ONUSignalHistory)
                                            .where(ONUSignalHistory.onu_id == onu.id)
                                            .order_by(ONUSignalHistory.timestamp.desc())
                                            .limit(1)
                                        ).first()
                                        
                                        if not last_h or (now - last_h.timestamp).total_seconds() >= 3600:
                                            session.add(ONUSignalHistory(
                                                onu_id=onu.id, 
                                                signal_dbm=sig,
                                                bandwidth_rx=onu.bandwidth_rx,
                                                bandwidth_tx=onu.bandwidth_tx
                                            ))
                                        
                                        # Limpieza automática de datos > 48h
                                        from sqlalchemy import text
                                        session.execute(text("DELETE FROM onusignalhistory WHERE timestamp < datetime('now', '-48 hours')"))"""

# 2. Modificar tiempos de espera de 60 a 30 segundos
content = content.replace(old_history, new_history)
content = content.replace("await asyncio.sleep(60)", "await asyncio.sleep(30)")

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Parche de telemetría (30s) y snapshot horario aplicado con éxito.")
