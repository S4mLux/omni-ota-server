import requests
import json

payload = {
    "name": "Test Router",
    "ip_address": "1.2.3.4",
    "username": "admin",
    "password": "password",
    "api_port": 8728,
    "connection_mode": "API",
    "role": "EDGE",
    "brand": "huawei",
    "model": "NE20"
}

try:
    r = requests.post("http://localhost:8000/api/v2/admin/routers", json=payload)
    print(f"Status: {r.status_code}")
    print(f"Response: {r.text}")
except Exception as e:
    print(f"Error: {e}")
