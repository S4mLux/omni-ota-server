import os

path = r'c:\laragon\www\X\backend\olt_driver.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

old_start = '    @staticmethod\n    async def get_onu_details(olt: OLT, pon_port: int, onu_index: int) -> Dict[str, Any]:'
old_end = '        return details'

# Buscar el bloque exacto de get_onu_details
start_idx = content.find(old_start)
# Encontrar el return que cierra esa función (asumiendo que es el siguiente después del start)
end_idx = content.find(old_end, start_idx) + len(old_end)

if start_idx == -1 or end_idx == -1:
    print("No se pudo localizar la función get_onu_details para optimizar.")
    exit(1)

new_code = '''    @staticmethod
    async def get_onu_details(olt: OLT, pon_port: int, onu_index: int) -> Dict[str, Any]:
        """Diagnóstico completo de una ONU detectando rama de forma optimizada (paralelo)."""
        details: Dict[str, Any] = {
            "signal_dbm": None, "tx_power": None,
            "temp": None, "voltage": None,
            "distance": None, "status_msg": "Unknown",
            "rx_octets": None, "tx_octets": None,
            "model": None, "firmware": None
        }

        sys_obj = await OLTDriver.snmp_get(olt, "1.3.6.1.2.1.1.2.0") # OID_SYS_OBJ_ID
        is_cdata = sys_obj and "37950" in sys_obj
        
        oids = {
            "rx": "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.7" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.8",
            "tx": "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.6" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.9",
            "dist": "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.10" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.10",
            "status": "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.13" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.10",
            "model_name": "1.3.6.1.4.1.17409.2.3.1.1.1.2",
            "fw": "1.3.6.1.4.1.17409.2.3.1.1.1.5"
        }

        # Ejecutar SNMP en paralelo
        import asyncio
        tasks = [
            OLTDriver.snmp_get(olt, f"{oids['rx']}.{pon_port}.{onu_index}"),
            OLTDriver.snmp_get(olt, f"{oids['tx']}.{pon_port}.{onu_index}"),
            OLTDriver.snmp_get(olt, f"{oids['dist']}.{pon_port}.{onu_index}"),
            OLTDriver.snmp_get(olt, f"{oids['status']}.{pon_port}.{onu_index}"),
            OLTDriver.snmp_get(olt, f"{oids['model_name']}.{pon_port}.{onu_index}"),
            OLTDriver.snmp_get(olt, f"{oids['fw']}.{pon_port}.{onu_index}")
        ]
        
        results = await asyncio.gather(*tasks)
        rx_raw, tx_raw, dist_raw, status_raw, model_raw, fw_raw = results

        try:
            if rx_raw and "ERROR" not in rx_raw:
                details["signal_dbm"] = float(rx_raw) if is_cdata else float(rx_raw) / 100.0
            if tx_raw and "ERROR" not in tx_raw:
                details["tx_power"] = float(tx_raw) if is_cdata else float(tx_raw) / 100.0
            if dist_raw and "ERROR" not in dist_raw:
                details["distance"] = float(dist_raw)
        except: pass

        def clean_snmp_str(s):
            if not s or "ERROR" in s: return None
            s = s.strip().replace('"', '')
            if all(c in "0123456789ABCDEFabcdef " for c in s) and len(s) > 4:
                try:
                    parts = s.split()
                    return "".join(chr(int(p, 16)) for p in parts if p).strip()
                except: pass
            return s
            
        details["model"] = clean_snmp_str(model_raw)
        details["firmware"] = clean_snmp_str(fw_raw)
        details["status_msg"] = "Online" if status_raw == "1" else "Offline"

        if status_raw == "1":
            ifIndex = await OLTDriver.get_onu_ifindex(olt, pon_port, onu_index)
            if ifIndex:
                rx_t, tx_t = await asyncio.gather(
                    OLTDriver.snmp_get(olt, f"1.3.6.1.2.1.2.2.1.10.{ifIndex}"),
                    OLTDriver.snmp_get(olt, f"1.3.6.1.2.1.2.2.1.16.{ifIndex}")
                )
                try:
                    details["rx_octets"] = int(rx_t) if rx_t and "ERROR" not in rx_t else None
                    details["tx_octets"] = int(tx_t) if tx_t and "ERROR" not in tx_t else None
                except: pass

        return details'''

with open(path, 'w', encoding='utf-8') as f:
    f.write(content[:start_idx] + new_code + content[end_idx:])

print("Optimización aplicada con éxito.")
