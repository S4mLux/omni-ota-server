import asyncio
import websockets

async def test_ws():
    uri = "ws://localhost:8000/ws/notifications"
    try:
        async with websockets.connect(uri) as websocket:
            print("Connected")
            await websocket.send("Hello")
            print("Sent Hello")
            # We don't expect a reply right away unless there's a broadcast
    except Exception as e:
        print(f"Error: {e}")

asyncio.run(test_ws())
