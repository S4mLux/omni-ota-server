from sqlmodel import Session, select
from backend.database import engine
from backend.models import Staff

with Session(engine) as session:
    positions = session.exec(select(Staff.position)).all()
    print(set(positions))
