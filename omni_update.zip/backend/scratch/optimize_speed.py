import os
import sqlite3

# 1. Actualizar Base de Datos
db_path = 'omni_isp.db'
if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute('ALTER TABLE onu ADD COLUMN snmp_ifindex INTEGER')
        conn.commit()
        print("Columna snmp_ifindex añadida a la DB.")
    except:
        print("Columna snmp_ifindex ya existía.")
    conn.close()

# 2. Actualizar models.py
models_path = r'c:\laragon\www\X\backend\models.py'
with open(models_path, 'r', encoding='utf-8') as f:
    m_content = f.read()
if 'snmp_ifindex: Optional[int] = None' not in m_content:
    m_content = m_content.replace('intensive_monitoring_until: Optional[datetime] = Field(default=None)', 
                                  'intensive_monitoring_until: Optional[datetime] = Field(default=None)\n    snmp_ifindex: Optional[int] = None')
    with open(models_path, 'w', encoding='utf-8') as f:
        f.write(m_content)
    print("models.py actualizado.")

# 3. Optimizar Driver (olt_driver.py)
driver_path = r'c:\laragon\www\X\backend\olt_driver.py'
with open(driver_path, 'r', encoding='utf-8') as f:
    d_content = f.read()

# Modificar get_onu_details para aceptar y retornar ifindex
old_method_head = "    async def get_onu_details(olt: OLT, pon_port: int, onu_index: int) -> Dict[str, Any]:"
new_method_head = "    async def get_onu_details(olt: OLT, pon_port: int, onu_index: int, cached_ifindex: int = None) -> Dict[str, Any]:"

d_content = d_content.replace(old_method_head, new_method_head)
d_content = d_content.replace('ifIndex = await OLTDriver.get_onu_ifindex(olt, pon_port, onu_index)', 
                              'ifIndex = cached_ifindex or await OLTDriver.get_onu_ifindex(olt, pon_port, onu_index)')
# Añadir retorno de ifindex en el dict de detalles
d_content = d_content.replace('"firmware": None', '"firmware": None, "snmp_ifindex": None')
d_content = d_content.replace('details["firmware"] = clean_snmp_str(fw_raw)', 
                              'details["firmware"] = clean_snmp_str(fw_raw)\n        details["snmp_ifindex"] = ifIndex if status_raw == "1" else None')

with open(driver_path, 'w', encoding='utf-8') as f:
    f.write(d_content)
print("olt_driver.py optimizado (Cache IFINDEX).")

# 4. Actualizar admin_api.py para pasar el caché
api_path = r'c:\laragon\www\X\backend\admin_api.py'
with open(api_path, 'r', encoding='utf-8') as f:
    a_content = f.read()
a_content = a_content.replace('details = await OLTDriver.get_onu_details(olt, onu.pon_port, onu.onu_index)',
                              'details = await OLTDriver.get_onu_details(olt, onu.pon_port, onu.onu_index, cached_ifindex=onu.snmp_ifindex)\n    if details.get("snmp_ifindex") and details["snmp_ifindex"] != onu.snmp_ifindex:\n        onu.snmp_ifindex = details["snmp_ifindex"]\n        session.add(onu)\n        session.commit()')
with open(api_path, 'w', encoding='utf-8') as f:
    f.write(a_content)
print("admin_api.py actualizado.")

# 5. UI Indicator (ONUDetailsModal.tsx)
ui_path = r'c:\laragon\www\X\frontend\src\components\ONUDetailsModal.tsx'
with open(ui_path, 'r', encoding='utf-8') as f:
    u_content = f.read()

old_ui = """                <span className={`px-3 py-1 rounded-full text-[10px] font-black font-mono uppercase tracking-widest ${details?.status_msg === 'Online' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-500'}`}>
                  {details?.status_msg}
                </span>"""

new_ui = """                <span className={`px-3 py-1 rounded-full text-[10px] font-black font-mono uppercase tracking-widest ${details?.status_msg === 'Online' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-500'}`}>
                  {details?.status_msg}
                </span>
                {loading && <span className="text-[10px] font-mono text-blue-500 animate-pulse uppercase tracking-widest ml-2">// REFRESHING_LIVE_DATA</span>}"""

if old_ui in u_content:
    with open(ui_path, 'w', encoding='utf-8') as f:
        f.write(u_content.replace(old_ui, new_ui))
    print("UI de refresco añadida.")
