import asyncio
import sys
import os

# Add parent dir to path
sys.path.append(os.getcwd())

from backend.models import OLT
from backend.olt_driver import OLTDriver

async def main():
    olt = OLT(
        name="test",
        ip_address="10.255.255.106",
        username="admin",
        password="",
        ssh_port=22
    )
    
    print(f"Testing SSH connection to {olt.ip_address}...")
    client = await OLTDriver.get_ssh_client(olt)
    print(f"SSH RESULT: {client is not None}")
    if client:
        client.close()

if __name__ == "__main__":
    asyncio.run(main())
