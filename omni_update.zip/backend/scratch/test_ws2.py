import asyncio
import websockets

async def test_ws():
    uri = "ws://localhost:8000/ws/notifications"
    print(f"Connecting to {uri}")
    try:
        async with websockets.connect(uri, ping_timeout=None) as websocket:
            print("Connected")
            await websocket.send("Hello")
            print("Sent Hello")
            msg = await asyncio.wait_for(websocket.recv(), timeout=2.0)
            print(f"Received: {msg}")
    except Exception as e:
        print(f"Error: {e}")

asyncio.run(test_ws())
