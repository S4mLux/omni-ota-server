import sys
import os
from pysnmp.hlapi import *

def test_sync(ip, community):
    print(f"Sync test: {ip} | {community}")
    errorIndication, errorStatus, errorIndex, varBinds = next(
        getCmd(SnmpEngine(),
               CommunityData(community),
               UdpTransportTarget((ip, 161), timeout=2, retries=0),
               ContextData(),
               ObjectType(ObjectIdentity('1.3.6.1.2.1.1.1.0')))
    )

    if errorIndication:
        print(f"Error: {errorIndication}")
    elif errorStatus:
        print(f"Error: {errorStatus}")
    else:
        for varBind in varBinds:
            print(f"Result: {varBind[0].prettyPrint()} = {varBind[1].prettyPrint()}")

if __name__ == "__main__":
    test_sync("10.255.255.106", "panel-isp")
    test_sync("10.255.255.106", "public")
