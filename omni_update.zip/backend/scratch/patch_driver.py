import os

path = r'c:\laragon\www\X\backend\olt_driver.py'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

old_code = """        # 3. Model & Firmware
        model_raw = await OLTDriver.snmp_get(olt, f"{OID_VSOL_ONU_MODEL}.{pon_port}.{onu_index}")
        fw_raw = await OLTDriver.snmp_get(olt, f"{OID_VSOL_ONU_FIRMWARE}.{pon_port}.{onu_index}")

        # Normalizar señal
        signal = None
        if sig_raw and not sig_raw.startswith("ERROR"):
            try:
                v = float(sig_raw)
                signal = round(v / 100.0, 2) if v < -100 else v
            except: pass
        
        return {
            "signal_dbm": signal,
            "distance": int(dist_raw) if dist_raw and dist_raw.isdigit() else None,
            "model": model_raw.strip() if model_raw and "ERROR" not in model_raw else None,
            "firmware": fw_raw.strip() if fw_raw and "ERROR" not in fw_raw else None
        }"""

new_code = """        # 3. Model & Firmware
        model_raw = await OLTDriver.snmp_get(olt, f"1.3.6.1.4.1.17409.2.3.1.1.1.2.{pon_port}.{onu_index}") # Model Name
        if not model_raw or "ERROR" in model_raw:
            model_raw = await OLTDriver.snmp_get(olt, f"1.3.6.1.4.1.17409.2.3.1.1.1.1.{pon_port}.{onu_index}") # Type
            
        fw_raw = await OLTDriver.snmp_get(olt, f"{OID_VSOL_ONU_FIRMWARE}.{pon_port}.{onu_index}")

        # Función para limpiar strings de SNMP (pueden venir en Hex)
        def clean_snmp_str(s):
            if not s or "ERROR" in s: return None
            s = s.strip().replace('"', '')
            # Si parece hexadecimal (ej: 56 32 38 30 31), intentar convertir
            if all(c in "0123456789ABCDEFabcdef " for c in s) and len(s) > 4:
                try:
                    parts = s.split()
                    return "".join(chr(int(p, 16)) for p in parts if p).strip()
                except: pass
            return s

        return {
            "signal_dbm": signal,
            "distance": int(dist_raw) if dist_raw and dist_raw.isdigit() else None,
            "model": clean_snmp_str(model_raw),
            "firmware": clean_snmp_str(fw_raw)
        }"""

if old_code in content:
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.replace(old_code, new_code))
    print("Driver parcheado con éxito.")
else:
    print("No se encontró el bloque de código original. Verifica el contenido.")
