import asyncio
import sys
import os

# Add parent dir to path
sys.path.append(os.getcwd())

from backend.models import OLT
from backend.olt_driver import OLTDriver

async def main():
    olt = OLT(
        name="test",
        ip_address="10.255.255.106",
        snmp_version="v2c",
        snmp_community="panel-isp"
    )
    
    print(f"Testing SNMP connection to {olt.ip_address} with community '{olt.snmp_community}' (Long timeout)...")
    
    from pysnmp.hlapi.v3arch.asyncio import (
        SnmpEngine, UdpTransportTarget, ContextData,
        ObjectType, ObjectIdentity, get_cmd
    )
    from backend.olt_driver import _build_snmp_auth

    try:
        auth = _build_snmp_auth(olt)
        engine = SnmpEngine()
        # 10 seconds timeout
        transport = await UdpTransportTarget.create((olt.ip_address, 161), timeout=10, retries=1)
        
        print("Sending get_cmd...")
        errorIndication, errorStatus, errorIndex, varBinds = await get_cmd(
            engine, auth, transport, ContextData(),
            ObjectType(ObjectIdentity("1.3.6.1.2.1.1.1.0"))
        )
        
        if errorIndication:
            print(f"ERROR Indication: {errorIndication}")
        elif errorStatus:
            print(f"ERROR Status: {errorStatus}")
        else:
            print(f"SUCCESS: {varBinds[0][1].prettyPrint()}")
                
        engine.close_dispatcher()
    except Exception as e:
        print(f"EXCEPTION: {e}")

if __name__ == "__main__":
    asyncio.run(main())
