import asyncio
import sys
import os

# Add parent dir to path
sys.path.append(os.getcwd())

from backend.models import OLT
from backend.olt_driver import OLTDriver
from pysnmp.hlapi.v3arch.asyncio import (
    SnmpEngine, UdpTransportTarget, ContextData,
    ObjectType, ObjectIdentity, get_cmd, CommunityData
)

async def test_snmp(ip, community, version_model):
    print(f"Trying {ip} | Community: {community} | Model: {version_model}...")
    try:
        engine = SnmpEngine()
        auth = CommunityData(community, mpModel=version_model)
        transport = await UdpTransportTarget.create((ip, 161), timeout=1, retries=0)
        
        errorIndication, errorStatus, errorIndex, varBinds = await get_cmd(
            engine, auth, transport, ContextData(),
            ObjectType(ObjectIdentity("1.3.6.1.2.1.1.1.0"))
        )
        
        engine.close_dispatcher()
        if not errorIndication and not errorStatus:
            return True, varBinds[0][1].prettyPrint()
        return False, str(errorIndication or errorStatus)
    except Exception as e:
        return False, str(e)

async def main():
    ip = "10.255.255.106"
    communities = ["panel-isp", "public", "private", "admin", "vsol"]
    models = [0, 1] # v1, v2c
    
    for comm in communities:
        for model in models:
            ok, res = await test_snmp(ip, comm, model)
            if ok:
                print(f"!!! FOUND: {comm} (model {model}) -> {res}")
                return
            else:
                print(f"FAILED: {comm} (model {model}) -> {res}")

if __name__ == "__main__":
    asyncio.run(main())
