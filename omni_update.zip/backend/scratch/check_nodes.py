import sqlite3
import os

db_path = 'backend/omni_isp.db'
if not os.path.exists(db_path):
    print(f"Error: {db_path} not found")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print("--- ROUTERS ---")
cursor.execute("SELECT id, name, ip_address FROM router")
for row in cursor.fetchall():
    print(row)

print("\n--- OLTS ---")
cursor.execute("SELECT id, name, ip_address FROM olt")
for row in cursor.fetchall():
    print(row)

conn.close()
