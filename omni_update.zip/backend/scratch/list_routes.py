import sys
import os
sys.path.append(os.getcwd())
from backend.main import app
for route in app.routes:
    print(f"{getattr(route, 'methods', 'N/A')} {route.path}")
