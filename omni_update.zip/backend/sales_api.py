"""
Sales API — Captación de clientes por vendedores + flujo de instalación
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlmodel import Session, select
from typing import Optional
from datetime import datetime
from pydantic import BaseModel
import os, shutil

from backend.models import Sale, Staff, Plan, Router, Installation
from backend.database import get_session

router = APIRouter(prefix="/api/v2/sales", tags=["sales"])

UPLOAD_DIR = "uploads/sales"
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ─────────────────────────────────────────────
# VENTAS
# ─────────────────────────────────────────────

@router.get("")
async def list_sales(
    status: Optional[str] = None,
    seller_id: Optional[int] = None,
    session: Session = Depends(get_session)
):
    query = select(Sale)
    if status:
        query = query.where(Sale.status == status)
    if seller_id:
        query = query.where(Sale.seller_id == seller_id)
    sales = session.exec(query.order_by(Sale.created_at.desc())).all()
    
    result = []
    for s in sales:
        seller = session.get(Staff, s.seller_id) if s.seller_id else None
        plan = session.get(Plan, s.plan_id) if s.plan_id else None
        installer = session.get(Staff, s.installer_id) if s.installer_id else None
        result.append({
            **s.dict(),
            "seller_name": seller.full_name if seller else None,
            "plan_name": plan.name if plan else None,
            "installer_name": installer.full_name if installer else None,
        })
    return result

@router.get("/pending-installation")
async def get_pending_installations(
    installer_id: Optional[int] = None,
    session: Session = Depends(get_session)
):
    """Vista del instalador: ventas marcadas para instalación"""
    query = select(Sale).where(Sale.status.in_(["PENDIENTE_INSTALACION", "INSTALANDO"]))
    if installer_id:
        query = query.where(Sale.installer_id == installer_id)
    sales = session.exec(query.order_by(Sale.created_at.asc())).all()
    
    result = []
    for s in sales:
        plan = session.get(Plan, s.plan_id) if s.plan_id else None
        router_obj = session.get(Router, s.router_id) if s.router_id else None
        result.append({
            **s.dict(),
            "plan_name": plan.name if plan else None,
            "router_name": router_obj.name if router_obj else None,
        })
    return result

@router.post("")
async def create_sale(
    full_name: str = Form(...),
    dni: str = Form(...),
    phone: str = Form(...),
    email: Optional[str] = Form(None),
    address: str = Form(...),
    lat: Optional[float] = Form(None),
    lng: Optional[float] = Form(None),
    plan_id: Optional[int] = Form(None),
    connection_type: str = Form("DHCP"),
    router_id: Optional[int] = Form(None),
    seller_id: Optional[int] = Form(None),
    installer_id: Optional[int] = Form(None),
    notes: Optional[str] = Form(None),
    cedula_photo: Optional[UploadFile] = File(None),
    session: Session = Depends(get_session)
):
    """Crear una nueva venta con todos los datos del cliente y foto de cédula"""
    cedula_path = None
    if cedula_photo:
        fname = f"cedula_{dni}_{int(datetime.utcnow().timestamp())}{os.path.splitext(cedula_photo.filename)[1]}"
        fpath = os.path.join(UPLOAD_DIR, fname)
        with open(fpath, "wb") as f:
            shutil.copyfileobj(cedula_photo.file, f)
        cedula_path = fpath

    # Determinar estado: si viene con instalador nace para instalación
    status = "PENDIENTE_INSTALACION" if installer_id else "NUEVO"

    sale = Sale(
        full_name=full_name,
        dni=dni,
        phone=phone,
        email=email,
        address=address,
        lat=lat,
        lng=lng,
        cedula_photo_path=cedula_path,
        plan_id=plan_id,
        connection_type=connection_type,
        router_id=router_id,
        seller_id=seller_id,
        installer_id=installer_id,
        notes=notes,
        status=status
    )
    session.add(sale)
    session.commit()
    session.refresh(sale)
    return sale

class AssignInstallerSchema(BaseModel):
    installer_id: int

@router.patch("/{sale_id}/mark-installation")
async def mark_for_installation(
    sale_id: int,
    body: AssignInstallerSchema,
    session: Session = Depends(get_session)
):
    """Marcar una venta para instalación y asignar instalador"""
    sale = session.get(Sale, sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")
    
    sale.status = "PENDIENTE_INSTALACION"
    sale.installer_id = body.installer_id
    sale.updated_at = datetime.utcnow()
    session.add(sale)
    session.commit()
    return {"status": "PENDIENTE_INSTALACION", "sale_id": sale_id}

@router.patch("/{sale_id}/cancel")
async def cancel_sale(sale_id: int, session: Session = Depends(get_session)):
    sale = session.get(Sale, sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")
    sale.status = "CANCELADO"
    sale.updated_at = datetime.utcnow()
    session.add(sale)
    session.commit()
    return {"status": "CANCELADO"}

@router.get("/stats")
async def get_sales_stats(session: Session = Depends(get_session)):
    """Estadísticas de ventas por estado"""
    from sqlmodel import func
    all_sales = session.exec(select(Sale)).all()
    stats = {}
    for s in all_sales:
        stats[s.status] = stats.get(s.status, 0) + 1
    return {"total": len(all_sales), "by_status": stats}
