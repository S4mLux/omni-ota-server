import sqlite3
import os

db_path = "omni_isp.db"

if not os.path.exists(db_path):
    print(f"Error: {db_path} not found.")
    exit(1)

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("Adding column is_read_by_staff...")
    cursor.execute("ALTER TABLE supportticket ADD COLUMN is_read_by_staff BOOLEAN DEFAULT 0")
    
    print("Adding column is_read_by_client...")
    cursor.execute("ALTER TABLE supportticket ADD COLUMN is_read_by_client BOOLEAN DEFAULT 1")
    
    conn.commit()
    conn.close()
    print("Success: Columns added correctly.")
except sqlite3.OperationalError as e:
    if "duplicate column name" in str(e).lower():
        print("Columns already exist.")
    else:
        print(f"OperationalError: {e}")
except Exception as e:
    print(f"Error: {e}")
