"""
MikroTik Driver — Producción completa
Soporta: Legacy API (librouteros) + REST API (httpx)
Métodos: DHCP leases, PPPoE secrets/active, resource, backup, suspend/restore, tráfico
"""
import asyncio
import json
import time as time_module
from backend.snmp_core import snmp_get
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor
from librouteros import connect

from backend.snmp_core import (
    snmp_get, snmp_walk, 
    OID_CPU_LOAD, OID_MEMORY_TOTAL, OID_MEMORY_USED, 
    OID_UPTIME, OID_IF_DESCR, OID_IF_IN, OID_IF_OUT
)
import ssl
import httpx

executor = ThreadPoolExecutor(max_workers=20)


# ─────────────────────────────────────────────────────────────
# REST API WRAPPERS (compatible con librouteros interface)
# ─────────────────────────────────────────────────────────────

class RestApiWrapper:
    """Capa de compatibilidad para que REST se vea como librouteros"""
    def __init__(self, user: str, password: str, url: str):
        self.user = user
        self.password = password
        self.url = url  # e.g. https://192.168.1.1/rest

    def path(self, *args):
        p_str = "/".join(args).lstrip("/")
        return RestPath(self.user, self.password, self.url, p_str)

    def close(self):
        pass

    def get(self, path: str, **params) -> List[Dict]:
        url = f"{self.url}/{path.lstrip('/')}"
        try:
            with httpx.Client(verify=False, timeout=8.0) as client:
                res = client.get(url, auth=(self.user, self.password), params=params)
                if res.status_code == 200:
                    data = res.json()
                    return data if isinstance(data, list) else [data]
                return []
        except Exception as e:
            print(f"[REST GET ERROR] {url}: {e}")
            return []

    def post(self, path: str, body: Dict) -> Dict:
        url = f"{self.url}/{path.lstrip('/')}"
        try:
            with httpx.Client(verify=False, timeout=8.0) as client:
                res = client.post(url, auth=(self.user, self.password), json=body)
                return res.json() if res.status_code in (200, 201) else {"error": res.text}
        except Exception as e:
            print(f"[REST POST ERROR] {url}: {e}")
            return {"error": str(e)}


class RestPath:
    def __init__(self, user, password, base_url, path):
        self.user = user
        self.password = password
        self.base_url = base_url
        self.path_str = path

    def __call__(self, **kwargs):
        url = f"{self.base_url}/{self.path_str}"
        try:
            with httpx.Client(verify=False, timeout=8.0) as client:
                res = client.get(url, auth=(self.user, self.password))
                if res.status_code == 200:
                    return res.json()
                return {"error": f"HTTP {res.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    def __iter__(self):
        res = self.__call__()
        if isinstance(res, list):
            yield from res
        else:
            yield res


# ─────────────────────────────────────────────────────────────
# MAIN DRIVER
# ─────────────────────────────────────────────────────────────

class MikroTikDriver:

    # ── Conexión ──────────────────────────────────────────────

    @staticmethod
    async def get_api(router):
        mode = getattr(router, "connection_mode", "API")
        print(f"[MK] Connecting: {router.name} | {router.ip_address} | Mode={mode}")
        if mode == "REST":
            return await MikroTikDriver._connect_rest(
                router.ip_address, router.username, router.password,
                getattr(router, "api_port", 443)
            )
        return await MikroTikDriver._connect_legacy(
            router.ip_address, router.username, router.password,
            getattr(router, "api_port", 8728)
        )

    @staticmethod
    async def _connect_legacy(ip, user, password, port):
        try:
            loop = asyncio.get_event_loop()
            api = await loop.run_in_executor(
                executor,
                lambda: connect(host=ip, username=user, password=password, port=port, timeout=6)
            )
            print(f"[MK] Legacy API OK: {ip}:{port}")
            return api
        except Exception as e:
            print(f"[MK] Legacy Connection Failed: {ip}:{port} | {e}")
            return None

    @staticmethod
    async def _connect_rest(ip, user, password, port):
        rest_port = 443 if port == 8728 else port
        protocol = "https" if rest_port == 443 else "http"
        url = f"{protocol}://{ip}:{rest_port}/rest"
        print(f"[MK] REST probe: {url}")

        # Usamos run_in_executor para no bloquear el event loop de asyncio
        # con la llamada sincrónica de httpx.
        def _check_rest():
            with httpx.Client(verify=False, timeout=6.0) as client:
                response = client.get(f"{url}/system/identity", auth=(user, password))
                if response.status_code == 200:
                    return True
                raise Exception(f"REST_AUTH_FAILED: {response.status_code}")

        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(executor, _check_rest)
            print(f"[MK] REST API OK: {ip}")
            return RestApiWrapper(user, password, url)
        except Exception as e:
            print(f"[MK] REST Connection Failed: {ip} | {e}")
            return None

    # ── Helpers internos ──────────────────────────────────────

    @staticmethod
    def _legacy_get(api, path: str) -> List[Dict]:
        """Obtiene lista de recursos vía librouteros"""
        try:
            return list(api.path(path))
        except Exception as e:
            print(f"[MK LEGACY GET ERROR] {path}: {e}")
            return []

    @staticmethod
    def _legacy_add(api, path: str, params: Dict) -> bool:
        """Agrega recurso vía librouteros"""
        try:
            api.path(path).add(**params)
            return True
        except Exception as e:
            print(f"[MK LEGACY ADD ERROR] {path}: {e}")
            return False

    @staticmethod
    def _legacy_set(api, path: str, id_: str, params: Dict) -> bool:
        try:
            api.path(path).update(**{".id": id_, **params})
            return True
        except Exception as e:
            print(f"[MK LEGACY SET ERROR] {path} id={id_}: {e}")
            return False

    # ── Sistema & Recursos ────────────────────────────────────

    @staticmethod
    async def get_resource(router) -> Dict:
        """CPU, RAM, uptime, versión de hardware"""
        brand = getattr(router, "brand", "mikrotik")
        if brand != "mikrotik":
            return await MikroTikDriver._get_generic_resource(router)
            
        api = await MikroTikDriver.get_api(router)
        if not api:
            # Fallback a SNMP si la API falla pero es MikroTik
            return await MikroTikDriver._get_generic_resource(router)
        try:
            loop = asyncio.get_event_loop()
            if isinstance(api, RestApiWrapper):
                res = await loop.run_in_executor(None, lambda: api.get("/system/resource"))
                return res[0] if res else {}
            items = await loop.run_in_executor(None, lambda: list(api.path("/system/resource")))
            return items[0] if items else {}
        except Exception as e:
            print(f"[MK RESOURCE ERROR] {e}")
            return {}
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def _get_generic_resource(router) -> Dict:
        """Obtiene recursos básicos vía SNMP para cualquier marca (Cisco, Huawei, etc)"""
        host = router.ip_address
        comm = getattr(router, "snmp_community", "public")
        ver = getattr(router, "snmp_version", "v2c")
        port = getattr(router, "snmp_port", 161)
        brand = getattr(router, "brand", "generic")

        # OIDs por marca
        oids = {
            "mikrotik": {"cpu": ".1.3.6.1.2.1.25.3.3.1.2.1", "mem": ".1.3.6.1.2.1.25.2.3.1.6.65536"},
            "cisco": {"cpu": ".1.3.6.1.4.1.9.9.109.1.1.1.1.5.1", "mem": ".1.3.6.1.4.1.9.9.48.1.1.1.5.1"},
            "huawei": {"cpu": ".1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5.0", "mem": ".1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7.0"},
            "juniper": {"cpu": ".1.3.6.1.4.1.2636.3.1.13.1.8.9.1.0.0", "mem": ".1.3.6.1.4.1.2636.3.1.13.1.11.9.1.0.0"},
            "generic": {"cpu": ".1.3.6.1.2.1.25.3.3.1.2.1", "mem": ".1.3.6.1.2.1.25.2.3.1.6.1"}
        }
        
        target = oids.get(brand, oids["generic"])
        
        cpu, uptime = await asyncio.gather(
            snmp_get(host, comm, target["cpu"], ver, port),
            snmp_get(host, comm, ".1.3.6.1.2.1.1.3.0", ver, port)
        )
        
        return {
            "cpu-load": int(cpu) if cpu and cpu.isdigit() else 0,
            "uptime": uptime or "unknown",
            "board-name": router.model if router.model != "auto" else brand.upper(),
            "version": "SNMP-Generic"
        }

    @staticmethod
    async def get_identity(router) -> str:
        brand = getattr(router, "brand", "mikrotik")
        if brand != "mikrotik":
            return router.name

        api = await MikroTikDriver.get_api(router)
        if not api:
            return "OFFLINE"
        try:
            loop = asyncio.get_event_loop()
            if isinstance(api, RestApiWrapper):
                res = await loop.run_in_executor(None, lambda: api.get("/system/identity"))
                return res[0].get("name", "MikroTik") if res else "MikroTik"
            items = await loop.run_in_executor(None, lambda: list(api.path("/system/identity")))
            return items[0].get("name", "MikroTik") if items else "MikroTik"
        except Exception as e:
            return "MikroTik"
        finally:
            if hasattr(api, "close"):
                api.close()

    # ── DHCP Server Leases ────────────────────────────────────

    @staticmethod
    async def get_dhcp_leases(router) -> List[Dict]:
        """Obtiene todos los leases del DHCP server (dinámicos y estáticos)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/ip/dhcp-server/lease")
            return MikroTikDriver._legacy_get(api, "/ip/dhcp-server/lease")
        except Exception as e:
            print(f"[MK DHCP LEASES ERROR] {e}")
            return []
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def create_dhcp_lease(router, params: Dict) -> bool:
        """
        Crea un lease estático en el DHCP server.
        params: ip-address, mac-address, server, comment, address-list (opcional)
        """
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            if isinstance(api, RestApiWrapper):
                result = api.post("/ip/dhcp-server/lease/add", params)
                return "ret" in result or ".id" in result
            return MikroTikDriver._legacy_add(api, "/ip/dhcp-server/lease", params)
        except Exception as e:
            print(f"[MK CREATE DHCP ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def suspend_dhcp_client(router, ip_address: str, prev_address_list: str = "") -> bool:
        """
        Corta servicio DHCP cambiando address-list a MOROSOS.
        La regla de firewall en el MikroTik debe bloquear esa lista.
        """
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            leases = MikroTikDriver._legacy_get(api, "/ip/dhcp-server/lease") if not isinstance(api, RestApiWrapper) else api.get("/ip/dhcp-server/lease")
            print(f"[MK DEBUG] Buscando lease para IP: {ip_address} entre {len(leases)} leases...")
            for lease in leases:
                if lease.get("address") == ip_address:
                    lid = lease.get(".id", "")
                    # Capturamos el nombre de la lista actual (el plan del cliente)
                    original_list = lease.get("address-lists") or lease.get("address-list") or ""
                    update_params = {"address-lists": "MOROSOS"}
                    
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ip/dhcp-server/lease/{lid}/set", update_params)
                    else:
                        MikroTikDriver._legacy_set(api, "/ip/dhcp-server/lease", lid, update_params)


                    
                    print(f"[MK SUSPEND DHCP] OK - IP {ip_address}: '{original_list}' -> 'MOROSOS'")
                    return original_list



            print(f"[MK DEBUG] No se encontro lease activo para la IP: {ip_address}")
            return False

        except Exception as e:
            print(f"[MK SUSPEND DHCP ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def restore_dhcp_client(router, ip_address: str, prev_address_list: str = "") -> bool:
        """Restaura el address-list original cuando el cliente paga"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            leases = MikroTikDriver._legacy_get(api, "/ip/dhcp-server/lease") if not isinstance(api, RestApiWrapper) else api.get("/ip/dhcp-server/lease")
            for lease in leases:
                if lease.get("address") == ip_address:
                    lid = lease.get(".id", "")
                    restore_list = prev_address_list if prev_address_list else ""
                    # Usamos 'address-lists' (plural) para compatibilidad
                    update_params = {"address-lists": restore_list}
                    
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ip/dhcp-server/lease/{lid}/set", update_params)
                    else:
                        MikroTikDriver._legacy_set(api, "/ip/dhcp-server/lease", lid, update_params)
                    
                    print(f"[MK RESTORE DHCP] {ip_address} -> '{restore_list}'")
                    return True

            return False
        except Exception as e:
            print(f"[MK RESTORE DHCP ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def update_dhcp_lease_params(router, address: str, params: Dict) -> bool:
        """Actualiza parámetros de un lease DHCP (ej: rate-limit) buscando por IP"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            leases = MikroTikDriver._legacy_get(api, "/ip/dhcp-server/lease") if not isinstance(api, RestApiWrapper) else api.get("/ip/dhcp-server/lease")
            for lease in leases:
                if lease.get("address") == address:
                    lid = lease.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ip/dhcp-server/lease/{lid}/set", params)
                    else:
                        MikroTikDriver._legacy_set(api, "/ip/dhcp-server/lease", lid, params)
                    return True
            return False
        except Exception as e:
            print(f"[MK UPDATE DHCP ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    # ── PPPoE ─────────────────────────────────────────────────

    @staticmethod
    async def get_pppoe_active(router) -> List[Dict]:
        """Sesiones PPPoE activas en este momento"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/ppp/active")
            return MikroTikDriver._legacy_get(api, "/ppp/active")
        except Exception as e:
            print(f"[MK PPPOE ACTIVE ERROR] {e}")
            return []
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def get_pppoe_secrets(router) -> List[Dict]:
        """Todos los secretos PPPoE configurados"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/ppp/secret")
            return MikroTikDriver._legacy_get(api, "/ppp/secret")
        except Exception as e:
            print(f"[MK PPPOE SECRETS ERROR] {e}")
            return []
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def create_pppoe_secret(router, params: Dict) -> bool:
        """Crea un secret PPPoE (name, password, profile, etc)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            if isinstance(api, RestApiWrapper):
                result = api.post("/ppp/secret/add", params)
                return "ret" in result or ".id" in result
            return MikroTikDriver._legacy_add(api, "/ppp/secret", params)
        except Exception as e:
            print(f"[MK CREATE PPPOE ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def suspend_pppoe_client(router, username: str) -> bool:
        """Deshabilita el secret PPPoE y cierra la sesión activa (corte instantáneo)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            # 1. Deshabilitar Secret
            secrets = MikroTikDriver._legacy_get(api, "/ppp/secret") if not isinstance(api, RestApiWrapper) else api.get("/ppp/secret")
            for s in secrets:
                if s.get("name") == username:
                    sid = s.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ppp/secret/{sid}/disable", {})
                    else:
                        # En librouteros usamos update(disabled=yes)
                        api.path("/ppp/secret").update(**{".id": sid, "disabled": "yes"})
                    print(f"[MK SUSPEND PPPOE] Secret {username} deshabilitado")
                    break

            # 2. Cerrar Sesión Activa (Kick)
            active = MikroTikDriver._legacy_get(api, "/ppp/active") if not isinstance(api, RestApiWrapper) else api.get("/ppp/active")
            for session in active:
                if session.get("name") == username:
                    aid = session.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ppp/active/{aid}/remove", {})
                    else:
                        # En librouteros remove() espera el ID posicional
                        api.path("/ppp/active").remove(aid)
                    print(f"[MK SUSPEND PPPOE] Sesión activa de {username} cerrada (KICK)")

                    break
            
            return True
        except Exception as e:
            print(f"[MK SUSPEND PPPOE ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def restore_pppoe_client(router, username: str) -> bool:
        """Rehabilita el secret PPPoE del cliente"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            secrets = MikroTikDriver._legacy_get(api, "/ppp/secret") if not isinstance(api, RestApiWrapper) else api.get("/ppp/secret")
            for s in secrets:
                if s.get("name") == username:
                    sid = s.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ppp/secret/{sid}/enable", {})
                    else:
                        # En librouteros usamos update(disabled=no)
                        api.path("/ppp/secret").update(**{".id": sid, "disabled": "no"})
                    print(f"[MK RESTORE PPPOE] {username} habilitado")
                    return True
            return False
        except Exception as e:
            print(f"[MK RESTORE PPPOE ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()


    @staticmethod
    async def get_pppoe_profiles(router) -> List[Dict]:
        """Obtiene perfiles PPP con sus rate-limits"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/ppp/profile")
            return MikroTikDriver._legacy_get(api, "/ppp/profile")
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def update_pppoe_profile(router, name: str, params: Dict) -> bool:
        """Actualiza un perfil PPPoE (ej: DNS, Local/Remote Address, Rate-Limit)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            # En MikroTik, los perfiles se listan en /ppp/profile
            profiles = await MikroTikDriver.get_pppoe_profiles(router)
            for p in (profiles or []):
                if p.get("name") == name:
                    pid = p.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ppp/profile/{pid}/set", params)
                    else:
                        MikroTikDriver._legacy_set(api, "/ppp/profile", pid, params)
                    return True
            return False
        except Exception as e:
            print(f"[MK UPDATE PROFILE ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()


    @staticmethod
    async def kick_pppoe_session(router, username: str) -> bool:
        """Remueve una sesión activa para forzar reconexión"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            active = MikroTikDriver._legacy_get(api, "/ppp/active") if not isinstance(api, RestApiWrapper) else api.get("/ppp/active")
            for session in active:
                if session.get("name") == username:
                    sid = session.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        # En REST remove es un POST al path con remove
                        api.post(f"/ppp/active/{sid}/remove", {})
                    else:
                        api.path("/ppp/active").remove(**{".id": sid})
                    return True
            return False
        except Exception as e:
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def update_pppoe_secret(router, username: str, params: Dict) -> bool:
        """Actualiza un secret (ej: cambio de perfil)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            secrets = MikroTikDriver._legacy_get(api, "/ppp/secret") if not isinstance(api, RestApiWrapper) else api.get("/ppp/secret")
            for s in secrets:
                if s.get("name") == username:
                    sid = s.get(".id", "")
                    if isinstance(api, RestApiWrapper):
                        api.post(f"/ppp/secret/{sid}/set", params)
                    else:
                        MikroTikDriver._legacy_set(api, "/ppp/secret", sid, params)
                    return True
            return False
        except Exception as e:
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    # ── Tráfico de Interfaz ───────────────────────────────────

    @staticmethod
    async def get_interface_traffic(router, interface: str = "ether1") -> Dict:
        """Obtiene bytes de TX y RX de una interfaz"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return {}
        try:
            if isinstance(api, RestApiWrapper):
                items = api.get("/interface", **{"name": interface})
            else:
                items = list(api.path("/interface"))
                items = [i for i in items if i.get("name") == interface]
            return items[0] if items else {}
        except Exception as e:
            return {}
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def get_all_interfaces(router) -> List[Dict]:
        brand = getattr(router, "brand", "mikrotik")
        if brand != "mikrotik":
            # SNMP Walk interfaces
            walk = await snmp_walk(router.ip_address, router.snmp_community, ".1.3.6.1.2.1.2.2.1.2", router.snmp_version, router.snmp_port)
            return [{"name": w["value"], "status": "up"} for w in walk]

        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/interface")
            return MikroTikDriver._legacy_get(api, "/interface")
        except Exception:
            return []
        finally:
            if hasattr(api, "close"):
                api.close()

    # ── Backup ────────────────────────────────────────────────

    @staticmethod
    async def run_backup(router, backup_name: str = "") -> bool:
        """Ejecuta backup del router (solo Legacy API)"""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        try:
            name = backup_name or f"omni-backup-{int(time_module.time())}"
            if isinstance(api, RestApiWrapper):
                result = api.post("/system/backup/save", {"name": name})
                return "error" not in result
            list(api.path("/system/backup").save(name=name))
            print(f"[MK BACKUP] {router.name} → {name}")
            return True
        except Exception as e:
            print(f"[MK BACKUP ERROR] {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    # ── Provisioning (PPPoE + DHCP + Queue) ──────────────────

    @staticmethod
    async def provision_pppoe(router, client, plan) -> bool:
        params = {
            "name": client.pppoe_user,
            "password": client.pppoe_pass or "changeme",
            "profile": plan.mikrotik_profile or "default",
            "comment": f"{client.full_name} | {client.dni} | {client.phone}",
            "service": "ppp",
        }
        if client.ip_address:
            params["remote-address"] = client.ip_address
        return await MikroTikDriver.create_pppoe_secret(router, params)

    @staticmethod
    async def provision_dhcp(router, client, plan) -> bool:
        """
        Crea un lease estático en el DHCP server e inyecta el rate-limit del plan
        para que MikroTik genere la cola dinámica automáticamente.
        """
        params = {
            "ip-address": client.ip_address,
            "mac-address": client.mac_address or "00:00:00:00:00:00",
            "server": client.dhcp_server or "all",
            "comment": f"{client.full_name} | {client.dni} | {client.phone}",
            "rate-limit": f"{plan.upload_limit}M/{plan.download_limit}M"
        }
        if client.address_list:
            params["address-lists"] = client.address_list
        return await MikroTikDriver.create_dhcp_lease(router, params)


    # ── Colas Simples (DHCP / Queues) ─────────────────────────
    @staticmethod
    async def get_simple_queues(router) -> List[Dict]:
        """Obtiene todas las colas simples"""
        api = await MikroTikDriver.get_api(router)
        if not api: return []
        try:
            if isinstance(api, RestApiWrapper):
                return api.get("/queue/simple")
            return MikroTikDriver._legacy_get(api, "/queue/simple")
        finally:
            if hasattr(api, "close"): api.close()

    @staticmethod
    async def activate_client(router, ip_address: str, prev_address_list: str = "") -> bool:
        """Activa cliente (wrapper para pagos)"""
        return await MikroTikDriver.restore_dhcp_client(router, ip_address, prev_address_list)


    @staticmethod
    async def get_client_traffic_realtime(router, client) -> Dict:
        """
        Obtiene el consumo en tiempo real usando SNMP para máxima compatibilidad con hardware Mikrotik/Huawei/Cisco.
        """
        from backend.snmp_core import snmp_get, snmp_walk, OID_IF_IN, OID_IF_OUT, OID_IF_DESCR
        
        host = router.ip_address
        comm = getattr(router, "snmp_community", "public")
        ver  = getattr(router, "snmp_version", "v2c")
        port = getattr(router, "snmp_port", 161)
        
        tx_bytes = 0
        rx_bytes = 0
        online = False
        
        router_id = str(getattr(router, "id", "local"))
        client_key = f"{router_id}_{client.id}"
        
        # 1. Intentar encontrar el ifIndex (Índice SNMP de la interfaz)
        ifIndex = MikroTikDriver._client_ifindex_cache.get(client_key)
        
        # Si no hay cache o han pasado 5 minutos, refrescamos el mapeo de interfaces
        now = time_module.time()
        cache_age = now - MikroTikDriver._client_ifindex_cache_ts.get(client_key, 0)
        
        if not ifIndex or cache_age > 300:
            user_clean = str(client.pppoe_user or client.ip_address).strip().lower()
            # Caminar por las descripciones de interfaz para encontrar la correcta
            descriptions = await snmp_walk(host, comm, OID_IF_DESCR, ver, port)
            for d in descriptions:
                # En MikroTik las interfaces PPPoE suelen llamarse <pppoe-usuario>
                # En otros hardwares puede ser Virtual-AccessX o simplemente el nombre
                d_val = d["value"].strip().lower()
                if user_clean in d_val or d_val.startswith(f"<pppoe-{user_clean}>"):
                    ifIndex = d["oid"].split(".")[-1]
                    MikroTikDriver._client_ifindex_cache[client_key] = ifIndex
                    MikroTikDriver._client_ifindex_cache_ts[client_key] = now
                    break
        
        if ifIndex:
            # 2. Pollear contadores de bytes por SNMP
            # RX_OID = 1.3.6.1.2.1.2.2.1.10.<index>
            # TX_OID = 1.3.6.1.2.1.2.2.1.16.<index>
            rx_oid = f"{OID_IF_IN}.{ifIndex}"
            tx_oid = f"{OID_IF_OUT}.{ifIndex}"
            
            res_rx, res_tx = await asyncio.gather(
                snmp_get(host, comm, rx_oid, ver, port),
                snmp_get(host, comm, tx_oid, ver, port)
            )
            
            if res_rx and res_tx:
                online = True
                rx_bytes = int(res_rx)
                tx_bytes = int(res_tx)
        
        # 3. Fallback a API si SNMP falla o no se encontró el índice
        if not online:
            api = await MikroTikDriver.get_api(router)
            if api:
                try:
                    if client.connection_type == "PPPOE" and client.pppoe_user:
                        sessions = api.get("/ppp/active") if isinstance(api, RestApiWrapper) else list(api.path("/ppp/active"))
                        user_clean = client.pppoe_user.strip().lower()
                        session = next((s for s in sessions if str(s.get("name", "")).strip().lower() == user_clean), None)
                        if session:
                            online = True
                            tx_bytes = int(session.get("bytes-out", session.get("bytes-out-64", 0)) or 0)
                            rx_bytes = int(session.get("bytes-in", session.get("bytes-in-64", 0)) or 0)
                except: pass
                finally:
                    if hasattr(api, "close"): api.close()

        # Cálculo de Rate (Mbps)
        prev = MikroTikDriver._client_traffic_cache.get(client_key)
        tx_mbps = rx_mbps = 0.0
        
        if prev and online:
            dt = now - prev["ts"]
            if dt > 0.1:
                # Nota: En SNMP, IF_OUT es Download para el cliente e IF_IN es Upload
                tx_mbps = max(0, (tx_bytes - prev["tx"]) * 8 / (1024 * 1024) / dt)
                rx_mbps = max(0, (rx_bytes - prev["rx"]) * 8 / (1024 * 1024) / dt)
        
        if online:
            MikroTikDriver._client_traffic_cache[client_key] = {"ts": now, "tx": tx_bytes, "rx": rx_bytes}
        
        return {
            "download_mb": round(tx_bytes / (1024 * 1024), 2),
            "upload_mb": round(rx_bytes / (1024 * 1024), 2),
            "download_mbps": round(tx_mbps, 3),
            "upload_mbps": round(rx_mbps, 3),
            "online": online,
            "timestamp": now,
            "source": "snmp" if ifIndex else "api"
        }

    _client_traffic_cache: Dict[str, Dict] = {}
    _client_ifindex_cache: Dict[str, str] = {}
    _client_ifindex_cache_ts: Dict[str, float] = {}

    @staticmethod
    async def get_client_telemetry(router, ip_address: str) -> Dict:
        """
        Obtiene telemetría en tiempo real de un cliente por su IP.
        Verifica presencia en DHCP leases y sesiones PPPoE activas.
        Realiza una sonda TCP para estimar latencia.
        """
        import socket as _socket
        import time as _time

        # Buscar en DHCP leases y sesiones PPPoE en paralelo
        leases, sessions = await asyncio.gather(
            MikroTikDriver.get_dhcp_leases(router),
            MikroTikDriver.get_pppoe_active(router),
        )

        lease_entry = next((l for l in leases if l.get("address") == ip_address), None)
        pppoe_entry = next((s for s in sessions if s.get("address") == ip_address), None)
        entry = lease_entry or pppoe_entry or {}
        is_online = bool(entry)

        # Sonda TCP para estimar latencia (puerto 80; silencioso si rechazado)
        latency_ms: Optional[float] = None
        if is_online:
            def _tcp_probe():
                try:
                    t0 = _time.monotonic()
                    sock = _socket.create_connection((ip_address, 80), timeout=2)
                    elapsed = (_time.monotonic() - t0) * 1000
                    sock.close()
                    return round(elapsed, 1)
                except Exception:
                    return None  # Puerto cerrado no significa offline

            loop = asyncio.get_event_loop()
            latency_ms = await loop.run_in_executor(executor, _tcp_probe)

        return {
            "status": "ONLINE" if is_online else "OFFLINE",
            "is_router_online": is_online,
            "latency_ms": latency_ms,
            "signal_dbm": None,  # La señal óptica es responsabilidad del OLTDriver
            "ip_address": ip_address,
            "mac_address": entry.get("mac-address", ""),
            "uptime": entry.get("uptime", ""),
        }

    # ── Buscar por comentario ─────────────────────────────────

    @staticmethod
    async def find_lease_by_comment(router, keyword: str) -> Optional[Dict]:
        """Busca un lease dinámico cuyo comentario contenga el keyword (nombre, cédula)"""
        leases = await MikroTikDriver.get_dhcp_leases(router)
        keyword_lower = keyword.lower()
        for lease in leases:
            comment = lease.get("comment", "").lower()
            if keyword_lower in comment:
                return lease
        return None

    # ── Tráfico PPPoE por sesión (Tx/Rx Rate + Packet Rate) ──

    @staticmethod
    async def get_pppoe_traffic(router) -> List[Dict]:
        """
        Retorna las sesiones PPPoE activas enriquecidas con:
          - tx-rate-bps  / rx-rate-bps   (bits/s calculados del delta de bytes-out/in)
          - tx-pkt-rate  / rx-pkt-rate   (paquetes/s calculados del delta de packets-out/in)
          - tx-bytes     / rx-bytes      (acumulados de la sesión)
          - tx-packets   / rx-packets    (acumulados)

        El primer poll sólo tiene acumulados. Con el segundo poll (5 s después) se
        calculan los rates. Internamente se usa el caché _pppoe_cache para el delta.
        """
        api = await MikroTikDriver.get_api(router)
        if not api:
            return []
        try:
            if isinstance(api, RestApiWrapper):
                sessions = api.get("/ppp/active")
            else:
                sessions = list(api.path("/ppp/active"))
        except Exception as e:
            print(f"[MK PPPOE TRAFFIC ERROR] {e}")
            return []
        finally:
            if hasattr(api, "close"):
                api.close()

        now = time_module.time()
        router_key = getattr(router, "id", str(router.ip_address))
        cache = MikroTikDriver._pppoe_cache.get(router_key, {})

        result = []
        new_cache: Dict[str, Dict] = {}

        for s in sessions:
            name = s.get("name", "")
            tx_bytes  = int(s.get("bytes-out", 0)   or 0)
            rx_bytes  = int(s.get("bytes-in",  0)   or 0)
            tx_pkts   = int(s.get("packets-out", 0) or 0)
            rx_pkts   = int(s.get("packets-in",  0) or 0)

            prev = cache.get(name)
            tx_rate_bps = rx_rate_bps = tx_pkt_rate = rx_pkt_rate = 0.0

            if prev:
                dt = now - prev["ts"]
                if dt > 0:
                    tx_rate_bps  = max(0, (tx_bytes - prev["tx_bytes"]) * 8 / dt)
                    rx_rate_bps  = max(0, (rx_bytes - prev["rx_bytes"]) * 8 / dt)
                    tx_pkt_rate  = max(0, (tx_pkts  - prev["tx_pkts"])  / dt)
                    rx_pkt_rate  = max(0, (rx_pkts  - prev["rx_pkts"])  / dt)

            new_cache[name] = {
                "ts": now,
                "tx_bytes": tx_bytes, "rx_bytes": rx_bytes,
                "tx_pkts":  tx_pkts,  "rx_pkts":  rx_pkts,
            }

            result.append({
                **s,
                # Tx/Rx Rate
                "tx-rate-bps":   round(tx_rate_bps),
                "rx-rate-bps":   round(rx_rate_bps),
                "tx-rate-mbps":  round(tx_rate_bps  / 1_000_000, 3),
                "rx-rate-mbps":  round(rx_rate_bps  / 1_000_000, 3),
                "tx-rate-kbps":  round(tx_rate_bps  / 1_000, 1),
                "rx-rate-kbps":  round(rx_rate_bps  / 1_000, 1),
                # Packet Rate
                "tx-pkt-rate":   round(tx_pkt_rate, 1),
                "rx-pkt-rate":   round(rx_pkt_rate, 1),
                # Acumulados
                "tx-bytes":  tx_bytes,
                "rx-bytes":  rx_bytes,
                "tx-packets": tx_pkts,
                "rx-packets": rx_pkts,
            })

        MikroTikDriver._pppoe_cache[router_key] = new_cache
        return result

    # Cache de estado anterior para cálculo de rates (dict de router_id → {user → snapshot})
    _pppoe_cache: Dict[str, Dict] = {}

    # ─────────────────────────────────────────────────────────────
    # OMNI-SHIELD: NEURAL MITIGATION ENGINE
    # ─────────────────────────────────────────────────────────────

    @staticmethod
    async def activate_neural_shield(router) -> bool:
        """
        Activates the OMNI-SHIELD mitigation layer on the target router.
        Currently implements a RAW Firewall Drop rule for UDP traffic.
        """
        print(f"[OMNI-SHIELD] EXECUTING ACTIVE MITIGATION on {router.name} ({router.ip_address})")
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        
        try:
            # We use RAW firewall to drop traffic without hitting the connection tracker (lower CPU)
            params = {
                "chain": "prerouting",
                "action": "drop",
                "protocol": "udp",
                "comment": "OMNI-SHIELD: ACTIVE_MITIGATION"
            }
            
            if isinstance(api, RestApiWrapper):
                # REST API Check if already exists to avoid duplicates
                existing = api.get("/ip/firewall/raw", **{"comment": "OMNI-SHIELD: ACTIVE_MITIGATION"})
                if not existing:
                    api.post("/ip/firewall/raw/add", params)
            else:
                # Legacy API check
                existing = [r for r in list(api.path("/ip/firewall/raw")) if r.get("comment") == "OMNI-SHIELD: ACTIVE_MITIGATION"]
                if not existing:
                    api.path("/ip/firewall/raw").add(**params)
            
            print(f"[OMNI-SHIELD] Shield ACTIVE on {router.name}")
            return True
        except Exception as e:
            print(f"[OMNI-SHIELD] Shield activation FAILED on {router.name}: {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def deactivate_neural_shield(router) -> bool:
        """Removes the OMNI-SHIELD mitigation rules."""
        api = await MikroTikDriver.get_api(router)
        if not api:
            return False
        
        try:
            if isinstance(api, RestApiWrapper):
                rules = api.get("/ip/firewall/raw", **{"comment": "OMNI-SHIELD: ACTIVE_MITIGATION"})
                for r in rules:
                    rid = r.get(".id")
                    api.post(f"/ip/firewall/raw/{rid}/remove", {})
            else:
                rules = [r for r in list(api.path("/ip/firewall/raw")) if r.get("comment") == "OMNI-SHIELD: ACTIVE_MITIGATION"]
                for r in rules:
                    api.path("/ip/firewall/raw").remove(**{".id": r.get(".id")})
            
            print(f"[OMNI-SHIELD] Shield deactivated on {router.name}")
            return True
        except Exception as e:
            print(f"[OMNI-SHIELD] Shield deactivation ERROR: {e}")
            return False
        finally:
            if hasattr(api, "close"):
                api.close()

    @staticmethod
    async def get_snmp_interfaces(router) -> List[Dict]:
        """Descubre interfaces físicas y sus IDs SNMP."""
        host = router.ip_address
        comm = getattr(router, "snmp_community", "public")
        ver = getattr(router, "snmp_version", "v2c")
        port = getattr(router, "snmp_port", 161)
        
        walk_data = await snmp_walk(host, community=comm, oid=OID_IF_DESCR, version=ver, port=port)
        interfaces = []
        for item in walk_data:
            idx = item["oid"].split(".")[-1]
            interfaces.append({
                "id": idx,
                "name": item["value"]
            })
        return interfaces

    @staticmethod
    async def get_snmp_telemetry(router, interface_idx: str = "1") -> Dict:
        """Obtiene telemetría avanzada vía SNMP."""
        host = router.ip_address
        comm = getattr(router, "snmp_community", "public")
        ver = getattr(router, "snmp_version", "v2c")
        port = getattr(router, "snmp_port", 161)

        oid_in = f"{OID_IF_IN}.{interface_idx}"
        oid_out = f"{OID_IF_OUT}.{interface_idx}"

        cpu_task = snmp_get(host, comm, OID_CPU_LOAD, ver, port)
        mem_total_task = snmp_get(host, comm, OID_MEMORY_TOTAL, ver, port)
        mem_used_task = snmp_get(host, community=comm, oid=OID_MEMORY_USED, version=ver, port=port)
        uptime_task = snmp_get(host, community=comm, oid=OID_UPTIME, version=ver, port=port)
        in_task = snmp_get(host, community=comm, oid=oid_in, version=ver, port=port)
        out_task = snmp_get(host, community=comm, oid=oid_out, version=ver, port=port)

        results = await asyncio.gather(cpu_task, mem_total_task, mem_used_task, uptime_task, in_task, out_task)
        
        cpu = results[0]
        m_total = results[1]
        m_used = results[2]
        uptime = results[3]
        if_in = results[4]
        if_out = results[5]

        ram_percent = 0
        if m_total and m_used and int(m_total) > 0:
            ram_percent = round((int(m_used) / int(m_total)) * 100, 1)

        return {
            "cpu_load": int(cpu) if cpu else 0,
            "ram_usage_percent": ram_percent,
            "uptime": uptime or "0",
            "traffic_in_bytes": int(if_in) if if_in else 0,
            "traffic_out_bytes": int(if_out) if if_out else 0,
            "interface_idx": interface_idx,
            "timestamp": time_module.time()
        }
