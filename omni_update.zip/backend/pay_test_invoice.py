import asyncio
from backend.database import engine
from sqlmodel import Session, select
from backend.models import Invoice, PaymentReceipt
from backend.billing_api import approve_receipt, ReviewReceiptSchema

async def main():
    with Session(engine) as session:
        # Buscamos la factura #4
        invoice = session.get(Invoice, 4)
        if not invoice:
            print("No se encontro la factura #4")
            return
            
        print(f"Simulando pago para factura #{invoice.id}...")
        
        # Crear recibo
        receipt = PaymentReceipt(
            invoice_id=invoice.id,
            client_id=invoice.client_id,
            bank="BANESCO",
            reference_number="RECONNECT_TEST_999",
            amount_paid_bs=1.0,
            status="PENDIENTE"
        )
        session.add(receipt)
        session.commit()
        session.refresh(receipt)
        
        # Aprobar recibo para disparar la restauración
        print("Aprobando recibo para reconectar...")
        await approve_receipt(
            receipt.id, 
            ReviewReceiptSchema(reviewer="ROOT_SYSTEM", notes="Prueba de reconexion automatica"), 
            session=session
        )
        print("PROCESO DE RECONEXION DISPARADO")

if __name__ == "__main__":
    asyncio.run(main())
