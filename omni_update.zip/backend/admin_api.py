"""
Admin API — Gestión de hardware: Routers, OLTs, MikroTik completo
"""
from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, BackgroundTasks, Query
from sqlmodel import Session, select, delete
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import datetime
import json
import re
import asyncio
import pandas as pd
import random
import string

from backend.models import (
    Client, Router, Plan, RouterCreate, OLT, ONU, OLTCreate,
    MikrotikPendingChange, Staff, SystemConfig, SupportTicket, TicketMessage,
    MikrotikHardwareRecord, Invoice, PaymentReceipt, Transaction, DailyConsumption, NotificationLog, ONUSignalHistory
)

from backend.database import get_session
from backend.mikrotik_driver import MikroTikDriver, RestApiWrapper
from backend.olt_driver import OLTDriver
from backend.state import OLT_STATUS_CACHE
from backend.onu_live_cache import get_olt_snmp_lock, cache_get, cache_set, cache_delete
from backend.notifications import NotificationDispatcher, EVENTS
import pandas as pd
import string, random, os

router = APIRouter(prefix="/api/v2/admin", tags=["admin-hardware"])


# ─────────────────────────────────────────────
# CLIENTS CRUD
# ─────────────────────────────────────────────

@router.get("/clients")
async def list_clients(
    status: Optional[str] = None,
    connection_type: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """Lista todos los clientes. Soporta filtros por status y connection_type."""
    query = select(Client)
    if status:
        query = query.where(Client.status == status)
    if connection_type:
        query = query.where(Client.connection_type == connection_type)
    clients = session.exec(query.order_by(Client.full_name)).all()
    return clients

@router.get("/clients/{client_id}")
async def get_client(client_id: int, session: Session = Depends(get_session)):
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    return client

@router.put("/clients/{client_id}")
async def update_client(client_id: int, data: dict, session: Session = Depends(get_session)):
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    for k, v in data.items():
        if hasattr(client, k) and k not in ("id", "created_at"):
            # Detect plan change
            if k == "plan_id" and getattr(client, k) != v:
                await NotificationDispatcher.dispatch(
                    EVENTS["PLAN_CHANGED"],
                    f"Cambio de plan para {client.full_name}. De ID {getattr(client, k)} a {v}.",
                    session,
                    client_id=client.id
                )
            setattr(client, k, v)
    client.updated_at = datetime.utcnow()
    session.add(client)
    session.commit()
    session.refresh(client)
    return client
 
@router.delete("/clients/{client_id}")
async def delete_client(client_id: int, session: Session = Depends(get_session)):
    """Elimina un cliente y todos sus registros asociados."""
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
        
    try:
        # 1. BORRADO EN HARDWARE (MikroTik)
        if client.router_id:
            from backend.mikrotik_driver import MikroTikDriver
            from backend.models import Router
            router_obj = session.get(Router, client.router_id)
            if router_obj:
                if client.connection_type == "PPPOE" and client.pppoe_user:
                    await MikroTikDriver.delete_pppoe_secret(router_obj, client.pppoe_user)
                elif client.connection_type == "DHCP" and client.ip_address:
                    await MikroTikDriver.delete_dhcp_lease(router_obj, client.ip_address)
        
        # 2. (OPCIONAL) BORRADO EN HARDWARE (OLT)
        # Falta implementar delete_onu con SNMP RowStatus(6). 
        # Por ahora solo borramos del MikroTik para evitar zombies.

        # 3. Limpiar registros dependientes de la Base de Datos
        session.exec(delete(Invoice).where(Invoice.client_id == client_id))
        session.exec(delete(PaymentReceipt).where(PaymentReceipt.client_id == client_id))
        session.exec(delete(Transaction).where(Transaction.client_id == client_id))
        session.exec(delete(SupportTicket).where(SupportTicket.client_id == client_id))
        session.exec(delete(DailyConsumption).where(DailyConsumption.client_id == client_id))
        session.exec(delete(NotificationLog).where(NotificationLog.client_id == client_id))
        
        # 4. Finalmente eliminar al cliente
        session.delete(client)
        session.commit()
        return {"status": "SUCCESS", "message": f"Cliente {client_id} y sus datos asociados han sido eliminados."}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=f"Error al eliminar cliente: {str(e)}")

@router.get("/clients/{client_id}/live-traffic")
async def get_client_live_traffic(client_id: int, session: Session = Depends(get_session)):
    """Tráfico en tiempo real para un cliente específico (Mbps)."""
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    
    router_obj = session.get(Router, client.router_id)
    if not router_obj:
        return {"download_mbps": 0, "upload_mbps": 0, "online": False}
        
    traffic = await MikroTikDriver.get_client_traffic_realtime(router_obj, client)
    return traffic



# ─────────────────────────────────────────────
# PLANS CRUD
# ─────────────────────────────────────────────

@router.get("/plans")
async def list_plans(session: Session = Depends(get_session)):
    """Lista todos los planes disponibles."""
    plans = session.exec(select(Plan).order_by(Plan.price)).all()
    return plans

@router.post("/plans")
async def create_plan(data: dict, session: Session = Depends(get_session)):
    plan = Plan(
        name=data.get("name", "Nuevo Plan"),
        price=float(data.get("price", 10.0)),
        download_limit=int(data.get("download_limit", 10)),
        upload_limit=int(data.get("upload_limit", 5)),
        mikrotik_profile=data.get("mikrotik_profile", "default"),
        mikrotik_rate_limit=data.get("mikrotik_rate_limit"),
    )
    session.add(plan)
    session.commit()
    session.refresh(plan)
    return plan

@router.delete("/plans/{plan_id}")
async def delete_plan(plan_id: int, session: Session = Depends(get_session)):
    plan = session.get(Plan, plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan no encontrado")
    session.delete(plan)
    session.commit()
    return {"status": "deleted"}


# ─────────────────────────────────────────────
# PROVISIONING
# ─────────────────────────────────────────────

@router.post("/provision/{client_id}")
async def provision_client_hardware(client_id: int, session: Session = Depends(get_session)):
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    router_obj = session.get(Router, client.router_id)
    plan = session.get(Plan, client.plan_id)
    if not router_obj or not plan:
        raise HTTPException(status_code=400, detail="Missing linked router or plan")

    results = {"pppoe": None, "dhcp": None, "qos": "DYNAMIC"}
    if client.connection_type == "PPPOE":
        results["pppoe"] = await MikroTikDriver.provision_pppoe(router_obj, client, plan)
    elif client.connection_type == "DHCP":
        results["dhcp"] = await MikroTikDriver.provision_dhcp(router_obj, client, plan)

    return {"status": "PROVISIONED", "client": client.full_name, "actions": results}
    

# ─────────────────────────────────────────────
# SYSTEM & SCHEDULER MONITORING
# ─────────────────────────────────────────────

@router.get("/system/status")
async def get_system_status(session: Session = Depends(get_session)):
    """Estado de salud del motor de automatización y servicios base"""
    keys = [
        "scheduler_last_suspension_date",
        "scheduler_last_billing_month",
        "scheduler_last_bcv_hour",
        "scheduler_last_discovery_date"
    ]
    configs = session.exec(select(SystemConfig).where(SystemConfig.key.in_(keys))).all()
    status_map = {c.key: c.value for c in configs}
    
    return {
        "engine": "OMNI-V2-AUTONOMOUS",
        "scheduler_status": "ACTIVE",
        "last_runs": {
            "overdue_suspension": status_map.get("scheduler_last_suspension_date", "NEVER"),
            "monthly_billing": status_map.get("scheduler_last_billing_month", "NEVER"),
            "bcv_refresh": status_map.get("scheduler_last_bcv_hour", "NEVER"),
            "auto_discovery": status_map.get("scheduler_last_discovery_date", "NEVER")
        },
        "server_time": datetime.utcnow().isoformat()
    }


@router.post("/import-clients-local-csv")
async def import_clients_local_csv(session: Session = Depends(get_session)):
    csv_path = r"c:\laragon\www\X\uploads\base de datos clientes cvs\Base de Datos Clientes - clientes.csv"
    if not os.path.exists(csv_path):
        raise HTTPException(status_code=404, detail="CSV local no encontrado en la ruta de uploads.")

    df = pd.read_csv(csv_path).fillna("")

    # Asegurarnos de tener el "VIRTUAL_CSV_ROUTER"
    virtual_router = session.exec(select(Router).where(Router.name == "VIRTUAL_CSV_ROUTER")).first()
    if not virtual_router:
        virtual_router = Router(
            name="VIRTUAL_CSV_ROUTER",
            ip_address="127.0.0.1",
            username="virtual",
            password="csv",
            status="OFFLINE",
            connection_mode="API"
        )
        session.add(virtual_router)
        session.commit()
        session.refresh(virtual_router)

    # Obtener el máximo ID existente para generar IPs consecutivas únicas
    from sqlalchemy import text as sql_text
    max_id_res = session.exec(sql_text("SELECT MAX(id) FROM client")).first()
    base_ip_offset = (max_id_res[0] or 0) + 1

    created_count = 0
    updated_count = 0
    errors = []

    for idx, row in df.iterrows():
        try:
            cedula = str(row.get("cedula", "")).strip()
            if not cedula or cedula == "nan":
                continue

            nombres   = str(row.get("nombres",   "")).strip()
            apellidos = str(row.get("apellidos", "")).strip()
            full_name = f"{nombres} {apellidos}".strip() or f"Cliente {cedula}"

            # ── Detectar tipo de conexión desde el CSV ──────────────────
            conn_csv = str(row.get("tipo_conexion", row.get("tipo", row.get("conexion", "")))).upper().strip()
            if any(x in conn_csv for x in ["PPP", "SECRET"]):
                conn_type = "PPPOE"
            elif any(x in conn_csv for x in ["DHCP", "BOUND", "LEASE", "IP"]):
                conn_type = "DHCP"
            else:
                conn_type = "DHCP"   # Cambiamos a DHCP por defecto si no es explícitamente PPP


            # ── Detectar IP desde el CSV o generar una ficticia única ────
            ip_csv = str(row.get("ip", row.get("ip_address", row.get("direccion_ip", "")))).strip()
            if ip_csv and ip_csv not in ("", "nan", "0.0.0.0"):
                # Validar formato básico
                parts = ip_csv.split(".")
                ip_address = ip_csv if len(parts) == 4 else None
            else:
                ip_address = None

            if not ip_address:
                # Generar IP ficticia única en rango 10.255.x.x
                ip_val = base_ip_offset + idx
                b3 = (ip_val // 254) % 254 + 1
                b4 = (ip_val % 254) + 1
                ip_address = f"10.255.{b3}.{b4}"

            # Asegurar unicidad de IP en caso de colisión
            ip_conflict = session.exec(select(Client).where(Client.ip_address == ip_address)).first()
            if ip_conflict and ip_conflict.dni != cedula:
                ip_address = f"10.254.{(base_ip_offset + idx) % 254 + 1}.{(base_ip_offset + idx * 7) % 254 + 1}"

            # ── Plan ─────────────────────────────────────────────────────
            plan_name      = str(row.get("plan", "Plan Basico")).strip() or "Plan Basico"
            plan_price_str = str(row.get("precio", "0")).replace("$", "").strip()
            try:
                plan_price = float(plan_price_str)
            except (ValueError, TypeError):
                plan_price = 15.0

            db_plan = session.exec(select(Plan).where(Plan.name == plan_name)).first()
            if not db_plan:
                db_plan = Plan(
                    name=plan_name,
                    price=plan_price,
                    download_limit=10,
                    upload_limit=5,
                    mikrotik_profile="default",
                )
                session.add(db_plan)
                session.commit()
                session.refresh(db_plan)

            # ── PPPoE credentials ─────────────────────────────────────────
            pppoe_user_csv = str(row.get("usuario_pppoe", row.get("usuario", ""))).strip()
            pppoe_pass_csv = str(row.get("password_pppoe", row.get("clave", row.get("pass", "")))).strip()

            first = nombres.split(" ")[0].lower() if nombres else "user"
            last  = apellidos.split(" ")[0].lower() if apellidos else cedula[:4]
            pppoe_user = pppoe_user_csv if pppoe_user_csv and pppoe_user_csv != "nan" else f"{first}.{last}"
            pppoe_pass = pppoe_pass_csv if pppoe_pass_csv and pppoe_pass_csv != "nan" else \
                         ''.join(random.choices(string.ascii_letters + string.digits, k=8))

            # ── Insertar o actualizar ──────────────────────────────────────
            existing = session.exec(select(Client).where(Client.dni == cedula)).first()
            if existing:
                # Actualizar datos del existente
                if not existing.phone:
                    existing.phone = str(row.get("telefono 1", "")).strip()
                if not existing.address:
                    existing.address = str(row.get("direccion", "")).strip()
                
                # ACTUALIZACIÓN CRÍTICA: Sincronizar tipo de conexión y plan si vienen en el CSV
                existing.connection_type = conn_type
                existing.plan_id = db_plan.id
                
                session.add(existing)
                updated_count += 1

            else:
                new_client = Client(
                    full_name=full_name,
                    dni=cedula,
                    email=str(row.get("correo", "")).strip() or f"{cedula}@omni.net",
                    phone=str(row.get("telefono 1", "")).strip(),
                    address=str(row.get("direccion", "")).strip(),
                    ip_address=ip_address,
                    plan_id=db_plan.id,
                    router_id=virtual_router.id,
                    connection_type=conn_type,
                    pppoe_user=pppoe_user,
                    pppoe_pass=pppoe_pass,
                    status="MIGRATED"
                )
                session.add(new_client)
                created_count += 1

            # Commit individual por fila para evitar rollback masivo
            session.commit()

        except Exception as e:
            session.rollback()
            errors.append(f"Fila {idx} (cédula={row.get('cedula','?')}): {str(e)}")

    return {
        "status": "MIGRATED_OK",
        "created": created_count,
        "updated": updated_count,
        "total_rows": len(df),
        "errors_count": len(errors),
        "errors": errors[:20],   # Solo primeros 20 errores para no saturar
    }

@router.post("/import-google-sheets")
async def import_google_sheets(session: Session = Depends(get_session)):
    """Importa clientes desde una Google Sheet pública configurada en los ajustes."""
    # 1. Obtener URL de la configuración
    config = session.exec(select(SystemConfig).where(SystemConfig.key == "google_sheets_url")).first()
    if not config or not config.value:
        raise HTTPException(status_code=400, detail="URL de Google Sheets no configurada en Ajustes > Sistema.")

    url = config.value.strip()
    
    # 2. Transformar URL a formato CSV
    # 2. Transformar URL a formato CSV export
    # Maneja casos como /edit, /view, o enlaces directos
    if "docs.google.com/spreadsheets" in url:
        if "/edit" in url:
            base = url.split("/edit")[0]
        elif "/view" in url:
            base = url.split("/view")[0]
        else:
            base = url.rstrip("/")
            
        gid = "0"
        match = re.search(r"gid=(\d+)", url)
        if match: gid = match.group(1)
        import_url = f"{base}/export?format=csv&gid={gid}"
    else:
        import_url = url

    try:
        # 3. Descargar y procesar con Pandas
        # Usamos un timeout implícito o simplemente delegamos a la red local
        df = pd.read_csv(import_url).fillna("")
        
        # Router virtual para importaciones
        virtual_router = session.exec(select(Router).where(Router.name == "VIRTUAL_GSHEETS_ROUTER")).first()
        if not virtual_router:
            virtual_router = Router(
                name="VIRTUAL_GSHEETS_ROUTER", ip_address="127.0.0.1", username="virtual", password="gs",
                status="OFFLINE", connection_mode="API"
            )
            session.add(virtual_router)
            session.commit()
            session.refresh(virtual_router)

        from sqlalchemy import text as sql_text
        max_id_res = session.exec(sql_text("SELECT MAX(id) FROM client")).first()
        base_ip_offset = (max_id_res[0] or 0) + 1

        created = 0
        updated = 0
        skipped = 0
        errors = []

        for idx, row in df.iterrows():
            try:
                # Normalizar nombres de columnas a minúsculas para mayor flexibilidad
                # (Google Sheets a veces capitaliza los headers)
                row_data = {str(k).lower().strip(): v for k, v in row.to_dict().items()}
                
                cedula = str(row_data.get("cedula", row_data.get("dni", ""))).strip()
                if not cedula or cedula in ("nan", ""):
                    continue

                # VERIFICACIÓN DE DUPLICADOS (Requisito del usuario)
                existing = session.exec(select(Client).where(Client.dni == cedula)).first()
                if existing:
                    # Si ya existe, podemos optar por actualizar o saltar.
                    # El usuario pidió "verifique si ya existen para no duplicarlos", 
                    # usualmente significa saltar o actualizar campos vacíos.
                    skipped += 1
                    continue

                nombres = str(row_data.get("nombres", "")).strip()
                apellidos = str(row_data.get("apellidos", "")).strip()
                full_name = f"{nombres} {apellidos}".strip() or f"Cliente {cedula}"

                conn_csv = str(row_data.get("tipo_conexion", row_data.get("tipo", ""))).upper().strip()
                conn_type = "PPPOE" if "PPP" in conn_csv else "DHCP"

                # Generar IP única
                ip_val = base_ip_offset + idx
                ip_address = f"10.253.{(ip_val // 254) % 254 + 1}.{(ip_val % 254) + 1}"

                # Plan lookup
                # Plan lookup (Case Insensitive)
                plan_name = str(row_data.get("plan", row_data.get("plan_name", "Plan Basico"))).strip()
                from sqlalchemy import func
                db_plan = session.exec(select(Plan).where(func.lower(Plan.name) == plan_name.lower())).first()
                if not db_plan:
                    db_plan = session.exec(select(Plan)).first() # Default al primero si no existe
                
                # Fallback de ID seguro
                plan_id_final = db_plan.id if db_plan else (session.exec(select(Plan.id)).first() or 1)

                new_client = Client(
                    full_name=full_name, dni=cedula,
                    email=str(row_data.get("correo", row_data.get("email", ""))).strip() or f"{cedula}@omni.net",
                    phone=str(row_data.get("telefono", row_data.get("phone", ""))).strip(),
                    address=str(row_data.get("direccion", row_data.get("address", ""))).strip(),
                    ip_address=ip_address,
                    plan_id=plan_id_final,
                    router_id=virtual_router.id,
                    connection_type=conn_type,
                    pppoe_user=f"{nombres.split(' ')[0].lower()}.{cedula[-4:]}" if conn_type == "PPPOE" else None,
                    pppoe_pass=''.join(random.choices(string.ascii_letters + string.digits, k=8)),
                    status="MIGRATED"
                )
                session.add(new_client)
                created += 1
                session.commit()
            except Exception as e:
                session.rollback()
                errors.append(f"Fila {idx}: {str(e)}")

        return {
            "status": "SUCCESS",
            "created": created,
            "skipped_duplicates": skipped,
            "errors": errors[:10]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error procesando Google Sheet: {str(e)}")




@router.post("/mikrotik/{router_id}/sync-plans")
async def sync_mikrotik_plans(router_id: int, session: Session = Depends(get_session)):
    """Escanea perfiles PPPoE y crea planes en la DB basados en rate-limit."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    profiles = await MikroTikDriver.get_pppoe_profiles(router_obj)
    if profiles is None:
        raise HTTPException(status_code=503, detail="No se pudo obtener perfiles del MikroTik")

    synced = []
    
    # Mapeo de precios estandarizados
    price_map = {
        "BRONCE": 10.0,
        "PLATA": 15.0,
        "ORO": 20.0,
        "PLATINO": 25.0,
        "DIAMANTE": 30.0,
        "TITANIO": 35.0,
        "PYME": 40.0,
        "PYMES": 40.0,
        "EMPRESARIAL": 60.0,
        "CORPORATIVO": 100.0
    }

    # Identificar nombres de perfiles válidos del MikroTik para limpieza
    valid_names = []

    for p in profiles:
        name = p.get("name", "Unknown").upper()
        if name == "PYMES": name = "PYME"
        
        # Evitar perfiles default ruidosos
        if name in ("DEFAULT", "DEFAULT-ENCRYPTION"):
            continue
            
        valid_names.append(name)
        rate_limit = p.get("rate-limit", "10M/10M") # Default si no tiene
        
        existing = session.exec(select(Plan).where(Plan.name == name)).first()
        price = price_map.get(name, 20.0)

        # Intentar extraer download/upload referencial para el modelo
        try:
            parts = rate_limit.split(" ")
            main_rates = parts[0].split("/")
            tx = int(main_rates[0].lower().replace("k", "")) / 1024 if "k" in main_rates[0].lower() else int(main_rates[0].replace("M", ""))
            rx = int(main_rates[1].lower().replace("k", "")) / 1024 if "k" in main_rates[1].lower() else int(main_rates[1].replace("M", ""))
        except:
            tx, rx = 10, 10

        if existing:
            existing.mikrotik_rate_limit = rate_limit
            existing.mikrotik_profile = p.get("name")
            existing.upload_limit = int(tx)
            existing.download_limit = int(rx)
            # Solo actualizamos el precio si es el default (no editado por usuario)
            if existing.price == 20.0 or name in price_map:
                existing.price = price
            session.add(existing)
        else:
            new_plan = Plan(
                name=name,
                price=price,
                download_limit=int(rx),
                upload_limit=int(tx),
                mikrotik_profile=p.get("name"),
                mikrotik_rate_limit=rate_limit
            )
            session.add(new_plan)
        synced.append(name)

    # PROCESO DE LIMPIEZA: Eliminar planes que ya no existen en el hardware (como "ALIEN")
    # Solo los eliminamos si no tienen clientes asociados para evitar errores de FK.
    all_db_plans = session.exec(select(Plan)).all()
    deleted_orphans = 0
    for db_p in all_db_plans:
        # Si el plan no está en la lista de nombres válidos recién sincronizados
        if db_p.name.upper() not in valid_names:
            # Verificar si tiene clientes
            client_count = len(session.exec(select(Client).where(Client.plan_id == db_p.id)).all())
            if client_count == 0:
                session.delete(db_p)
                deleted_orphans += 1
            else:
                # Opcional: Podríamos marcarlo como "OBSOLETO" en el nombre si quisiéramos
                pass

    session.commit()
    return {
        "status": "SYNC_OK", 
        "synced_plans": synced, 
        "deleted_orphans": deleted_orphans
    }


async def _sync_router_hardware_snapshot(router_obj: Router, session: Session):
    """Descarga datos del hardware y los guarda en la tabla MikrotikHardwareRecord."""
    try:
        print(f"[*] Iniciando snapshot para Router {router_obj.name} ({router_obj.ip_address})")
        # 1. Obtener datos crudos (con fallback para que uno no rompa todo)
        # Usamos asyncio.gather con return_exceptions para paralelizar y no fallar si uno falla
        import asyncio
        results = await asyncio.gather(
            MikroTikDriver.get_pppoe_secrets(router_obj),
            MikroTikDriver.get_dhcp_leases(router_obj),
            MikroTikDriver.get_pppoe_active(router_obj),
            return_exceptions=True
        )
        
        secrets = results[0] if not isinstance(results[0], Exception) else []
        leases = results[1] if not isinstance(results[1], Exception) else []
        active_ppp = results[2] if not isinstance(results[2], Exception) else []

        if isinstance(results[0], Exception): print(f"[!] Error secrets: {results[0]}")
        if isinstance(results[1], Exception): print(f"[!] Error leases: {results[1]}")
        if isinstance(results[2], Exception): print(f"[!] Error active: {results[2]}")
        
        if not secrets and not leases and not active_ppp:
            # Si todos fallaron, lanzamos el error del primero sustancial que haya fallado
            for r in results:
                if isinstance(r, Exception): raise r
            raise Exception("No se pudo obtener ningún dato del hardware (listas vacías)")

        # 2. Limpiar snapshot anterior para este router
        session.exec(
            delete(MikrotikHardwareRecord).where(MikrotikHardwareRecord.router_id == router_obj.id)
        )
        
        # 3. Guardar PPPoE Secrets
        for s in (secrets or []):
            record = MikrotikHardwareRecord(
                router_id=router_obj.id,
                record_type="PPPOE_SECRET",
                name=s.get("name"),
                comment=s.get("comment"),
                ip_address=s.get("remote-address"),
                raw_data=json.dumps(s),
                synced_at=datetime.utcnow()
            )
            session.add(record)
            
        # 4. Guardar DHCP Leases
        for l in (leases or []):
            record = MikrotikHardwareRecord(
                router_id=router_obj.id,
                record_type="DHCP_LEASE",
                name=l.get("address"),
                comment=l.get("comment"),
                mac_address=l.get("mac-address"),
                ip_address=l.get("address"),
                raw_data=json.dumps(l),
                synced_at=datetime.utcnow()
            )
            session.add(record)
            
        # 5. Guardar PPPoE Active (para tener IPs de tiempo real)
        for a in (active_ppp or []):
            record = MikrotikHardwareRecord(
                router_id=router_obj.id,
                record_type="PPPOE_ACTIVE",
                name=a.get("name"),
                comment=a.get("comment"),
                ip_address=a.get("address"),
                raw_data=json.dumps(a),
                synced_at=datetime.utcnow()
            )
            session.add(record)
            
        session.commit()
        print(f"[+] Snapshot completado: {len(secrets or [])} secrets, {len(leases or [])} leases, {len(active_ppp or [])} active")
        return True
    except Exception as e:
        print(f"[SNAPSHOT FATAL ERROR] {e}")
        # Re-lanzamos para que internal_discover_mikrotik_clients lo capture y reporte como 503
        raise e


async def internal_discover_mikrotik_clients(router_obj: Router, session: Session, preview_only: bool = False):
    """Lógica interna de descubrimiento basada en Snapshots de SQLite."""
    router_id = router_obj.id
    
    # 1. ACTUALIZAR SNAPSHOT (Hardware -> SQLite)
    try:
        await _sync_router_hardware_snapshot(router_obj, session)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"HARDWARE_SYNC_FAILED: {str(e)}")

    # 2. LEER DESDE SNAPSHOT (SQLite -> Discovery)
    snapshot_records = session.exec(
        select(MikrotikHardwareRecord).where(MikrotikHardwareRecord.router_id == router_id)
    ).all()
    
    secrets = [r for r in snapshot_records if r.record_type == "PPPOE_SECRET"]
    leases = [r for r in snapshot_records if r.record_type == "DHCP_LEASE"]
    active_ppp = [r for r in snapshot_records if r.record_type == "PPPOE_ACTIVE"]

    # OPTIMIZACIÓN: Cargar clientes existentes y Planes en memoria
    all_clients = session.exec(select(Client)).all()
    client_by_dni = {c.dni: c for c in all_clients if c.dni}
    client_by_user = {c.pppoe_user: c for c in all_clients if c.pppoe_user}
    client_by_mac = {c.mac_address.lower(): c for c in all_clients if c.mac_address}
    client_by_ip = {c.ip_address: c for c in all_clients if c.ip_address and c.ip_address not in ("0.0.0.0", "none", "")}
    
    all_plans = session.exec(select(Plan)).all()
    plan_map = {p.name.upper(): p for p in all_plans}
    rate_plan_map = {p.mikrotik_rate_limit: p for p in all_plans if p.mikrotik_rate_limit}
    
    default_plan = plan_map.get("PLAN BASICO") or plan_map.get("BASIC") or (all_plans[0] if all_plans else None)

    active_ppp_ips = {a.name: a.ip_address for a in active_ppp if a.ip_address}
    
    created_count = 0
    updated_count = 0
    new_candidates = []
    
    def parse_comment(comment: str):
        if not comment:
            return None, None, None
        comment = comment.strip()
        
        # Regex más flexible para DNI (6 a 12 dígitos)
        # Soporta formatos como "DNI: 12345678", "Cedula 12345678", "12345678 | Juan"
        dni_match = re.search(r'\b(\d{6,12})\b', comment)
        dni = dni_match.group(1) if dni_match else None
        
        temp_name = comment
        if dni: temp_name = temp_name.replace(dni, "").strip()
        
        # Limpieza de caracteres ruidosos
        temp_name = re.sub(r'^[|,\-\s\(\)/:.]+', '', temp_name)
        temp_name = re.sub(r'[|,\-\s\(\)/:.]+$', '', temp_name)
        temp_name = re.sub(r'\s+', ' ', temp_name)
        
        # Si el nombre queda muy corto o es solo números, intentar fallbacks
        if len(temp_name) < 2 or temp_name.isdigit(): 
            name = None
        else: 
            name = temp_name
            
        # Ignorar palabras clave de prueba
        if name and name.lower() in ("test", "prueba", "reserved", "pnp", "admin", "mikrotik", "default"):
            return None, None, None
            
        phone = "000"
        # Buscar algo que parezca teléfono (7 a 15 dígitos) que no sea el DNI
        other_numbers = re.findall(r'\b\d{7,15}\b', comment)
        for num in other_numbers:
            if num != dni:
                phone = num
                break
        return name, dni, phone

    # 1. PROCESAR PPPOE SECRETS
    for r in secrets:
        s_data = json.loads(r.raw_data)
        username = r.name
        name, dni, phone = parse_comment(r.comment)
        
        # IDENTIFICADOR ÚNICO: Priorizar DNI, sino usar username como "DNI temporal"
        id_dni = dni or f"PPPOE-{username}"
        
        # Priorizar la IP de la sesión activa si existe, normalizar a None si es inválida
        ip = active_ppp_ips.get(username) or r.ip_address
        if ip in ("0.0.0.0", "none", ""): ip = None
        
        plan_name = s_data.get("profile", "default").upper()
        if plan_name == "PYMES": plan_name = "PYME"
        db_plan = plan_map.get(plan_name) or default_plan
        
        # Buscar cliente existente (por DNI real, DNI temporal o usuario)
        client = (
            client_by_dni.get(dni) if dni else None
        ) or client_by_user.get(username) or client_by_dni.get(id_dni)

        if client:
            is_updated = False
            # Corregir IP si es diferente y válida, evitando conflictos
            if ip and ip != client.ip_address:
                if ip not in client_by_ip:
                    client.ip_address = ip
                    client_by_ip[ip] = client
                    is_updated = True
            
            # Asegurar que el usuario PPPoE esté vinculado
            if client.pppoe_user != username:
                client.pppoe_user = username
                is_updated = True
                
            if is_updated:
                updated_count += 1
                session.add(client)
            continue

        # Crear nuevo si no existe, validando IP disponible
        target_ip = ip if ip and ip not in client_by_ip else None
        new_client = Client(
            full_name=name or f"Cliente PPPoE: {username}", 
            dni=id_dni, 
            phone=phone or "000", 
            email=f"{id_dni}@omni.net",
            ip_address=target_ip, 
            plan_id=db_plan.id if db_plan else 1, 
            router_id=router_id,
            connection_type="PPPOE", 
            pppoe_user=username,
            pppoe_pass=s_data.get("password", "changeme"), 
            status="ACTIVE"
        )
        
        if preview_only:
            new_candidates.append({
                "username": username,
                "full_name": new_client.full_name,
                "dni": new_client.dni,
                "ip_address": new_client.ip_address,
                "connection_type": new_client.connection_type,
                "mac_address": "",
                "phone": new_client.phone
            })
        else:
            session.add(new_client)
            client_by_dni[id_dni] = new_client
            client_by_user[username] = new_client
            if target_ip: client_by_ip[target_ip] = new_client
            created_count += 1

    # 2. PROCESAR DHCP LEASES
    for r in leases:
        l_data = json.loads(r.raw_data)
        addr = r.ip_address
        mac = (r.mac_address or "").lower()
        if not mac: continue # Sin MAC no podemos identificar confiablemente
        
        name, dni, phone = parse_comment(r.comment)
        
        # IDENTIFICADOR ÚNICO: DNI o MAC como surrogate
        id_dni = dni or f"MAC-{mac.replace(':', '')[-8:]}" # 8 últimos caracteres de MAC
        
        rate_limit = l_data.get("rate-limit", "")
        db_plan = rate_plan_map.get(rate_limit) or default_plan

        # Buscar por DNI, MAC o Surrogate DNI
        client = (
            client_by_dni.get(dni) if dni else None
        ) or client_by_mac.get(mac) or client_by_dni.get(id_dni)

        if client:
            is_updated = False
            if addr and addr not in ("0.0.0.0", "none", "") and addr != client.ip_address:
                if addr not in client_by_ip:
                    client.ip_address = addr
                    client_by_ip[addr] = client
                    is_updated = True
            if client.mac_address != mac:
                client.mac_address = mac
                is_updated = True
            
            if is_updated:
                updated_count += 1
                session.add(client)
            continue

        # Crear si no existe
        target_ip = addr if addr and addr not in ("0.0.0.0", "none", "") and addr not in client_by_ip else None
        new_client = Client(
            full_name=name or f"Cliente DHCP: {addr}", 
            dni=id_dni, 
            phone=phone or "000", 
            email=f"{id_dni}@omni.net",
            ip_address=target_ip, 
            mac_address=mac,
            plan_id=db_plan.id if db_plan else 1, 
            router_id=router_id,
            connection_type="DHCP", 
            status="ACTIVE"
        )
        
        if preview_only:
            new_candidates.append({
                "username": addr,
                "full_name": new_client.full_name,
                "dni": new_client.dni,
                "ip_address": new_client.ip_address,
                "connection_type": new_client.connection_type,
                "mac_address": new_client.mac_address,
                "phone": new_client.phone
            })
        else:
            session.add(new_client)
            client_by_dni[id_dni] = new_client
            client_by_mac[mac] = new_client
            if target_ip: client_by_ip[target_ip] = new_client
            created_count += 1

    if not preview_only:
        session.commit()
        return {"created": created_count, "updated": updated_count}
    else:
        return {"candidates": new_candidates, "updated": updated_count}




@router.post("/mikrotik/{router_id}/discover-clients")
async def discover_mikrotik_clients(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    try:
        # Timeout de 45s para asegurar que la petición HTTP no quede colgada
        result = await asyncio.wait_for(
            internal_discover_mikrotik_clients(router_obj, session, preview_only=False),
            timeout=45.0
        )
        return {"status": "SUCCESS", **result}
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="HARDWARE_TIMEOUT: El router tardó demasiado en responder.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/mikrotik/{router_id}/discover-preview")
async def preview_mikrotik_clients(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    try:
        result = await asyncio.wait_for(
            internal_discover_mikrotik_clients(router_obj, session, preview_only=True),
            timeout=45.0
        )
        return {"status": "SUCCESS", **result}
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="HARDWARE_TIMEOUT: El router tardó demasiado en responder.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class ClientImportSchema(BaseModel):
    username: str
    full_name: str
    dni: str
    ip_address: Optional[str]
    connection_type: str
    mac_address: Optional[str]
    phone: str

class ImportClientsRequest(BaseModel):
    clients: List[ClientImportSchema]

@router.post("/mikrotik/{router_id}/import-clients")
async def import_selected_clients(router_id: int, req: ImportClientsRequest, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    all_plans = session.exec(select(Plan)).all()
    default_plan = all_plans[0] if all_plans else None
    
    created = 0
    for c in req.clients:
        new_client = Client(
            full_name=c.full_name, 
            dni=c.dni, 
            phone=c.phone or "000", 
            email=f"{c.dni}@omni.net",
            ip_address=c.ip_address if c.ip_address else None, 
            plan_id=default_plan.id if default_plan else 1, 
            router_id=router_id,
            connection_type=c.connection_type, 
            pppoe_user=c.username if c.connection_type == "PPPOE" else None,
            pppoe_pass="changeme" if c.connection_type == "PPPOE" else None,
            mac_address=c.mac_address if c.connection_type == "DHCP" else None,
            status="ACTIVE"
        )
        session.add(new_client)
        created += 1
        
    session.commit()
    return {"status": "SUCCESS", "created": created}


@router.get("/mikrotik/{router_id}/profiles")
async def get_mikrotik_profiles(router_id: int, session: Session = Depends(get_session)):
    """Lista los perfiles PPPoE disponibles en el hardware."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    profiles = await MikroTikDriver.get_pppoe_profiles(router_obj)
    return profiles


@router.patch("/mikrotik/{router_id}/profiles/{name}")
async def update_mikrotik_profile(router_id: int, name: str, params: dict, session: Session = Depends(get_session)):
    """Actualiza un perfil técnico directamente en el MikroTik."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    success = await MikroTikDriver.update_pppoe_profile(router_obj, name, params)
    if not success:
        raise HTTPException(status_code=500, detail=f"No se pudo actualizar el perfil '{name}' en el hardware.")
    return {"status": "SUCCESS"}


@router.patch("/plans/{plan_id}")
async def update_plan(plan_id: int, data: dict, session: Session = Depends(get_session)):
    """Actualiza los datos de un plan en la base de datos."""
    plan = session.get(Plan, plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan no encontrado")
    
    for k, v in data.items():
        if hasattr(plan, k) and k not in ("id"):
            setattr(plan, k, v)
    
    session.add(plan)
    session.commit()
    session.refresh(plan)
    return plan



@router.post("/clients/{client_id}/change-plan/{new_plan_id}")
async def change_client_plan(client_id: int, new_plan_id: int, session: Session = Depends(get_session)):
    """Cambia el plan de un cliente en la DB y en caliente en el MikroTik."""
    client = session.get(Client, client_id)
    plan = session.get(Plan, new_plan_id)
    if not client or not plan:
        raise HTTPException(status_code=404, detail="Client or Plan not found")

    router_obj = session.get(Router, client.router_id)
    if not router_obj:
        raise HTTPException(status_code=400, detail="No router assigned to client")

    success = False
    if client.connection_type == "PPPOE":
        # 1. Cambiar perfil en el secret (el perfil maneja el QoS dinámico)
        success = await MikroTikDriver.update_pppoe_secret(router_obj, client.pppoe_user, {"profile": plan.mikrotik_profile or "default"})
        # 2. Botar sesion para reconexión
        await MikroTikDriver.kick_pppoe_session(router_obj, client.pppoe_user)
    else:
        # DHCP: Inyectar rate-limit (genera cola dinámica en el lease)
        limit = plan.mikrotik_rate_limit or f"{plan.upload_limit}M/{plan.download_limit}M"
        success = await MikroTikDriver.update_dhcp_lease_params(
            router_obj, client.ip_address, {"rate-limit": limit}
        )


    if success:
        client.plan_id = new_plan_id
        
        # SI EL CLIENTE ESTA MOROSO: Debemos actualizar el 'recuerdo' (prev_address_list)
        # para que cuando pague, el sistema lo restaure al NUEVO plan y no al viejo.
        if client.status in ("MOROSO", "SUSPENDED"):
            # Usamos el nombre del perfil o el nombre del plan como address-list objetivo
            new_target_list = plan.mikrotik_profile or plan.name
            client.prev_address_list = new_target_list
            print(f"[PLAN CHANGE] Cliente MOROSO detectado. Actualizando recuerdo de restauracion a: {new_target_list}")

        session.add(client)
        session.commit()
        return {"status": "PLAN_CHANGED", "client": client.full_name, "new_plan": plan.name, "moroso_synced": client.status in ("MOROSO", "SUSPENDED")}



# ─────────────────────────────────────────────
# ROUTERS (MIKROTIK NODES)
# ─────────────────────────────────────────────

@router.get("/routers")
async def list_routers(session: Session = Depends(get_session)):
    return session.exec(select(Router)).all()

@router.get("/routers/{router_id}/status")
async def get_router_status(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    api = await MikroTikDriver.get_api(router_obj)
    if not api:
        return {"id": router_id, "status": "OFFLINE"}
    resource_path = api.path("/system/resource")
    res = list(resource_path) if not isinstance(api, RestApiWrapper) else resource_path()
    if hasattr(api, "close"):
        api.close()
    return {"id": router_id, "status": "ONLINE", "resources": res[0] if isinstance(res, list) and res else res}

@router.post("/routers")
async def register_router(router_data: RouterCreate, session: Session = Depends(get_session)):
    print(f"[DEBUG] POST /routers received: {router_data}")
    existing = session.exec(select(Router).where(Router.ip_address == router_data.ip_address)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Router with this IP already registered")
    db_router = Router.from_orm(router_data)
    try:
        session.add(db_router)
        session.commit()
        session.refresh(db_router)
        return db_router
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

class RouterTestSchema(BaseModel):
    ip_address: str
    username: str
    password: str
    api_port: int = 8728
    connection_mode: str = "API"

@router.post("/routers/test-connection")
async def test_router_connection(router_data: RouterTestSchema):
    temp_router = Router(
        name="TEST_NODE", ip_address=router_data.ip_address,
        username=router_data.username, password=router_data.password,
        api_port=router_data.api_port, connection_mode=router_data.connection_mode
    )
    api = await MikroTikDriver.get_api(temp_router)
    if not api:
        raise HTTPException(status_code=400, detail="CONNECTION_TIMEOUT: Check IP, Port, API service.")
    try:
        if isinstance(api, RestApiWrapper):
            res = api.get("/system/identity")
            identity = res[0].get("name", "MikroTik") if res else "MikroTik"
        else:
            res = list(api.path("/system/identity"))
            identity = res[0].get("name", "MikroTik") if res else "MikroTik"
        return {"status": "SUCCESS", "identity": identity}
    except Exception as e:
        return {"status": "SUCCESS", "identity": "MikroTik"}
    finally:
        if hasattr(api, "close"):
            api.close()

@router.get("/routers/{router_id}/test")
async def test_stored_router_connection(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    api = await MikroTikDriver.get_api(router_obj)
    if not api:
        raise HTTPException(status_code=400, detail=f"CONNECTION_FAILED for {router_obj.username}")
    try:
        if isinstance(api, RestApiWrapper):
            res = api.get("/system/identity")
            identity = res[0].get("name", "MikroTik") if res else "MikroTik"
        else:
            res = list(api.path("/system/identity"))
            identity = res[0].get("name", "MikroTik") if res else "MikroTik"
        return {"status": "SUCCESS", "identity": identity}
    except Exception:
        return {"status": "SUCCESS", "identity": "MikroTik"}
    finally:
        if hasattr(api, "close"):
            api.close()

@router.patch("/routers/{router_id}")
async def update_router(router_id: int, router_update: RouterCreate, session: Session = Depends(get_session)):
    db_router = session.get(Router, router_id)
    if not db_router:
        raise HTTPException(status_code=404, detail="Router not found")
    update_data = router_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_router, key, value)
    session.add(db_router)
    session.commit()
    session.refresh(db_router)
    return db_router

@router.get("/routers/{router_id}/telemetry")
async def get_router_snmp_telemetry(router_id: int, session: Session = Depends(get_session)):
    """Obtiene telemetría avanzada vía SNMP (CPU, RAM, Ancho de Banda)."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    return await MikroTikDriver.get_snmp_telemetry(router_obj)

@router.get("/routers/{router_id}/metrics")
async def get_router_historical_metrics(router_id: int, hours: int = 24):
    """Obtiene el historial de métricas para gráficos."""
    from backend.telemetry_service import get_historical_metrics
    return await get_historical_metrics(router_id, hours)

@router.get("/routers/{router_id}/interfaces")
async def get_router_interfaces(router_id: int, session: Session = Depends(get_session)):
    """Descubre interfaces vía SNMP Walk."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    return await MikroTikDriver.get_snmp_interfaces(router_obj)

@router.delete("/routers/{router_id}")
async def decommission_router(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    session.delete(router_obj)
    session.commit()
    return {"status": "DECOMMISSIONED", "id": router_id}


# ─────────────────────────────────────────────
# MIKROTIK — Clientes (DHCP + PPPoE)
# ─────────────────────────────────────────────

@router.get("/mikrotik/{router_id}/resource")
async def get_mikrotik_resource(router_id: int, session: Session = Depends(get_session)):
    """CPU, RAM, uptime, versión RouterOS"""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    resource = await MikroTikDriver.get_resource(router_obj)
    return resource or {"error": "OFFLINE"}

@router.get("/mikrotik/{router_id}/dhcp-leases")
async def get_dhcp_leases(router_id: int, session: Session = Depends(get_session)):
    """Todos los DHCP leases del router (dinámicos + estáticos)"""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    leases = await MikroTikDriver.get_dhcp_leases(router_obj)
    return {"router": router_obj.name, "count": len(leases), "leases": leases}

@router.get("/mikrotik/{router_id}/pppoe-active")
async def get_pppoe_active(router_id: int, session: Session = Depends(get_session)):
    """Sesiones PPPoE activas en este momento"""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    active = await MikroTikDriver.get_pppoe_active(router_obj)
    return {"router": router_obj.name, "count": len(active), "sessions": active}

@router.get("/mikrotik/{router_id}/pppoe-secrets")
async def get_pppoe_secrets(router_id: int, session: Session = Depends(get_session)):
    """Todos los secretos PPPoE configurados"""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    secrets = await MikroTikDriver.get_pppoe_secrets(router_obj)
    return {"router": router_obj.name, "count": len(secrets), "secrets": secrets}

@router.get("/mikrotik/{router_id}/pppoe-traffic")
async def get_pppoe_traffic(router_id: int, session: Session = Depends(get_session)):
    """
    Tráfico en tiempo real de cada sesión PPPoE activa.
    Devuelve por sesión:
      - tx-rate-bps / rx-rate-bps   → bits por segundo
      - tx-rate-kbps / rx-rate-kbps → kilobits por segundo
      - tx-rate-mbps / rx-rate-mbps → megabits por segundo
      - tx-pkt-rate / rx-pkt-rate   → paquetes por segundo
      - tx-bytes / rx-bytes         → bytes acumulados de la sesión
      - tx-packets / rx-packets     → paquetes acumulados
    El primer call retorna rates en 0 (sin baseline previo).
    Los rates se calculan a partir del segundo poll (intervalo ~5 s recomendado).
    """
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    traffic = await MikroTikDriver.get_pppoe_traffic(router_obj)
    return {"router": router_obj.name, "count": len(traffic), "sessions": traffic}

@router.get("/mikrotik/{router_id}/interfaces")
async def get_interfaces(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    ifaces = await MikroTikDriver.get_all_interfaces(router_obj)
    return {"interfaces": ifaces}

@router.get("/mikrotik/{router_id}/snmp-live")
async def get_snmp_live(router_id: int, interface_idx: str = "1", session: Session = Depends(get_session)):
    """Obtiene telemetría SNMP en tiempo real."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    data = await MikroTikDriver.get_snmp_telemetry(router_obj, interface_idx=interface_idx)
    return data

@router.get("/mikrotik/{router_id}/interfaces-detailed")
async def get_interfaces_detailed(router_id: int, session: Session = Depends(get_session)):
    """Obtiene interfaces, interface lists y vlans para mapeo profundo"""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
        
    api = await MikroTikDriver.get_api(router_obj)
    if not api:
        return {"interfaces": [], "lists": [], "vlans": []}

    try:
        if isinstance(api, RestApiWrapper):
            ifaces = api.get("/interface") or []
            lists = api.get("/interface/list/member") or []
            vlans = api.get("/interface/vlan") or []
        else:
            ifaces = list(api.path("/interface"))
            try:
                lists = list(api.path("/interface/list/member"))
            except Exception:
                lists = []
            try:
                vlans = list(api.path("/interface/vlan"))
            except Exception:
                vlans = []
                
        return {"interfaces": ifaces, "lists": lists, "vlans": vlans}
    except Exception as e:
        return {"error": str(e), "interfaces": [], "lists": [], "vlans": []}
    finally:
        if hasattr(api, "close"):
            api.close()

@router.get("/mikrotik/client-telemetry/{client_id}")
async def get_client_telemetry_endpoint(client_id: int, session: Session = Depends(get_session)):
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    if not client.router_id:
        return {"status": "NO_ROUTER"}
    router_obj = session.get(Router, client.router_id)
    if not router_obj:
        return {"status": "NO_ROUTER"}
    telemetry = await MikroTikDriver.get_client_telemetry(router_obj, client)
    return telemetry


class CreateDHCPLeaseSchema(BaseModel):
    ip_address: str
    mac_address: str
    server: str = "all"
    comment: str = ""
    address_list: Optional[str] = None

@router.post("/mikrotik/{router_id}/dhcp-lease")
async def create_dhcp_lease(
    router_id: int,
    body: CreateDHCPLeaseSchema,
    session: Session = Depends(get_session)
):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    params = {
        "ip-address": body.ip_address,
        "mac-address": body.mac_address,
        "server": body.server,
        "comment": body.comment,
    }
    if body.address_list:
        params["address-list"] = body.address_list
    
    success = await MikroTikDriver.create_dhcp_lease(router_obj, params)
    if not success:
        # Crear cambio pendiente
        pending = MikrotikPendingChange(
            router_id=router_id,
            action="CREATE_DHCP",
            payload=json.dumps(params),
            description=f"Crear DHCP lease: {body.ip_address} ({body.comment})",
            created_by="MANUAL"
        )
        session.add(pending)
        session.commit()
        return {"status": "PENDING", "message": "Router no disponible. Cambio guardado en cola."}
    return {"status": "CREATED", "ip": body.ip_address}

class CreatePPPoESecretSchema(BaseModel):
    name: str
    password: str
    profile: str = "default"
    comment: str = ""
    local_address: Optional[str] = None
    remote_address: Optional[str] = None
    service: str = "ppp"

@router.post("/mikrotik/{router_id}/pppoe-secret")
async def create_pppoe_secret(
    router_id: int,
    body: CreatePPPoESecretSchema,
    session: Session = Depends(get_session)
):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    params = {
        "name": body.name,
        "password": body.password,
        "profile": body.profile,
        "comment": body.comment,
        "service": body.service,
    }
    if body.local_address:
        params["local-address"] = body.local_address
    if body.remote_address:
        params["remote-address"] = body.remote_address
    
    success = await MikroTikDriver.create_pppoe_secret(router_obj, params)
    if not success:
        pending = MikrotikPendingChange(
            router_id=router_id,
            action="CREATE_PPPOE",
            payload=json.dumps(params),
            description=f"Crear PPPoE secret: {body.name}",
            created_by="MANUAL"
        )
        session.add(pending)
        session.commit()
        return {"status": "PENDING", "message": "Router no disponible. Cambio guardado en cola."}
    return {"status": "CREATED", "user": body.name}

@router.post("/mikrotik/{router_id}/backup")
async def run_mikrotik_backup(router_id: int, session: Session = Depends(get_session)):
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    backup_name = f"omni-bkp-{router_obj.name}-{datetime.utcnow().strftime('%Y%m%d-%H%M')}"
    success = await MikroTikDriver.run_backup(router_obj, backup_name)
    return {"status": "BACKUP_OK" if success else "BACKUP_FAILED", "name": backup_name}


# ─────────────────────────────────────────────
# PENDING CHANGES (Cola offline)
# ─────────────────────────────────────────────

@router.get("/mikrotik/pending-changes")
async def list_pending_changes(
    router_id: Optional[int] = None,
    session: Session = Depends(get_session)
):
    query = select(MikrotikPendingChange).where(MikrotikPendingChange.status == "PENDIENTE")
    if router_id:
        query = query.where(MikrotikPendingChange.router_id == router_id)
    return session.exec(query.order_by(MikrotikPendingChange.created_at.asc())).all()

@router.post("/mikrotik/pending-changes/{change_id}/apply")
async def apply_change(change_id: int, session: Session = Depends(get_session)):
    change = session.get(MikrotikPendingChange, change_id)
    if not change:
        raise HTTPException(status_code=404, detail="Change not found")
    router_obj = session.get(Router, change.router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    payload = json.loads(change.payload)
    success = False
    try:
        if change.action == "CREATE_DHCP":
            success = await MikroTikDriver.create_dhcp_lease(router_obj, payload)
        elif change.action == "CREATE_PPPOE":
            success = await MikroTikDriver.create_pppoe_secret(router_obj, payload)
        elif change.action == "SUSPEND_DHCP":
            success = await MikroTikDriver.suspend_dhcp_client(router_obj, payload.get("ip", ""))
        elif change.action == "SUSPEND_PPPOE":
            success = await MikroTikDriver.suspend_pppoe_client(router_obj, payload.get("user", ""))
    except Exception as e:
        change.error_msg = str(e)
    
    change.status = "APLICADO" if success else "FALLIDO"
    if success:
        change.applied_at = datetime.utcnow()
    session.add(change)
    session.commit()
    return {"status": change.status}

@router.delete("/mikrotik/pending-changes/{change_id}")
async def cancel_change(change_id: int, session: Session = Depends(get_session)):
    change = session.get(MikrotikPendingChange, change_id)
    if not change:
        raise HTTPException(status_code=404, detail="Change not found")
    change.status = "CANCELADO"
    session.add(change)
    session.commit()
    return {"status": "CANCELADO"}


# ─────────────────────────────────────────────
# OLT & ONU
# ─────────────────────────────────────────────

class OLTTestSchema(BaseModel):
    ip_address: str
    username: Optional[str] = Field(default="admin")
    password: Optional[str] = Field(default="")
    ssh_port: Optional[int] = Field(default=22)
    snmp_version: Optional[str] = Field(default="v2c")
    snmp_community: Optional[str] = Field(default="public")
    snmp_username: Optional[str] = None
    snmp_auth_protocol: Optional[str] = None
    snmp_auth_password: Optional[str] = None
    snmp_priv_protocol: Optional[str] = None
    snmp_priv_password: Optional[str] = None
    model: Optional[str] = Field(default="VSOL_GPON")

@router.post("/olts/test-connection")
async def test_olt_connection(data: OLTTestSchema):
    """Prueba conectividad SNMP (primario) o SSH (fallback) con la OLT."""
    temp_olt = OLT(
        name="TEST_OLT", ip_address=data.ip_address,
        username=data.username, password=data.password,
        ssh_port=data.ssh_port, model=data.model,
        snmp_version=data.snmp_version,
        snmp_community=data.snmp_community or "public",
        snmp_username=data.snmp_username,
        snmp_auth_protocol=data.snmp_auth_protocol,
        snmp_auth_password=data.snmp_auth_password,
        snmp_priv_protocol=data.snmp_priv_protocol,
        snmp_priv_password=data.snmp_priv_password,
    )
    # 1. Probar SNMP sysDescr
    sys_descr = await OLTDriver.snmp_get(temp_olt, "1.3.6.1.2.1.1.1.0")
    if sys_descr and not sys_descr.startswith("ERROR") and not sys_descr.startswith("EXCEPTION"):
        return {"online": True, "status": "SUCCESS", "protocol": "SNMP", "info": sys_descr[:120]}
    
    snmp_error = sys_descr if sys_descr and (sys_descr.startswith("ERROR") or sys_descr.startswith("EXCEPTION")) else "Timeout (No responde)"

    # 2. Fallback SSH
    client = await OLTDriver.get_ssh_client(temp_olt)
    if client:
        try:
            return {"online": True, "status": "SUCCESS", "protocol": "SSH", "info": "Conexión SSH exitosa"}
        finally:
            client.close()
            
    # 3. Ping final
    is_alive = await OLTDriver.probe_status(temp_olt)
    if is_alive:
        return {"online": True, "status": "PARTIAL", "protocol": "PING", "info": f"Solo responde PING. SNMP falló: {snmp_error}"}
    
    return {"online": False, "status": "FAILED", "error": f"Inalcanzable. SNMP: {snmp_error}"}

@router.get("/olts", response_model=List[OLT])
async def list_olts(session: Session = Depends(get_session)):
    return session.exec(select(OLT)).all()

@router.post("/olts")
async def register_olt(olt_data: OLTCreate, background_tasks: BackgroundTasks, session: Session = Depends(get_session)):
    db_olt = OLT.from_orm(olt_data)
    session.add(db_olt)
    session.commit()
    session.refresh(db_olt)
    
    # Auto-scan in background
    async def _auto_scan():
        from backend.database import engine
        from sqlmodel import Session
        with Session(engine) as bg_session:
            try:
                await scan_olt_onus(db_olt.id, sync=True, session=bg_session)
                print(f"[AUTO-SCAN] Completed for OLT {db_olt.id}")
            except Exception as e:
                print(f"[AUTO-SCAN] Error for OLT {db_olt.id}: {e}")

    background_tasks.add_task(_auto_scan)
    
    return db_olt

@router.put("/olts/{olt_id}")
async def update_olt(olt_id: int, data: dict, session: Session = Depends(get_session)):
    """Actualiza los parámetros de una OLT registrada."""
    olt = session.get(OLT, olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    protected = {"id"}
    for k, v in data.items():
        if hasattr(olt, k) and k not in protected:
            setattr(olt, k, v)
    olt.last_seen = datetime.utcnow()
    session.add(olt)
    session.commit()
    session.refresh(olt)
    return olt


@router.delete("/olts/{olt_id}")
async def delete_olt(olt_id: int, session: Session = Depends(get_session)):
    olt = session.get(OLT, olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    session.delete(olt)
    session.commit()
    return {"status": "DELETED", "id": olt_id}

from backend.services.olt_service import sync_olt_onus_logic

@router.get("/olts/{olt_id}/scan")
async def scan_olt_onus(olt_id: int, sync: bool = False, session: Session = Depends(get_session)):
    result = await sync_olt_onus_logic(olt_id, sync, session)
    if not result:
        raise HTTPException(status_code=404, detail="OLT not found")
    
    # 3. Force port refresh in cache (Remaining logic in API)
    olt = session.get(OLT, olt_id)
    ports = await OLTDriver.get_port_states(olt)
    from backend.state import OLT_STATUS_CACHE
    OLT_STATUS_CACHE[olt.id] = {
        "data": {
            "id": f"olt_{olt.id}", "name": olt.name, "ip": olt.ip_address,
            "status": "ONLINE", "ports": ports
        },
        "timestamp": asyncio.get_event_loop().time()
    }


    
    if olt.auto_learn_enabled:
        result["unauth"] = []

    return {
        "olt": result["olt_name"], 
        "unauthenticated_onus": result["unauth"],
        "discovered_onus": result["discovered"],
        "auto_learn_active": olt.auto_learn_enabled,
        "synced_count": result["synced"],
        "ports_updated": True
    }

class ONUProvisionSchema(BaseModel):

    olt_id: int
    pon_port: int
    onu_index: int
    serial_number: str
    client_id: Optional[int] = None
    vlan: int = 100

@router.post("/olts/provision")
async def provision_onu(data: ONUProvisionSchema, session: Session = Depends(get_session)):
    olt = session.get(OLT, data.olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    success = await OLTDriver.authorize_onu(olt, data.pon_port, data.onu_index, data.serial_number, data.vlan)
    if not success:
        raise HTTPException(status_code=500, detail="OLT_PROVISIONING_FAILED")
    new_onu = ONU(
        olt_id=olt.id, pon_port=data.pon_port, onu_index=data.onu_index,
        serial_number=data.serial_number, vlan=data.vlan, status="ONLINE"
    )
    session.add(new_onu)
    session.commit()
    session.refresh(new_onu)

    # DISPATCH NOTIFICATION: ONU Registrada/Autorizada
    client_name = "Sin asignar"
    if data.client_id:
        client = session.get(Client, data.client_id)
        if client:
            client_name = client.full_name
            client.onu_id = new_onu.id
            session.add(client)
    
    await NotificationDispatcher.dispatch(
        EVENTS["ONU_REGISTERED"],
        f"ONU Autorizada: {new_onu.serial_number} en puerto {new_onu.pon_port}:{new_onu.onu_index}. Cliente: {client_name}.",
        session,
        client_id=data.client_id
    )

    if data.client_id:
        client = session.get(Client, data.client_id)
        if client:
            client.onu_id = new_onu.id
            session.add(client)
            session.commit()
    return {"status": "PROVISIONED", "onu": new_onu}

@router.get("/olts/{olt_id}/onus")
async def list_olt_onus(olt_id: int, session: Session = Depends(get_session)):
    return session.exec(select(ONU).where(ONU.olt_id == olt_id)).all()


@router.get("/onus/unassigned")
async def list_unassigned_onus(session: Session = Depends(get_session)):
    """Retorna todas las ONUs registradas en BD que no están vinculadas a ningún cliente."""
    # Obtenemos los onu_id que ya tienen cliente asignado
    assigned_ids_rows = session.exec(
        select(Client.onu_id).where(Client.onu_id != None)
    ).all()
    assigned_ids = {row for row in assigned_ids_rows if row is not None}

    stmt = select(ONU)
    if assigned_ids:
        stmt = stmt.where(ONU.id.not_in(assigned_ids))

    onus = session.exec(stmt.order_by(ONU.olt_id, ONU.pon_port, ONU.onu_index)).all()

    # Enriquecemos con nombre de OLT para contexto visual en el frontend
    olt_names: dict[int, str] = {}
    for onu in onus:
        if onu.olt_id not in olt_names:
            olt = session.get(OLT, onu.olt_id)
            olt_names[onu.olt_id] = olt.name if olt else f"OLT#{onu.olt_id}"

    return [
        {
            "id": onu.id,
            "serial_number": onu.serial_number,
            "pon_port": onu.pon_port,
            "onu_index": onu.onu_index,
            "status": onu.status,
            "signal_dbm": onu.signal_dbm,
            "model": onu.model,
            "vlan": onu.vlan,
            "olt_id": onu.olt_id,
            "olt_name": olt_names[onu.olt_id],
        }
        for onu in onus
    ]


@router.put("/clients/{client_id}/assign-onu")
async def assign_onu_to_client(
    client_id: int,
    data: dict,
    session: Session = Depends(get_session),
):
    """Vincula (o desvincula) una ONU a un cliente a nivel de base de datos."""
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    onu_id = data.get("onu_id")  # None = desvincular

    if onu_id is None:
        # Desvincular
        client.onu_id = None
        client.onu_serial = None
        session.add(client)
        session.commit()
        return {"status": "UNLINKED", "message": "ONU desvinculada del cliente"}

    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU no encontrada")

    # Verificar que la ONU no esté ya asignada a otro cliente
    existing_owner = session.exec(
        select(Client).where(Client.onu_id == onu_id).where(Client.id != client_id)
    ).first()
    if existing_owner:
        raise HTTPException(
            status_code=409,
            detail=f"Esta ONU ya está asignada al cliente '{existing_owner.full_name}'"
        )

    client.onu_id = onu.id
    client.onu_serial = onu.serial_number
    session.add(client)
    session.commit()
    session.refresh(client)

    return {
        "status": "ASSIGNED",
        "message": f"ONU {onu.serial_number} vinculada al cliente {client.full_name}",
        "onu_serial": onu.serial_number,
        "onu_id": onu.id,
    }


@router.get("/onus/{onu_id}/history")
async def get_onu_signal_history(onu_id: int, session: Session = Depends(get_session)):
    """Retorna los últimos 100 puntos de señal para graficar el historial."""
    history = session.exec(
        select(ONUSignalHistory)
        .where(ONUSignalHistory.onu_id == onu_id)
        .order_by(ONUSignalHistory.timestamp.desc())
        .limit(100)
    ).all()
    # Retornar en orden cronológico para el gráfico
    return sorted(history, key=lambda x: x.timestamp)


def _merge_onu_hardware_fields(session: Session, onu: ONU, details: Dict[str, Any]) -> None:
    """Rellena modelo/firmware faltantes desde la BD y persiste lecturas SNMP nuevas en la ONU."""
    snmp_model = details.get("model")
    snmp_fw = details.get("firmware")
    if isinstance(snmp_model, str):
        snmp_model = snmp_model.strip() or None
    if isinstance(snmp_fw, str):
        snmp_fw = snmp_fw.strip() or None

    if not snmp_model and onu.model:
        details["model"] = onu.model
    if not snmp_fw and onu.firmware:
        details["firmware"] = onu.firmware

    dirty = False
    if snmp_model and snmp_model != onu.model:
        onu.model = snmp_model
        dirty = True
    if snmp_fw and snmp_fw != onu.firmware:
        onu.firmware = snmp_fw
        dirty = True
    if dirty:
        session.add(onu)
        session.commit()


async def _resolve_onu_details_payload(
    session: Session, onu: ONU, olt: OLT, *, force: bool = False
) -> Dict[str, Any]:
    """SNMP + DB merge for ONU detail panel; uses TTL cache and per-OLT SNMP lock."""
    if not force:
        cached = cache_get(onu.id)
        if cached is not None:
            return cached

    async with get_olt_snmp_lock(olt.id):
        if not force:
            cached = cache_get(onu.id)
            if cached is not None:
                return cached

        details = await OLTDriver.get_onu_details(
            olt, onu.pon_port, onu.onu_index, cached_ifindex=onu.snmp_ifindex
        )
        if details.get("snmp_ifindex") and details["snmp_ifindex"] != onu.snmp_ifindex:
            onu.snmp_ifindex = details["snmp_ifindex"]
            session.add(onu)
            session.commit()

        details["id"] = onu.id
        details["serial_number"] = onu.serial_number
        details["pon_port"] = onu.pon_port
        details["onu_index"] = onu.onu_index
        details["vlan"] = onu.vlan
        details["bandwidth_rx"] = onu.bandwidth_rx
        details["bandwidth_tx"] = onu.bandwidth_tx
        if onu.intensive_monitoring_until:
            details["intensive_monitoring_until"] = onu.intensive_monitoring_until.isoformat()
        else:
            details["intensive_monitoring_until"] = None

        client = session.exec(select(Client).where(Client.onu_id == onu.id)).first()
        if client:
            details["client"] = {
                "id": client.id,
                "name": client.full_name,
                "status": client.status,
                "ip": client.ip_address,
                "dni": client.dni,
            }

        _merge_onu_hardware_fields(session, onu, details)

        cache_set(onu.id, details)
        return details


@router.get("/onus/{onu_id}/details")
async def get_onu_full_details(
    onu_id: int,
    force: bool = Query(False, description="Bypass cache and query OLT via SNMP immediately"),
    session: Session = Depends(get_session),
):
    """Fetches high-depth telemetry for a specific ONU (Optical + Status + Real Bandwidth)."""
    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU not found")

    olt = session.get(OLT, onu.olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found for this ONU")

    return await _resolve_onu_details_payload(session, onu, olt, force=force)


_ONU_LIVE_KEYS = (
    "signal_dbm",
    "tx_power",
    "distance",
    "status_msg",
    "bandwidth_rx",
    "bandwidth_tx",
    "model",
    "firmware",
    "intensive_monitoring_until",
    "rx_octets",
    "tx_octets",
)


@router.get("/onus/{onu_id}/live")
async def get_onu_live_metrics(
    onu_id: int,
    force: bool = Query(False, description="Bypass cache and query OLT via SNMP immediately"),
    session: Session = Depends(get_session),
):
    """Lightweight live metrics for polling (same cache as /details)."""
    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU not found")
    olt = session.get(OLT, onu.olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found for this ONU")
    full = await _resolve_onu_details_payload(session, onu, olt, force=force)
    return {k: full.get(k) for k in _ONU_LIVE_KEYS}


@router.post("/onus/{onu_id}/intensive-monitoring")
async def enable_intensive_monitoring(onu_id: int, hours: int = 1, session: Session = Depends(get_session)):
    """Activa el monitoreo de alta frecuencia (cada 30s) para una ONU específica."""
    from datetime import datetime, timedelta
    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU not found")

    onu.intensive_monitoring_until = datetime.utcnow() + timedelta(hours=hours)
    session.add(onu)
    session.commit()
    cache_delete(onu_id)

    return {"status": "ENABLED", "until": onu.intensive_monitoring_until}
    
@router.post("/onus/{onu_id}/reboot")
async def reboot_onu_endpoint(onu_id: int, session: Session = Depends(get_session)):
    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU not found")
    olt = session.get(OLT, onu.olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    
    success = await OLTDriver.reboot_onu(olt, onu.pon_port, onu.onu_index)
    if not success:
        raise HTTPException(status_code=500, detail="REBOOT_FAILED")

    cache_delete(onu_id)
    return {"status": "SUCCESS", "message": "Reboot command sent"}

@router.post("/onus/{onu_id}/factory-reset")
async def factory_reset_onu_endpoint(onu_id: int, session: Session = Depends(get_session)):
    onu = session.get(ONU, onu_id)
    if not onu:
        raise HTTPException(status_code=404, detail="ONU not found")
    olt = session.get(OLT, onu.olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    
    success = await OLTDriver.factory_reset_onu(olt, onu.pon_port, onu.onu_index)
    if not success:
        raise HTTPException(status_code=500, detail="FACTORY_RESET_FAILED")

    cache_delete(onu_id)
    return {"status": "SUCCESS", "message": "Factory reset command sent"}

@router.get("/olts/{olt_id}/port-status")
async def get_olt_port_status(olt_id: int, session: Session = Depends(get_session)):
    """Passive fetch: link states + OLT status from background telemetry cache."""
    cached = OLT_STATUS_CACHE.get(olt_id)
    if cached:
        data = cached["data"]
        return {
            "status": data.get("status", "UNKNOWN"),
            "ports": data.get("ports", []),
            "onus_telemetry": data.get("onus_telemetry", []),
        }
    # No cache yet — OLT hasn't been probed yet this session
    return {"status": "PENDING", "ports": [], "onus_telemetry": []}


@router.get("/olts/{olt_id}/onus/signals")
async def get_olt_signals(olt_id: int, session: Session = Depends(get_session)):
    """Fetches real-time signal strength for all registered ONUs on this OLT."""
    olt = session.get(OLT, olt_id)
    if not olt:
        raise HTTPException(status_code=404, detail="OLT not found")
    
    registered_onus = session.exec(select(ONU).where(ONU.olt_id == olt_id)).all()
    if not registered_onus:
        return []

    # Map signals in parallel to speed up (limited by executor)
    import asyncio
    
    async def fetch_signal(onu):
        sig = await OLTDriver.get_onu_signal(olt, onu.pon_port, onu.onu_index)
        return {
            "id": onu.id,
            "serial_number": onu.serial_number,
            "signal_dbm": sig,
            "pon_port": onu.pon_port,
            "onu_index": onu.onu_index
        }
    
    tasks = [fetch_signal(o) for o in registered_onus]
    results = await asyncio.gather(*tasks)
    return results

@router.get("/telemetry/alerts")
async def get_telemetry_alerts(session: Session = Depends(get_session)):
    """Fetches recent signal-related alerts for the dashboard."""
    alerts = session.exec(
        select(NotificationLog)
        .where(NotificationLog.type.in_(["SIGNAL_WARNING", "SIGNAL_CRITICAL"]))
        .order_by(NotificationLog.created_at.desc())
        .limit(20)
    ).all()
    return alerts


# ─────────────────────────────────────────────
# STAFF
# ─────────────────────────────────────────────

@router.get("/staff")
async def list_staff(session: Session = Depends(get_session)):
    return session.exec(select(Staff).where(Staff.status == "ACTIVE")).all()

@router.post("/staff")
async def create_staff(staff_data: dict, session: Session = Depends(get_session)):
    staff = Staff(**staff_data)
    session.add(staff)
    session.commit()
    session.refresh(staff)
    return staff


# ─────────────────────────────────────────────
# SYSTEM CONFIG
# ─────────────────────────────────────────────

@router.get("/config")
async def get_config(session: Session = Depends(get_session)):
    return session.exec(select(SystemConfig)).all()

class ConfigUpdate(BaseModel):
    key: str
    value: str

@router.post("/config")
async def upsert_config(data: ConfigUpdate, session: Session = Depends(get_session)):
    key = data.key
    value = data.value
    existing = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
    if existing:
        existing.value = value
        existing.updated_at = datetime.utcnow()
        session.add(existing)
    else:
        session.add(SystemConfig(key=key, value=value))
    session.commit()
    return {"key": key, "value": value}

@router.post("/config/logo")
async def upload_logo(file: UploadFile = File(...), session: Session = Depends(get_session)):
    """Sube un logo local y actualiza la configuración"""
    import uuid
    os.makedirs("uploads/brand", exist_ok=True)
    
    ext = file.filename.split(".")[-1]
    filename = f"logo_{uuid.uuid4().hex[:6]}.{ext}"
    file_path = os.path.join("uploads", "brand", filename)
    full_path = os.path.join(os.getcwd(), file_path)
    
    with open(full_path, "wb") as f:
        f.write(await file.read())
        
    web_path = f"/uploads/brand/{filename}"
    
    # Actualizar config
    existing = session.exec(select(SystemConfig).where(SystemConfig.key == "invoice_logo")).first()
    if existing:
        existing.value = web_path
        existing.updated_at = datetime.utcnow()
        session.add(existing)
    else:
        session.add(SystemConfig(key="invoice_logo", value=web_path))
    
    session.commit()
    return {"status": "SUCCESS", "path": web_path}

# ─────────────────────────────────────────────
# CLIENTS & TICKETS (For Operational Dashboards)
# ─────────────────────────────────────────────

@router.get("/clients")
async def list_clients(session: Session = Depends(get_session)):
    clients = session.exec(select(Client).order_by(Client.id.desc())).all()
    # Need to return Plan names and Router IPs to make the UI rich.
    result = []
    for c in clients:
        plan = session.get(Plan, c.plan_id) if c.plan_id else None
        router_obj = session.get(Router, c.router_id) if c.router_id else None
        result.append({
            **c.dict(),
            "plan_name": plan.name if plan else "Unknown",
            "router_ip": router_obj.ip_address if router_obj else "Unknown"
        })
    return result



# ─────────────────────────────────────────────
# PLAN MANAGEMENT
# ─────────────────────────────────────────────

@router.get("/plans", response_model=List[Plan])
async def list_plans(session: Session = Depends(get_session)):
    return session.exec(select(Plan)).all()

@router.get("/plans/{plan_id}", response_model=Plan)
async def get_plan(plan_id: int, session: Session = Depends(get_session)):
    plan = session.get(Plan, plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return plan

@router.patch("/plans/{plan_id}")
async def update_plan(plan_id: int, plan_data: dict, session: Session = Depends(get_session)):
    plan = session.get(Plan, plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    # Actualizar campos
    for key, value in plan_data.items():
        if hasattr(plan, key):
            setattr(plan, key, value)
    
    session.add(plan)
    session.commit()
    session.refresh(plan)
    return plan

@router.post("/mikrotik/{router_id}/sync-plans")
async def manual_sync_plans(router_id: int, session: Session = Depends(get_session)):
    """Sincroniza manualmente los planes desde el router MikroTik."""
    router_obj = session.get(Router, router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router not found")
    
    try:
        count = await sync_mikrotik_plans(router_obj, session)
        return {"status": "SUCCESS", "synced": count}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/plans/{plan_id}")
async def delete_plan(plan_id: int, session: Session = Depends(get_session)):
    plan = session.get(Plan, plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    # Verificar si hay clientes usando este plan
    usage = session.exec(select(Client).where(Client.plan_id == plan_id)).first()
    if usage:
        raise HTTPException(status_code=400, detail="No se puede eliminar un plan en uso por clientes")
        
    session.delete(plan)
    session.commit()
    return {"status": "DELETED", "id": plan_id}

# ─────────────────────────────────────────────
# SUPPORT TICKETS (Staff Management)
# ─────────────────────────────────────────────

@router.get("/tickets")
async def admin_list_tickets(session: Session = Depends(get_session)):
    """Lista todos los tickets de soporte activos y recientes, con el nombre del cliente."""
    # Realizamos un join manual o select para traer el nombre del cliente
    statement = select(SupportTicket, Client.full_name).join(Client, SupportTicket.client_id == Client.id).order_by(SupportTicket.updated_at.desc())
    results = session.exec(statement).all()
    
    tickets_with_names = []
    for ticket, client_name in results:
        t_dict = ticket.model_dump()
        t_dict["client_name"] = client_name
        tickets_with_names.append(t_dict)
        
    return tickets_with_names

@router.get("/tickets/{ticket_id}/messages", response_model=List[TicketMessage])
async def admin_get_ticket_messages(ticket_id: int, session: Session = Depends(get_session)):
    """Obtiene el historial de chat para un ticket específico."""
    messages = session.exec(
        select(TicketMessage).where(TicketMessage.ticket_id == ticket_id).order_by(TicketMessage.created_at.asc())
    ).all()
    return messages

@router.post("/tickets/{ticket_id}/messages")
async def admin_reply_to_ticket(
    ticket_id: int, 
    data: dict, 
    session: Session = Depends(get_session)
):
    """Staff envía un mensaje al cliente."""
    ticket = session.get(SupportTicket, ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    
    msg_text = data.get("message")
    staff_id = data.get("staff_id", 1) # Fallback al admin principal si no se pasa
    staff_name = data.get("staff_name", "Soporte Técnico")

    new_msg = TicketMessage(
        ticket_id=ticket_id,
        sender_type="STAFF",
        sender_id=staff_id,
        sender_name=staff_name,
        message=msg_text
    )
    session.add(new_msg)
    
    # Marcar que el staff ha leído y respondido
    ticket.is_read_by_staff = True
    ticket.is_read_by_client = False # Notificar al cliente
    ticket.status = "RESPONDED"
    ticket.updated_at = datetime.utcnow()
    
    session.add(ticket)
    session.commit()
    return {"status": "SUCCESS"}

@router.put("/tickets/{ticket_id}/status")
async def admin_update_ticket_status(
    ticket_id: int, 
    data: dict, 
    session: Session = Depends(get_session)
):
    """Actualiza manualmente el estado de un ticket."""
    ticket = session.get(SupportTicket, ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    
    if "status" in data:
        ticket.status = data["status"]
    
    if "is_read_by_staff" in data:
        ticket.is_read_by_staff = data["is_read_by_staff"]
        
    ticket.updated_at = datetime.utcnow()
    session.add(ticket)
    session.commit()
    return {"status": "UPDATED"}

@router.put("/tickets/{ticket_id}/mark-read")
async def admin_mark_ticket_read(ticket_id: int, session: Session = Depends(get_session)):
    """Marca un ticket como leído por el staff."""
    ticket = session.get(SupportTicket, ticket_id)
    if ticket:
        ticket.is_read_by_staff = True
        session.add(ticket)
        session.commit()
    return {"status": "OK"}

@router.post("/tickets/{ticket_id}/diagnose")
async def admin_diagnose_ticket(ticket_id: int, session: Session = Depends(get_session)):
    """Ejecuta un diagnóstico en tiempo real (señal OLT) para el cliente del ticket."""
    ticket = session.get(SupportTicket, ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    
    client = session.get(Client, ticket.client_id)
    if not client or not client.onu_id:
        return {"status": "ERROR", "message": "Cliente sin ONU vinculada"}
    
    onu = session.get(ONU, client.onu_id)
    if not onu:
        return {"status": "ERROR", "message": "ONU no encontrada en DB"}
    
    olt = session.get(OLT, onu.olt_id)
    if not olt:
        return {"status": "ERROR", "message": "OLT no encontrada"}
    
    # Fetch real-time signal
    details = await OLTDriver.get_onu_details(olt, onu.pon_port, onu.onu_index, cached_ifindex=onu.snmp_ifindex)
    if details.get("snmp_ifindex") and details["snmp_ifindex"] != onu.snmp_ifindex:
        onu.snmp_ifindex = details["snmp_ifindex"]
        session.add(onu)
        session.commit()
    sig = details.get("signal_dbm")
    
    if sig is not None:
        ticket.signal_dbm = sig
        onu.signal_dbm = sig
        onu.tx_power = details.get("tx_power")
        onu.distance = details.get("distance")
        onu.last_seen = datetime.utcnow()
        session.add(ticket)
        session.add(onu)
        session.commit()
        
        return {
            "status": "SUCCESS",
            "signal_dbm": sig,
            "tx_power": details.get("tx_power"),
            "distance": details.get("distance"),
            "status_msg": details.get("status_msg", "Online")
        }
    
    return {"status": "TIMEOUT", "message": "No se pudo obtener respuesta de la OLT"}




@router.post("/test-olt-ssh")
async def test_olt_ssh(data: dict):
    """Prueba conexión SSH a una OLT."""
    ip = data.get("ip_address")
    port = data.get("ssh_port", 22)
    username = data.get("username")
    password = data.get("password")
    if not all([ip, username, password]):
        raise HTTPException(status_code=400, detail="IP, username and password required")
    
    from backend.models import OLT
    temp_olt = OLT(
        name="temp",
        ip_address=ip,
        username=username,
        password=password,
        ssh_port=port
    )
    
    client = await OLTDriver.get_ssh_client(temp_olt, retries=1)
    if client:
        await asyncio.to_thread(client.close)
        return {"online": True}
    return {"online": False}

@router.post("/test-olt-telnet")
async def test_olt_telnet(data: dict):
    """Prueba conexión Telnet a una OLT."""
    ip = data.get("ip_address")
    port = data.get("telnet_port", 23)
    username = data.get("username")
    password = data.get("password")
    if not all([ip, username, password]):
        raise HTTPException(status_code=400, detail="IP, username and password required")
    
    try:
        output = await asyncio.to_thread(
            OLTDriver._telnet_send, ip, port, username, password, []
        )
        # Check if login successful (no "Bad UserName" in output)
        if "Bad UserName or Bad Password" in output or "Telnet error" in output:
            return {"online": False}
        return {"online": True}
    except:
        return {"online": False}

@router.get("/notifications")
async def get_notifications(limit: int = 20, session: Session = Depends(get_session)):
    """Obtiene los últimos logs de notificaciones del sistema."""
    query = select(NotificationLog).order_by(NotificationLog.created_at.desc()).limit(limit)
    logs = session.exec(query).all()
    return logs
