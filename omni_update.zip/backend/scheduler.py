import asyncio
import datetime
import json
from sqlmodel import Session, select
from backend.database import engine
from backend.models import SystemConfig, Router, Client, Invoice
from backend.billing_api import suspend_overdue_clients, generate_batch_invoices, send_overdue_reminders
from backend.admin_api import internal_discover_mikrotik_clients
from backend.bcv_driver import BCVDriver

class AutomatedScheduler:
    def __init__(self):
        self.is_running = False
        self.last_runs = {
            "suspension": None,
            "billing": None,
            "bcv_refresh": None
        }

    async def start(self):
        if self.is_running:
            return
        self.is_running = True
        print("[SCHEDULER] Engine STARTED")
        asyncio.create_task(self._main_loop())

    async def _main_loop(self):
        while self.is_running:
            now = datetime.datetime.utcnow()

            # 1. DAILY SUSPENSION por mora general sin cut_off_date (Runs at 00:00 Midnight UTC)
            #    Las facturas con cut_off_date explícito las maneja el suspension_engine.
            await self._check_suspension(now)

            # 2. MONTHLY BILLING (Runs on Day 1 at 00:01)
            await self._check_monthly_billing(now)

            # 3. OVERDUE REMINDERS (Runs at 10:00 AM)
            await self._check_overdue_reminders(now)

            # 4. AUTO DISCOVERY (Every 12 hours)
            await self._check_auto_discovery(now)

            # 5. BCV REFRESH (Every 6 hours)
            await self._check_bcv_refresh(now)

            # Wait 60 seconds before next check
            await asyncio.sleep(60)



    async def _check_suspension(self, now):
        # Runs if it's 00:xx UTC and we haven't run it today yet
        if now.hour == 0:
            last_run_key = "scheduler_last_suspension_date"
            if await self._should_run_daily(last_run_key, now):
                print(f"[SCHEDULER] Executing MIDNIGHT SUSPENSION: {now}")
                with Session(engine) as session:
                    try:
                        result = await asyncio.wait_for(
                            suspend_overdue_clients(days_overdue=5, session=session),
                            timeout=45.0
                        )
                        print(f"[SCHEDULER] Suspension COMPLETE: {result.get('suspended', 0)} clients cut.")
                        self._mark_run_today(last_run_key, now)
                    except asyncio.TimeoutError:
                        print("[SCHEDULER ERROR] Suspension Task TIMED OUT after 45s.")
                    except Exception as e:
                        print(f"[SCHEDULER ERROR] Suspension failed: {e}")


    async def _check_overdue_reminders(self, now):
        # Runs at 10:00 AM
        if now.hour == 10:
            last_run_key = "scheduler_last_reminders_date"
            if await self._should_run_daily(last_run_key, now):
                print(f"[SCHEDULER] Executing OVERDUE REMINDERS: {now}")
                with Session(engine) as session:
                    try:
                        result = await send_overdue_reminders(session=session)
                        print(f"[SCHEDULER] Reminders COMPLETE: {result['notifications_sent']} messages sent.")
                        self._mark_run_today(last_run_key, now)
                    except Exception as e:
                        print(f"[SCHEDULER ERROR] Reminders failed: {e}")

    async def _check_auto_discovery(self, now):
        # Every 12 hours (0, 12)
        if now.hour in [0, 12]:
            last_run_key = "scheduler_last_discovery_date"
            run_id = f"{now.day}-{now.hour}"
            if await self._should_run_hourly(last_run_key, run_id):
                print(f"[SCHEDULER] Auto-Discovery STARTING...")
                with Session(engine) as session:
                    try:
                        routers = session.exec(select(Router)).all()
                        total_new = 0
                        for r in routers:
                            try:
                                # Discovery can be heavy, set 30s timeout per router
                                discovered = await asyncio.wait_for(
                                    internal_discover_mikrotik_clients(r, session),
                                    timeout=30.0
                                )
                                total_new += discovered
                            except asyncio.TimeoutError:
                                print(f"[SCHEDULER] Discovery TIMEOUT for router {r.name}")
                            except Exception as e:
                                print(f"[SCHEDULER ERROR] Discovery FAILED for router {r.name}: {e}")
                        
                        print(f"[SCHEDULER] Auto-Discovery Cycle OK: {total_new} new clients found.")
                        self._mark_run_hourly(last_run_key, run_id)
                    except Exception as e:
                        print(f"[SCHEDULER ERROR] Auto-Discovery failed: {e}")

    async def _check_monthly_billing(self, now):
        # Runs if it's Day 1, 00:xx and we haven't run it this month
        if now.day == 1 and now.hour == 0:
            last_run_key = "scheduler_last_billing_month"
            month_id = f"{now.month}-{now.year}"
            if await self._should_run_monthly(last_run_key, month_id):
                print(f"[SCHEDULER] Executing MONTHLY BILLING GENERATION: {month_id}")
                with Session(engine) as session:
                    try:
                        result = await generate_batch_invoices(session=session)
                        print(f"[SCHEDULER] Billing COMPLETE: {result['created']} invoices generated.")
                        self._mark_run_monthly(last_run_key, month_id)
                    except Exception as e:
                        print(f"[SCHEDULER ERROR] Billing failed: {e}")

    async def _check_bcv_refresh(self, now):
        # Every 6 hours (0, 6, 12, 18)
        if now.hour in [0, 6, 12, 18]:
            last_run_key = "scheduler_last_bcv_hour"
            run_id = f"{now.day}-{now.hour}"
            if await self._should_run_hourly(last_run_key, run_id):
                print(f"[SCHEDULER] Refreshing BCV Rate...")
                with Session(engine) as session:
                    try:
                        rate = await BCVDriver.fetch_rate()
                        if rate:
                            from backend.models import BcvRate
                            session.add(BcvRate(usd_rate=rate, source="SCHEDULER_AUTO"))
                            session.commit()
                            print(f"[SCHEDULER] BCV Refresh OK: {rate} Bs/$")
                            self._mark_run_hourly(last_run_key, run_id)
                    except Exception as e:
                        print(f"[SCHEDULER ERROR] BCV refresh failed: {e}")

    async def _should_run_daily(self, key, now):
        target_date = now.strftime("%Y-%m-%d")
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg or cfg.value != target_date:
                return True
        return False

    def _mark_run_today(self, key, now):
        target_date = now.strftime("%Y-%m-%d")
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg:
                cfg = SystemConfig(key=key, value=target_date, description="Last run date for daily task")
            else:
                cfg.value = target_date
            session.add(cfg)
            session.commit()

    async def _should_run_monthly(self, key, month_id):
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg or cfg.value != month_id:
                return True
        return False

    def _mark_run_monthly(self, key, month_id):
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg:
                cfg = SystemConfig(key=key, value=month_id, description="Last run month for billing")
            else:
                cfg.value = month_id
            session.add(cfg)
            session.commit()

    async def _should_run_hourly(self, key, run_id):
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg or cfg.value != run_id:
                return True
        return False

    def _mark_run_hourly(self, key, run_id):
        with Session(engine) as session:
            cfg = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not cfg:
                cfg = SystemConfig(key=key, value=run_id, description="Last run hour for recurring task")
            else:
                cfg.value = run_id
            session.add(cfg)
            session.commit()

# Global instances
scheduler = AutomatedScheduler()
