from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session, select, func
from typing import List, Optional
from datetime import datetime, timedelta
from backend.database import get_session
from backend.models import Staff, AttendanceLog
from pydantic import BaseModel

router = APIRouter(prefix="/api/v2/hr", tags=["HR & Attendance"])

class AttendanceRequest(BaseModel):
    pin: str
    action: str  # IN, OUT
    lat: Optional[float] = None
    lng: Optional[float] = None
    device_info: Optional[str] = None

@router.get("/staff", response_model=List[Staff])
def get_staff(session: Session = Depends(get_session)):
    return session.exec(select(Staff)).all()

@router.post("/attendance/check")
def staff_check(req: AttendanceRequest, session: Session = Depends(get_session)):
    # Validate PIN
    staff = session.exec(select(Staff).where(Staff.pin == req.pin)).first()
    if not staff:
        raise HTTPException(status_code=401, detail="PIN_INVALIDO")
    
    if staff.status != "ACTIVE":
        raise HTTPException(status_code=403, detail="PERSONAL_SUSPENDIDO")

    # Prevent double IN/OUT within 5 minutes to avoid mistakes
    last_log = session.exec(
        select(AttendanceLog)
        .where(AttendanceLog.staff_id == staff.id)
        .order_by(AttendanceLog.timestamp.desc())
    ).first()

    if last_log and (datetime.utcnow() - last_log.timestamp) < timedelta(minutes=5) and last_log.action == req.action:
        raise HTTPException(status_code=400, detail="ACCION_RECIENTE_EXISTE")

    # Create log
    new_log = AttendanceLog(
        staff_id=staff.id,
        action=req.action,
        lat=req.lat,
        lng=req.lng,
        device_info=req.device_info
    )
    session.add(new_log)
    session.commit()
    session.refresh(new_log)
    
    return {
        "status": "SUCCESS",
        "staff_name": staff.full_name,
        "action": req.action,
        "timestamp": new_log.timestamp
    }

@router.get("/attendance/logs")
def get_attendance_logs(limit: int = 20, session: Session = Depends(get_session)):
    statement = (
        select(AttendanceLog, Staff.full_name, Staff.position)
        .join(Staff)
        .order_by(AttendanceLog.timestamp.desc())
        .limit(limit)
    )
    results = session.exec(statement).all()
    
    logs = []
    for log, name, pos in results:
        logs.append({
            "id": log.id,
            "staff_name": name,
            "position": pos,
            "action": log.action,
            "timestamp": log.timestamp,
            "location": f"{log.lat}, {log.lng}" if log.lat else "OFFICE"
        })
    return logs

@router.get("/stats/summary")
def get_hr_stats(session: Session = Depends(get_session)):
    total_staff = session.exec(select(func.count(Staff.id))).one()
    active_now = session.exec(
        select(func.count(func.distinct(AttendanceLog.staff_id)))
        .where(AttendanceLog.action == "IN")
        .where(AttendanceLog.timestamp >= datetime.utcnow().replace(hour=0, minute=0, second=0))
    ).one()
    
    return {
        "total_staff": total_staff,
        "active_on_duty": active_now,
        "efficiency_avg": 94.5
    }
