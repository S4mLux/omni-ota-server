from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlmodel import Session, select, delete, func, text
from typing import List, Optional
from datetime import datetime, timedelta
from backend.database import get_session
from backend.models import (
    Client, Invoice, Transaction, NotificationLog, 
    AttendanceLog, ONUSignalHistory, Staff, SupportTicket,
    DailyConsumption, PaymentReceipt, Router, OLT, ONU, Plan
)
from backend.mikrotik_driver import MikroTikDriver, RestApiWrapper
from pydantic import BaseModel

router = APIRouter(prefix="/api/v2/root", tags=["Root Mastery"])

class WipeRequest(BaseModel):
    target: str # logs, invoices, clients, staff, all, olt
    confirm: bool

class SQLRequest(BaseModel):
    query: str
    confirm: bool

class TimeTravelRequest(BaseModel):
    table: str
    record_id: int
    new_date: str

class ShadowInvoiceRequest(BaseModel):
    client_id: int
    amount_usd: float
    description: str

class PriceAdjustRequest(BaseModel):
    percentage: float
    is_fixed: bool = False

class CLIRequest(BaseModel):
    router_id: int
    command: str

@router.get("/system/stats")
async def get_system_master_stats(session: Session = Depends(get_session)):
    return {
        "total_clients": session.exec(select(func.count(Client.id))).one(),
        "total_invoices": session.exec(select(func.count(Invoice.id))).one(),
        "total_transactions": session.exec(select(func.count(Transaction.id))).one(),
        "total_logs": session.exec(select(func.count(NotificationLog.id))).one(),
        "total_bandwidth_records": session.exec(select(func.count(DailyConsumption.id))).one(),
        "db_size_estimated": "420MB",
        "active_threads": 24,
        "last_backup": datetime.utcnow().isoformat()
    }

@router.post("/wipe")
async def root_wipe_data(req: WipeRequest, session: Session = Depends(get_session)):
    if not req.confirm:
        raise HTTPException(status_code=400, detail="MUST_CONFIRM_DESTRUCTION")
    try:
        if req.target == "logs":
            session.exec(delete(NotificationLog))
            session.exec(delete(AttendanceLog))
            session.exec(delete(ONUSignalHistory))
        elif req.target == "invoices":
            session.exec(delete(NotificationLog))
            session.exec(delete(PaymentReceipt))
            session.exec(delete(Transaction))
            session.exec(delete(Invoice))
        elif req.target == "clients":
            session.exec(delete(NotificationLog))
            session.exec(delete(SupportTicket))
            session.exec(delete(DailyConsumption))
            session.exec(delete(PaymentReceipt))
            session.exec(delete(Transaction))
            session.exec(delete(Invoice))
            session.exec(delete(Client))
        elif req.target == "staff":
            session.exec(delete(AttendanceLog))
            session.exec(delete(Staff).where(Staff.position != "ADMINISTRADOR"))
        elif req.target == "olt":
            session.execute(text("UPDATE client SET onu_id = NULL"))
            session.exec(delete(ONUSignalHistory))
            session.exec(delete(ONU))
            session.exec(delete(OLT))
        elif req.target == "all":
            session.execute(text("UPDATE client SET onu_id = NULL"))
            tables = [NotificationLog, AttendanceLog, ONUSignalHistory, PaymentReceipt, Transaction, Invoice, DailyConsumption, SupportTicket, ONU, OLT, Client]
            for table in tables:
                session.exec(delete(table))
        session.commit()
        return {"status": "SUCCESS", "message": f"Data destruction of {req.target} completed."}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/prices/adjust")
async def adjust_global_prices(req: PriceAdjustRequest, session: Session = Depends(get_session)):
    plans = session.exec(select(Plan)).all()
    for p in plans:
        if req.is_fixed:
            p.price += req.percentage
        else:
            p.price *= (1 + (req.percentage / 100))
        session.add(p)
    session.commit()
    return {"status": "PRICES_ADJUSTED", "count": len(plans)}

@router.get("/oracle/forecast")
async def get_oracle_forecast(session: Session = Depends(get_session)):
    query = text("""
        SELECT SUM(p.price) as forecast 
        FROM client c 
        JOIN plan p ON c.plan_id = p.id 
        WHERE c.status = 'ACTIVE'
    """)
    result = session.execute(query).fetchone()
    return {"forecast_usd": result[0] or 0.0}

@router.post("/cli")
async def execute_cli_command(req: CLIRequest, session: Session = Depends(get_session)):
    """REMOTE KERNEL SHELL: Dispatcher para comandos MikroTik."""
    router_obj = session.get(Router, req.router_id)
    if not router_obj: raise HTTPException(status_code=404, detail="ROUTER_NOT_FOUND")
    
    api = await MikroTikDriver.get_api(router_obj)
    if not api: raise HTTPException(status_code=500, detail="CONNECTION_FAILED")
    
    try:
        cmd = req.command.strip()
        # Limpieza básica de comando
        if cmd.endswith(" print"):
            path = cmd.replace(" print", "").strip()
            if not path.startswith("/"): path = "/" + path
            if isinstance(api, RestApiWrapper):
                output = api.get(path)
            else:
                output = list(api.path(path))
            return {"status": "SUCCESS", "output": output}
        
        # Intentar ejecutar como path directo si no tiene espacios
        if " " not in cmd:
            if not cmd.startswith("/"): cmd = "/" + cmd
            if isinstance(api, RestApiWrapper):
                output = api.get(cmd)
            else:
                output = list(api.path(cmd))
            return {"status": "SUCCESS", "output": output}

        return {"status": "PARTIAL_SUCCESS", "message": "Comando enviado, pero el parser es limitado. Usa '/path print' para mejores resultados.", "output": "COMMAND_QUEUED"}
    except Exception as e:
        return {"status": "ERROR", "detail": str(e)}
    finally:
        if hasattr(api, "close"): api.close()

@router.post("/sql")
async def execute_raw_sql(req: SQLRequest, session: Session = Depends(get_session)):
    if not req.confirm:
        raise HTTPException(status_code=400, detail="CONFIRM_REQUIRED")
    try:
        result = session.execute(text(req.query))
        session.commit()
        if req.query.lower().strip().startswith("select"):
            return {"status": "SUCCESS", "data": [dict(row) for row in result.mappings()]}
        return {"status": "SUCCESS", "rows_affected": result.rowcount}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/kill-switch")
async def emergency_kill_switch(session: Session = Depends(get_session)):
    routers = session.exec(select(Router)).all()
    results = []
    for r in routers:
        try:
            api = await MikroTikDriver.get_api(r)
            if api:
                if isinstance(api, RestApiWrapper):
                    api.post("/ppp/active/remove", {"all": "true"}) # Simulación de wipe masivo
                else:
                    actives = list(api.path("/ppp/active"))
                    for a in actives:
                        api.path("/ppp/active").remove(**{".id": a[".id"]})
                results.append({"router": r.name, "status": "KILLED"})
                api.close()
            else:
                results.append({"router": r.name, "status": "OFFLINE"})
        except:
            results.append({"router": r.name, "status": "FAILED"})
    return {"status": "BLACKOUT_COMPLETE", "results": results}

@router.patch("/time-travel")
async def neural_time_travel(req: TimeTravelRequest, session: Session = Depends(get_session)):
    try:
        new_dt = datetime.fromisoformat(req.new_date)
        col = "created_at"
        if req.table.lower() == "transaction": col = "timestamp"
        query = text(f"UPDATE {req.table} SET {col} = :dt WHERE id = :id")
        session.execute(query, {"dt": new_dt, "id": req.record_id})
        session.commit()
        return {"status": "TEMPORAL_SHIFT_SUCCESS"}
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/shadow-invoice")
async def create_shadow_invoice(req: ShadowInvoiceRequest, session: Session = Depends(get_session)):
    client = session.get(Client, req.client_id)
    if not client: raise HTTPException(status_code=404)
    new_inv = Invoice(
        client_id=client.id,
        serial_number=f"SHD-{int(datetime.utcnow().timestamp())}",
        usd_amount=req.amount_usd,
        period=datetime.utcnow().strftime("%b-%Y").upper(),
        due_date=datetime.utcnow() + timedelta(days=5),
        status="PENDING",
        is_shadow=True,
        notes=f"SHADOW_ENTRY: {req.description}"
    )
    session.add(new_inv)
    session.commit()
    return {"status": "SHADOW_CREATED", "id": new_inv.id}

@router.post("/bandwidth-bypass")
async def bandwidth_bypass(client_id: int, session: Session = Depends(get_session)):
    client = session.get(Client, client_id)
    if not client or not client.router_id: raise HTTPException(status_code=404)
    router_obj = session.get(Router, client.router_id)
    api = await MikroTikDriver.get_api(router_obj)
    try:
        if isinstance(api, RestApiWrapper):
            queues = api.get("/queue/simple", **{"target": client.ip_address})
            for q in queues:
                api.post(f"/queue/simple/{q['.id']}/remove", {})
        else:
            queues = list(api.path("/queue/simple"))
            for q in queues:
                if q.get("target", "").startswith(client.ip_address):
                    api.path("/queue/simple").remove(**{".id": q[".id"]})
        return {"status": "LIMITS_SHATTERED"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if api: api.close()

@router.post("/dns-hijack")
async def dns_hijack_client(client_id: int, active: bool, session: Session = Depends(get_session)):
    """Secuestra la conexión de un cliente para forzar redirección."""
    client = session.get(Client, client_id)
    if not client or not client.router_id: raise HTTPException(status_code=404)
    router_obj = session.get(Router, client.router_id)
    api = await MikroTikDriver.get_api(router_obj)
    try:
        list_name = "OMNI_HIJACK"
        if isinstance(api, RestApiWrapper):
            if active:
                api.put("/ip/firewall/address-list", {"list": list_name, "address": client.ip_address})
            else:
                items = api.get("/ip/firewall/address-list", **{"list": list_name, "address": client.ip_address})
                for item in items:
                    api.post(f"/ip/firewall/address-list/{item['.id']}/remove", {})
        else:
            if active:
                api.path("/ip/firewall/address-list").add(list=list_name, address=client.ip_address)
            else:
                items = list(api.path("/ip/firewall/address-list"))
                for item in items:
                    if item.get("list") == list_name and item.get("address") == client.ip_address:
                        api.path("/ip/firewall/address-list").remove(**{".id": item[".id"]})
        return {"status": "HIJACK_UPDATED", "active": active}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if api: api.close()


class ForceStatusRequest(BaseModel):
    client_id: int
    status: str # ACTIVE, MOROSO, SUSPENDED, MIGRATED, RETIRED

@router.post("/client/force-status")
async def force_client_status(req: ForceStatusRequest, session: Session = Depends(get_session)):
    """
    ROOT MASTERY: Fuerza el estatus de un cliente y sincroniza con el MikroTik.
    Útil para reconexiones manuales o cortes de emergencia sin factura.
    """
    client = session.get(Client, req.client_id)
    if not client:
        raise HTTPException(status_code=404, detail="CLIENT_NOT_FOUND")

    old_status = client.status
    client.status = req.status.upper()
    session.add(client)
    
    router_obj = session.get(Router, client.router_id) if client.router_id else None
    sync_status = "NO_ROUTER"

    if router_obj:
        try:
            if client.status == "ACTIVE":
                # Restaurar servicio
                if client.connection_type == "PPPOE":
                    await MikroTikDriver.restore_pppoe_client(router_obj, client.pppoe_user)
                else:
                    await MikroTikDriver.restore_dhcp_client(router_obj, client.ip_address, client.prev_address_list)
                sync_status = "SYNCED_ACTIVE"
            
            elif client.status in ("MOROSO", "SUSPENDED"):
                # Cortar servicio
                if client.connection_type == "PPPOE":
                    await MikroTikDriver.suspend_pppoe_client(router_obj, client.pppoe_user)
                else:
                    # Capturamos la lista real-time incluso en el forzado manual
                    captured = await MikroTikDriver.suspend_dhcp_client(router_obj, client.ip_address)
                    if captured is not False:
                        client.prev_address_list = captured
                sync_status = "SYNCED_SUSPENDED"

        except Exception as e:
            sync_status = f"SYNC_ERROR: {str(e)}"

    session.commit()
    return {
        "status": "FORCE_UPDATE_SUCCESS",
        "client": client.full_name,
        "old_status": old_status,
        "new_status": client.status,
        "mikrotik_sync": sync_status
    }

