#!/usr/bin/env python3
import sqlite3
import os

def migrate_olt_snmp():
    db_path = 'omni_isp.db'
    if not os.path.exists(db_path):
        print("Base de datos no existe")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Verificar tabla OLT
    cursor.execute('SELECT name FROM sqlite_master WHERE type="table" AND name="olt"')
    if not cursor.fetchone():
        print("Tabla OLT no existe")
        conn.close()
        return

    # Verificar y agregar columnas SNMP
    cursor.execute('PRAGMA table_info(olt)')
    columns = [row[1] for row in cursor.fetchall()]

    snmp_columns = [
        ('snmp_version', 'TEXT DEFAULT "v2c"'),
        ('snmp_username', 'TEXT'),
        ('snmp_auth_protocol', 'TEXT'),
        ('snmp_auth_password', 'TEXT'),
        ('snmp_priv_protocol', 'TEXT'),
        ('snmp_priv_password', 'TEXT')
    ]

    for col_name, col_def in snmp_columns:
        if col_name not in columns:
            try:
                cursor.execute(f'ALTER TABLE olt ADD COLUMN {col_name} {col_def}')
                print(f"✓ Agregada columna: {col_name}")
            except sqlite3.OperationalError as e:
                print(f"✗ Error agregando {col_name}: {e}")
        else:
            print(f"✓ Columna {col_name} ya existe")

    conn.commit()

    # Verificar datos
    cursor.execute('SELECT COUNT(*) FROM olt')
    count = cursor.fetchone()[0]
    print(f"Total de OLTs: {count}")

    if count > 0:
        cursor.execute('SELECT id, name, snmp_version, snmp_community, snmp_username FROM olt ORDER BY id DESC LIMIT 3')
        rows = cursor.fetchall()
        print("Últimas OLTs:")
        for row in rows:
            print(f"  ID: {row[0]}, Name: {row[1]}, Version: {row[2]}, Community: {row[3]}, Username: {row[4] or 'None'}")

    conn.close()
    print("Migración completada")

if __name__ == "__main__":
    migrate_olt_snmp()