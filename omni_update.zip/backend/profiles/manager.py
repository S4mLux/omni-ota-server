# backend/profiles/manager.py
import time
from typing import Dict, Any, Tuple
from backend.profiles import cdata_gpon, cdata_epon, vsol_legacy

_PROFILE_CACHE: Dict[int, Tuple[str, float]] = {}
_PROFILE_TTL = 300  # 5 minutes

class ProfileManager:
    """Detects and returns the hardware profile for an OLT."""

    @staticmethod
    async def get_profile_name(olt, snmp_get_func, snmp_walk_func) -> str:
        """Returns the profile name for the given OLT."""
        now = time.time()
        cached = _PROFILE_CACHE.get(olt.id)
        if cached and (now - cached[1]) < _PROFILE_TTL:
            return cached[0]

        sys_obj = await snmp_get_func(olt, "1.3.6.1.2.1.1.2.0", timeout=5, retries=1)
        profile_name = "vsol_legacy"
        
        if sys_obj and "37950" in sys_obj:
            # Check if EPON or GPON by probing the EPON MAC table
            try:
                res = await snmp_walk_func(olt, "1.3.6.1.4.1.37950.1.1.5.12.1.25.1.5")
                if res:
                    profile_name = "cdata_epon"
                else:
                    profile_name = "cdata_gpon"
            except Exception:
                profile_name = "cdata_gpon"

        _PROFILE_CACHE[olt.id] = (profile_name, now)
        return profile_name

    @staticmethod
    def get_oids(profile_name: str) -> Dict[str, str]:
        """Returns the OID dictionary for a specific profile name."""
        if profile_name == "cdata_epon":
            return cdata_epon.OIDS
        elif profile_name == "cdata_gpon":
            return cdata_gpon.OIDS
        else:
            return vsol_legacy.OIDS
