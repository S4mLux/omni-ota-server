import asyncio
from datetime import datetime
from sqlmodel import Session, select
from backend.database import engine
from backend.models import Router, HardwareMetric
from backend.mikrotik_driver import MikroTikDriver

async def poll_hardware_telemetry():
    """Servicio en segundo plano para recolectar métricas cada 5 minutos (Estilo MRTG)."""
    print("[TELEMETRY] Starting Hardware Polling Service (God-Mode MRTG)...")
    while True:
        try:
            with Session(engine) as session:
                routers = session.exec(select(Router)).all()
                for r in routers:
                    # Solo intentamos si tiene IP
                    if not r.ip_address: continue
                    
                    try:
                        # Poll SNMP
                        data = await MikroTikDriver.get_snmp_telemetry(r, interface_idx="1")
                        
                        metric = HardwareMetric(
                            router_id=r.id,
                            cpu_load=data["cpu_load"],
                            ram_usage_percent=data["ram_usage_percent"],
                            traffic_in_bytes=data["traffic_in_bytes"],
                            traffic_out_bytes=data["traffic_out_bytes"],
                            interface_name="eth1"
                        )
                        session.add(metric)
                    except Exception as e:
                        # No queremos que un router offline detenga el servicio
                        pass
                
                session.commit()
        except Exception as e:
            print(f"[TELEMETRY GLOBAL ERROR] {e}")
        
        await asyncio.sleep(300) # Intervalo de 5 minutos

async def get_historical_metrics(router_id: int, hours: int = 24):
    """Obtiene métricas históricas para graficar."""
    from datetime import timedelta
    since = datetime.utcnow() - timedelta(hours=hours)
    
    with Session(engine) as session:
        query = select(HardwareMetric).where(
            HardwareMetric.router_id == router_id,
            HardwareMetric.timestamp >= since
        ).order_by(HardwareMetric.timestamp.asc())
        
        return session.exec(query).all()
