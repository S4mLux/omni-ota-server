"""
Script de migracion completa: sincroniza omni_isp.db con todos los modelos SQLAlchemy.
Ejecutar desde la raiz del proyecto: python backend/fix_db_schema.py
"""
import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "omni_isp.db")
print(f"Conectando a: {DB_PATH}\n")

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# ─────────────────────────────────────────────
# Mapa completo: tabla -> columnas faltantes
# Basado en models.py actual
# ─────────────────────────────────────────────
MIGRATIONS = {
    "client": [
        ("address",         "TEXT"),
        ("lat",             "REAL"),
        ("lng",             "REAL"),
        ("connection_type", "TEXT DEFAULT 'DHCP'"),
        ("pppoe_user",      "TEXT"),
        ("pppoe_pass",      "TEXT"),
        ("onu_serial",      "TEXT"),
        ("onu_id",          "INTEGER"),
        ("prev_address_list","TEXT"),
        ("dhcp_server",     "TEXT DEFAULT 'all'"),
        ("address_list",    "TEXT"),
        ("auto_reconnect",  "INTEGER DEFAULT 1"),
        ("created_at",      "TEXT"),
        ("updated_at",      "TEXT"),
    ],
    "plan": [
        ("burst_limit",         "INTEGER"),
        ("priority",            "INTEGER DEFAULT 8"),
        ("mikrotik_profile",    "TEXT DEFAULT 'default'"),
        ("mikrotik_rate_limit", "TEXT"),
    ],
    "router": [
        ("api_port",        "INTEGER DEFAULT 8728"),
        ("connection_mode", "TEXT DEFAULT 'API'"),
        ("role",            "TEXT DEFAULT 'EDGE'"),
        ("status",          "TEXT DEFAULT 'ONLINE'"),
        ("last_seen",       "TEXT"),
    ],
    "olt": [
        ("username",        "TEXT DEFAULT 'admin'"),
        ("password",        "TEXT DEFAULT 'admin'"),
        ("ssh_port",        "INTEGER DEFAULT 22"),
        ("snmp_community",  "TEXT DEFAULT 'private'"),
        ("model",           "TEXT DEFAULT 'VSOL_GPON'"),
        ("status",          "TEXT DEFAULT 'ONLINE'"),
        ("last_seen",       "TEXT"),
    ],
    "onu": [
        ("vlan",        "INTEGER DEFAULT 100"),
        ("signal_dbm",  "REAL"),
        ("status",      "TEXT DEFAULT 'OFFLINE'"),
        ("last_seen",   "TEXT"),
    ],
    "supportticket": [
        ("ticket_number",   "TEXT"),
        ("assigned_tech_id","INTEGER"),
        ("refined_issue",   "TEXT"),
        ("messages",        "TEXT"),
        ("priority",        "TEXT DEFAULT 'MEDIUM'"),
        ("signal_dbm",      "REAL"),
        ("latency_ms",      "REAL"),
        ("is_router_online","INTEGER DEFAULT 1"),
        ("updated_at",      "TEXT"),
    ],
    "invoice": [
        ("serial_number",        "TEXT"),
        ("tasa_bcv",             "REAL DEFAULT 0.0"),
        ("bs_amount",            "REAL DEFAULT 0.0"),
        ("deleted_at",           "TEXT"),
        ("deleted_by",           "TEXT"),
        ("delete_justification", "TEXT"),
        ("pdf_path",             "TEXT"),
        ("notes",                "TEXT"),
    ],
    "staff": [
        ("address",     "TEXT"),
        ("position",    "TEXT DEFAULT 'OPERADOR'"),
        ("permissions", "TEXT DEFAULT '*'"),
        ("status",      "TEXT DEFAULT 'ACTIVE'"),
        ("pin",         "TEXT"),
        ("created_at",  "TEXT"),
    ],
    "notificationlog": [
        ("invoice_id",   "INTEGER"),
        ("channel",      "TEXT DEFAULT 'WHATSAPP'"),
        ("phone_number", "TEXT"),
        ("message_body", "TEXT"),
        ("created_at",  "TEXT"),
    ],
    "mikrotikpendingchange": [
        ("description", "TEXT"),
        ("created_by",  "TEXT"),
        ("applied_at",  "TEXT"),
        ("error_msg",   "TEXT"),
        ("created_at",  "TEXT"),
    ],
}

# ─────────────────────────────────────────────
# Ejecutar migraciones
# ─────────────────────────────────────────────
total_applied = 0

for table, columns in MIGRATIONS.items():
    # Verificar si la tabla existe
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
    )
    if not cursor.fetchone():
        print(f"[SKIP] Tabla '{table}' no existe aun (se creara al iniciar el backend).")
        continue

    cursor.execute(f"PRAGMA table_info({table})")
    existing = {row[1] for row in cursor.fetchall()}

    for col, coltype in columns:
        if col not in existing:
            sql = f"ALTER TABLE {table} ADD COLUMN {col} {coltype}"
            print(f"[ADD]  {table}.{col}  ({coltype})")
            cursor.execute(sql)
            total_applied += 1
        # else: silencio para no saturar output

conn.commit()
conn.close()

print(f"\n--- Migracion finalizada: {total_applied} columnas agregadas ---")
if total_applied == 0:
    print("BD ya estaba al dia. No se requirio ninguna modificacion.")
