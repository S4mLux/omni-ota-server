"""
Search API — Buscador global Omni-Search (Ctrl+K)
Busca en: Clientes, Facturas, ONUs
"""
from fastapi import APIRouter, Depends, Query
from sqlmodel import Session, select, or_
from typing import List
from backend.database import get_session
from backend.models import Client, Invoice, ONU

router = APIRouter(prefix="/api/v2/search", tags=["search"])


@router.get("/global")
async def global_search(
    q: str = Query(..., min_length=1, description="Término de búsqueda"),
    session: Session = Depends(get_session)
):
    """
    Búsqueda global unificada. Devuelve resultados categorizados de:
    - Clientes (nombre, DNI, IP, usuario PPPoE)
    - Facturas (serial, período)
    - ONUs (serial)
    """
    q = q.strip()
    if not q:
        return {"results": [], "total": 0}

    results = []

    # ── Clientes ──────────────────────────────────────────────────
    clients = session.exec(
        select(Client).where(
            or_(
                Client.full_name.ilike(f"%{q}%"),
                Client.dni.ilike(f"%{q}%"),
                Client.ip_address.ilike(f"%{q}%"),
                Client.pppoe_user.ilike(f"%{q}%"),
                Client.phone.ilike(f"%{q}%"),
            )
        ).limit(8)
    ).all()

    for c in clients:
        results.append({
            "type": "client",
            "id": c.id,
            "label": c.full_name,
            "sublabel": f"C.I: {c.dni}  ·  IP: {c.ip_address or '—'}  ·  {c.status}",
            "href": f"/clients/{c.id}",
            "status": c.status,
        })

    # ── Facturas ──────────────────────────────────────────────────
    invoices = session.exec(
        select(Invoice).where(
            Invoice.deleted_at == None,
            or_(
                Invoice.serial_number.ilike(f"%{q}%"),
                Invoice.period.ilike(f"%{q}%"),
            )
        ).limit(6)
    ).all()

    for inv in invoices:
        client = session.get(Client, inv.client_id)
        results.append({
            "type": "invoice",
            "id": inv.id,
            "label": f"Factura {inv.serial_number}",
            "sublabel": f"{client.full_name if client else '—'}  ·  ${inv.usd_amount:,.2f}  ·  {inv.status}",
            "href": f"/billing",
            "status": inv.status,
        })

    # ── ONUs ──────────────────────────────────────────────────────
    onus = session.exec(
        select(ONU).where(
            ONU.serial_number.ilike(f"%{q}%")
        ).limit(5)
    ).all()

    for onu in onus:
        results.append({
            "type": "onu",
            "id": onu.id,
            "label": f"ONU {onu.serial_number}",
            "sublabel": f"Puerto {onu.pon_port}  ·  Índice {onu.onu_index}  ·  {onu.status}",
            "href": f"/olt",
            "status": onu.status,
        })

    return {"results": results, "total": len(results), "query": q}
