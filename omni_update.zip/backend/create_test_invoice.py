import asyncio
from datetime import datetime, timedelta
from backend.database import engine
from sqlmodel import Session, select
from backend.models import Client
from backend.billing_api import create_manual_invoice, ManualInvoiceSchema

async def main():
    with Session(engine) as session:
        client = session.exec(select(Client).where(Client.full_name == "ADM")).first()
        if not client:
            print("No se encontro al cliente ADM")
            return
            
        # Para pasar la validacion, ponemos el vencimiento en el pasado
        due_time = datetime.now() - timedelta(minutes=5)
        cut_time = datetime.now() + timedelta(seconds=30)
        
        print(f"Programando factura para {client.full_name}...")
        
        body = ManualInvoiceSchema(
            client_id=client.id,
            amount_usd=1.0,
            concept="Factura de Prueba Final #9",
            due_date=due_time,
            cut_off_date=cut_time
        )
        
        # Como es una llamada directa al endpoint, le pasamos el body
        inv = await create_manual_invoice(body=body, session=session)
        
        print(f"Factura #{inv.id} creada exitosamente.")
        print(f"CORTE PROGRAMADO PARA: {cut_time.strftime('%H:%M:%S')}")
        print("POR FAVOR MIRA EL LOG DEL BACKEND EN 30 SEGUNDOS...")

if __name__ == "__main__":
    asyncio.run(main())
