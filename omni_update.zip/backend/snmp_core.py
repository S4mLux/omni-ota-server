import asyncio
from typing import Optional, Dict, Any, List

async def snmp_get(host: str, community: str, oid: str, version: str = "v2c", port: int = 161) -> Optional[str]:
    """Helper genérico para GET SNMP async."""
    try:
        from pysnmp.hlapi.v3arch.asyncio import (
            SnmpEngine, UdpTransportTarget, ContextData,
            ObjectType, ObjectIdentity, get_cmd, CommunityData
        )
        
        mp_model = 0 if version == "v1" else 1
        auth = CommunityData(community, mpModel=mp_model)
        
        engine = SnmpEngine()
        transport = await UdpTransportTarget.create((host, port), timeout=5, retries=1)
        
        errorIndication, errorStatus, errorIndex, varBinds = await get_cmd(
            engine, auth, transport, ContextData(),
            ObjectType(ObjectIdentity(oid))
        )
        
        result = None
        if not (errorIndication or errorStatus):
            val = str(varBinds[0][1])
            if val not in ("No Such Object", "No Such Instance", ""):
                result = val

        engine.close_dispatcher()
        return result
    except Exception as e:
        print(f"[SNMP_CORE ERROR] {host} oid={oid}: {e}")
        return None

async def snmp_walk(host: str, community: str, oid: str, version: str = "v2c", port: int = 161) -> List[Dict[str, str]]:
    """Helper genérico para WALK SNMP async."""
    try:
        from pysnmp.hlapi.v3arch.asyncio import (
            SnmpEngine, UdpTransportTarget, ContextData,
            ObjectType, ObjectIdentity, next_cmd, CommunityData
        )
        
        mp_model = 0 if version == "v1" else 1
        auth = CommunityData(community, mpModel=mp_model)
        
        engine = SnmpEngine()
        transport = await UdpTransportTarget.create((host, port), timeout=8, retries=1)
        
        results = []
        # El comando next_cmd genera un generador asíncrono para el walk
        gen = next_cmd(
            engine, auth, transport, ContextData(),
            ObjectType(ObjectIdentity(oid)),
            lexicographicMode=False
        )
        
        async for errorIndication, errorStatus, errorIndex, varBinds in gen:
            if errorIndication or errorStatus:
                break
            for varBind in varBinds:
                results.append({
                    "oid": str(varBind[0]),
                    "value": str(varBind[1])
                })
        
        engine.close_dispatcher()
        return results
    except Exception as e:
        print(f"[SNMP_CORE WALK ERROR] {host} oid={oid}: {e}")
        return []

# OIDs Estándar para MikroTik / Hardware General
OID_CPU_LOAD     = ".1.3.6.1.2.1.25.3.3.1.2.1"
OID_MEMORY_TOTAL = ".1.3.6.1.2.1.25.2.3.1.5.65536"
OID_MEMORY_USED  = ".1.3.6.1.2.1.25.2.3.1.6.65536"
OID_UPTIME       = ".1.3.6.1.2.1.25.1.1.0"
OID_IF_DESCR     = ".1.3.6.1.2.1.2.2.1.2"
OID_IF_IN        = ".1.3.6.1.2.1.2.2.1.10"
OID_IF_OUT       = ".1.3.6.1.2.1.2.2.1.16"
