"""
Script de migración segura de la base de datos.
Agrega columnas nuevas a tablas existentes sin borrar datos.
Run: python backend/migrate_db.py
"""
import sqlite3
import os
from sqlmodel import SQLModel, create_engine
from backend.models import (
    Router, Client, Plan, OLT, ONU, Transaction, SupportTicket,
    DDoS_Event, Staff, DailyConsumption, SystemConfig,
    Sale, Installation, Invoice, PaymentReceipt,
    MikrotikPendingChange, BcvRate
)

DATABASE_URL = "sqlite:///omni_isp.db"
engine = create_engine(DATABASE_URL, echo=False)

def migrate():
    print("[MIGRATE] Creando/actualizando tablas...")
    SQLModel.metadata.create_all(engine)
    print("[MIGRATE] Tablas base creadas/verificadas.")

    # Migraciones manuales: agregar columnas que pueden no existir en tablas viejas
    db_path = "omni_isp.db"
    if not os.path.exists(db_path):
        print("[MIGRATE] No existe DB aún, se creará al iniciar el backend.")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Columns to add: (table, column, definition)
    new_columns = [
        # Client
        ("client", "prev_address_list", "TEXT"),
        ("client", "dhcp_server", "TEXT DEFAULT 'all'"),
        ("client", "pppoe_pass", "TEXT"),
        ("client", "address_list", "TEXT"),
        ("client", "onu_serial", "TEXT"),
        # Plan
        ("plan", "mikrotik_rate_limit", "TEXT"),
        # Installation
        ("installation", "onu_serial_photo_path", "TEXT"),
        ("installation", "onu_serial_written", "TEXT"),
        # Invoice
        ("invoice", "serial_number", "TEXT"),
        ("invoice", "usd_amount", "REAL DEFAULT 0.0"),
        ("invoice", "bs_amount", "REAL DEFAULT 0.0"),
        ("invoice", "tasa_bcv", "REAL DEFAULT 0.0"),
        ("invoice", "period", "TEXT"),
        ("invoice", "due_date", "TEXT"),
        ("invoice", "paid_at", "TEXT"),
        ("invoice", "deleted_at", "TEXT"),
        ("invoice", "deleted_by", "TEXT"),
        ("invoice", "delete_justification", "TEXT"),
        ("invoice", "pdf_path", "TEXT"),
        # Staff
        ("staff", "pin", "TEXT"),
        # SupportTicket
        ("supportticket", "ticket_number", "TEXT"),
        ("supportticket", "assigned_tech_id", "INTEGER"),
        ("supportticket", "messages", "TEXT"),
        ("supportticket", "refined_issue", "TEXT"),
        # OLT SNMP fields
        ("olt", "snmp_version", "TEXT DEFAULT 'v2c'"),
        ("olt", "snmp_username", "TEXT"),
        ("olt", "snmp_auth_protocol", "TEXT"),
        ("olt", "snmp_auth_password", "TEXT"),
        ("olt", "snmp_priv_protocol", "TEXT"),
        ("olt", "snmp_priv_password", "TEXT"),
    ]

    for table, col, col_def in new_columns:
        try:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_def}")
            print(f"[MIGRATE] Added: {table}.{col}")
        except sqlite3.OperationalError as e:
            if "duplicate column name" in str(e).lower():
                pass  # Ya existe
            elif "no such table" in str(e).lower():
                pass  # Tabla nueva, se creará con SQLModel
            else:
                print(f"[MIGRATE WARN] {table}.{col}: {e}")

    conn.commit()
    conn.close()
    print("[MIGRATE] OK - Migracion completada.")

if __name__ == "__main__":
    migrate()
