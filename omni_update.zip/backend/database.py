from sqlmodel import create_engine, Session
from sqlalchemy.pool import StaticPool
from sqlalchemy import event
import os

# Ruta absoluta relativa a este archivo para evitar crear múltiples DBs
# según el directorio de trabajo desde donde se lanza uvicorn.
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_URL = f"sqlite:///{os.path.join(_BASE_DIR, 'omni_isp.db')}"

engine = create_engine(
    DATABASE_URL, 
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)

@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.close()

def get_session():
    with Session(engine) as session:
        yield session
