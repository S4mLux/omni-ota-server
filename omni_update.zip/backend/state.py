# Global shared state for hardware telemetry
OLT_STATUS_CACHE = {} # {id: {"data": dict, "timestamp": float}}
ROUTERS_POOL = {}
PPPOE_SESSIONS_CACHE = {} # {router_id: set(active_usernames)}
