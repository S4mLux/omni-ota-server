from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List, Dict, Any
from backend.models import Staff, SystemConfig
from backend.database import get_session
from datetime import datetime

router = APIRouter(prefix="/api/v2/admin", tags=["admin-staff"])

# --- STAFF MANAGEMENT ---

@router.get("/staff", response_model=List[Staff])
async def list_staff(session: Session = Depends(get_session)):
    return session.exec(select(Staff)).all()

@router.post("/staff", response_model=Staff)
async def create_staff(member: Staff, session: Session = Depends(get_session)):
    session.add(member)
    session.commit()
    session.refresh(member)
    return member

@router.put("/staff/{staff_id}", response_model=Staff)
async def update_staff(staff_id: int, member_update: Staff, session: Session = Depends(get_session)):
    db_member = session.get(Staff, staff_id)
    if not db_member:
        raise HTTPException(status_code=404, detail="Staff member not found")
        
    member_data = member_update.model_dump(exclude_unset=True)
    for key, value in member_data.items():
        setattr(db_member, key, value)
        
    session.add(db_member)
    session.commit()
    session.refresh(db_member)
    return db_member

@router.delete("/staff/{staff_id}")
async def delete_staff(staff_id: int, session: Session = Depends(get_session)):
    member = session.get(Staff, staff_id)
    if not member:
        raise HTTPException(status_code=404, detail="Staff member not found")
    session.delete(member)
    session.commit()
    return {"status": "DELETED", "id": staff_id}

# --- SYSTEM CONFIG (API KEYS) ---

@router.get("/config", response_model=List[SystemConfig])
async def get_all_config(session: Session = Depends(get_session)):
    return session.exec(select(SystemConfig)).all()

@router.post("/config", response_model=SystemConfig)
async def set_config(config: SystemConfig, session: Session = Depends(get_session)):
    existing = session.exec(select(SystemConfig).where(SystemConfig.key == config.key)).first()
    if existing:
        existing.value = config.value
        existing.description = config.description
        existing.updated_at = datetime.utcnow()
        session.add(existing)
        session.commit()
        session.refresh(existing)
        return existing
    
    session.add(config)
    session.commit()
    session.refresh(config)
    return config

@router.get("/config/{key}")
async def get_config_by_key(key: str, session: Session = Depends(get_session)):
    config = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
    if not config:
        return {"key": key, "value": None}
    return config
