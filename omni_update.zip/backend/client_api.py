from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Response
from fastapi.responses import HTMLResponse
from sqlmodel import Session, select, func
from typing import List, Dict, Any, Optional
from backend.models import Client, Invoice, DailyConsumption, Plan, Router, SupportTicket, TicketMessage, PaymentReceipt, SystemConfig
from backend.database import get_session
from backend.auth_api import verify_token, generate_download_signature, verify_download_signature
from backend.bcv_driver import BCVDriver
from backend.mikrotik_driver import MikroTikDriver
from datetime import datetime
import os
import uuid

router = APIRouter(prefix="/api/v2/client", tags=["client-portal"])

# ─── Auth Dependency ──────────────────────────────────────────────────

async def get_current_client(
    token: str = Query(...), 
    session: Session = Depends(get_session)
) -> Client:
    payload = verify_token(token)
    if not payload or payload.get("type") != "CLIENT":
        raise HTTPException(status_code=401, detail="Token inválido o expirado")
    
    client = session.get(Client, payload["id"])
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    return client

# ─── Dashboard & Data ─────────────────────────────────────────────────

@router.get("/dashboard")
async def get_client_dashboard(
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Consolidated view for the client portal dashboard."""
    plan = session.get(Plan, client.plan_id)
    
    # Get last 7 days consumption
    consumption = session.exec(
        select(DailyConsumption)
        .where(DailyConsumption.client_id == client.id)
        .order_by(DailyConsumption.date.desc())
        .limit(7)
    ).all()
    
    # Get pending balance
    pending_total = session.exec(
        select(func.sum(Invoice.usd_amount))
        .where(Invoice.client_id == client.id)
        .where(Invoice.status == "PENDING")
    ).first() or 0.0
    
    # Get current BCV Rate
    bcv_rate = await BCVDriver.get_or_fetch_rate(session)
    
    # Get Portal Speedtest Config
    speedtest_config = session.exec(
        select(SystemConfig).where(SystemConfig.key == "portal_speedtest_url")
    ).first()
    speedtest_url = speedtest_config.value if speedtest_config else "https://openspeedtest.com/get-widget.php?theme=dark"
    
    # Get Payment & Suspension Configs
    all_configs = session.exec(select(SystemConfig)).all()
    cfg_map = {c.key: c.value for c in all_configs}
    
    pm_info = {
        "bank": cfg_map.get("billing_pm_bank", "Bancamiga"),
        "rif": cfg_map.get("billing_pm_rif", "J-00000000-0"),
        "phone": cfg_map.get("billing_pm_phone", "0412-000-0000"),
        "name": cfg_map.get("invoice_name", "OMNI_ISP C.A.")
    }
    
    cutoff_days = int(cfg_map.get("overdue_days_cutoff", "5"))
    
    # Real-time traffic from MikroTik
    realtime_traffic = {"download_mb": 0, "upload_mb": 0, "total_mb": 0, "online": False}
    router_obj = session.get(Router, client.router_id)
    if router_obj:
        realtime_traffic = await MikroTikDriver.get_client_traffic_realtime(router_obj, client)
    
    return {
        "client": {
            "id": client.id,
            "name": client.full_name,
            "dni": client.dni,
            "email": client.email,
            "phone": client.phone,
            "address": client.address,
            "status": client.status,
            "plan_name": plan.name if plan else "Unknown",
            "ip_address": client.ip_address,
            "onu_serial": client.onu_serial
        },
        "balance": {
            "pending_amount": round(pending_total, 2),
            "currency": "USD"
        },
        "consumption": [
            {"date": c.date.strftime("%Y-%m-%d"), "download": c.download_mb, "upload": c.upload_mb}
            for c in reversed(consumption) # Show chronological order in charts
        ],
        "telemetry": {
            "latency_ms": client.last_latency_ms or 0,
            "signal_dbm": client.last_signal_dbm or 0,
            "status": "OPTIMAL" if (client.last_signal_dbm or -100) > -27 else "REVISAR"
        },
        "bcv_rate": {
            "rate": bcv_rate,
            "formatted": f"Bs. {bcv_rate:,.2f}"
        },
        "speedtest_url": speedtest_url,
        "payment_info": pm_info,
        "cutoff_days": cutoff_days,
        "realtime_consumption": realtime_traffic
    }

@router.get("/invoices")
async def get_client_invoices(
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Retorna el historial de facturas del cliente autenticado."""
    invoices = session.exec(
        select(Invoice)
        .where(Invoice.client_id == client.id)
        .order_by(Invoice.created_at.desc())
    ).all()
    return invoices

@router.get("/invoices/{invoice_id}/secure-link")
async def get_invoice_secure_link(
    invoice_id: int, 
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Genera un enlace firmado temporal para descargar la factura sin exponer el token JWT."""
    inv = session.get(Invoice, invoice_id)
    if not inv or inv.client_id != client.id:
        raise HTTPException(status_code=404, detail="Factura no encontrada")
    
    # Generar firma válida por 15 minutos
    signed_data = generate_download_signature(f"inv_{invoice_id}", client.id)
    return {
        "invoice_id": invoice_id,
        "sig": signed_data["sig"],
        "expires": signed_data["expires"]
    }

@router.get("/tickets")
async def get_client_tickets(
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    tickets = session.exec(
        select(SupportTicket)
        .where(SupportTicket.client_id == client.id)
        .order_by(SupportTicket.created_at.desc())
    ).all()
    return tickets

@router.get("/notifications")
async def get_client_notifications(
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Retorna las últimas 20 notificaciones/alertas del cliente."""
    from backend.models import NotificationLog
    logs = session.exec(
        select(NotificationLog)
        .where(NotificationLog.client_id == client.id)
        .order_by(NotificationLog.created_at.desc())
        .limit(20)
    ).all()
    return logs

# ─── Operations (Payments & Tickets) ──────────────────────────────────

@router.post("/report-payment")
async def report_payment(
    invoice_id: int = Form(...),
    bank: str = Form(...),
    reference: str = Form(...),
    amount_bs: float = Form(...),
    sender_phone: str = Form(...),
    date: str = Form(...),
    capture: UploadFile = File(...),
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    # Validar factura
    invoice = session.get(Invoice, invoice_id)
    if not invoice or invoice.client_id != client.id:
        raise HTTPException(status_code=400, detail="Factura inválida")

    # Guardar archivo
    os.makedirs("uploads/payments", exist_ok=True)
    ext = capture.filename.split(".")[-1]
    filename = f"PAY_{uuid.uuid4().hex[:8]}.{ext}"
    file_path = f"uploads/payments/{filename}"
    
    with open(file_path, "wb") as f:
        f.write(await capture.read())

    # Crear comprobante
    receipt = PaymentReceipt(
        invoice_id=invoice_id,
        client_id=client.id,
        bank=bank,
        reference_number=reference, # Idealmente validar últimos 6 digitos en front o aquí
        amount_paid_bs=amount_bs,
        sender_phone=sender_phone,
        photo_path=f"/uploads/payments/{filename}",
        notes=f"Reportado desde el portal el {date}",
        status="PENDIENTE"
    )
    
    session.add(receipt)
    session.commit()
    return {"status": "SUCCESS", "message": "Pago reportado. Un analista lo verificará pronto."}

@router.post("/create-ticket")
async def create_portal_ticket(
    subject: str = Form(...),
    description: str = Form(...),
    photo: Optional[UploadFile] = File(None),
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    try:
        # Guardar foto si existe
        photo_url = None
        if photo and photo.filename:
            # Asegurar existencia de carpeta con ruta absoluta para evitar ambigüedades
            target_dir = os.path.join(os.getcwd(), "uploads", "tickets")
            os.makedirs(target_dir, exist_ok=True)
            
            ext = photo.filename.split(".")[-1]
            if not ext or ext == photo.filename: ext = "jpg" # Fallback
            
            filename = f"TIC_{uuid.uuid4().hex[:8]}.{ext}"
            file_path = os.path.join(target_dir, filename)
            
            content = await photo.read()
            with open(file_path, "wb") as f:
                f.write(content)
            
            photo_url = f"/uploads/tickets/{filename}"

        ticket_num = f"TIC-{uuid.uuid4().hex[:6].upper()}"
        ticket = SupportTicket(
            ticket_number=ticket_num,
            client_id=client.id,
            subject=subject,
            description=description,
            status="OPEN",
            priority="MEDIUM",
            photo_path=photo_url,
            # Defensive defaults to bypass NOT NULL constraints in existing legacy schema
            refined_issue="",
            messages="[]",
            signal_dbm=0.0,
            latency_ms=0.0,
            is_router_online=True
        )
        
        print(f"[TICKET_DB] Adding ticket {ticket_num} for client {client.id}...")
        session.add(ticket)
        session.commit()
        print(f"[TICKET_SUCCESS] Ticket {ticket_num} created.")
        return {"status": "SUCCESS", "id": ticket.id, "number": ticket_num}
    except Exception as e:
        print(f"[TICKET_ERROR] critical failure: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error interno (Debug): {str(e)}")

@router.put("/profile")
async def update_client_profile(
    data: Dict[str, Any],
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Allows client to update their personal information."""
    if "full_name" in data: client.full_name = data["full_name"]
    if "email" in data: client.email = data["email"]
    if "phone" in data: client.phone = data["phone"]
    if "address" in data: client.address = data["address"]
    if "portal_password" in data and data["portal_password"]:
        client.portal_password = data["portal_password"]
    
    client.updated_at = datetime.utcnow()
    session.add(client)
    session.commit()
    return {"status": "SUCCESS", "message": "Perfil actualizado correctamente"}

# ─── Real Speed Test Endpoints ────────────────────────────────────────

@router.get("/speedtest/download")
async def speedtest_download(
    client: Client = Depends(get_current_client)
):
    """Returns a 10MB stream of random-like data for speed testing."""
    import secrets
    from fastapi.responses import StreamingResponse
    import io

    # Generamos 10MB de datos (en chunks para no saturar memoria)
    def generate_data():
        chunk_size = 1024 * 1024 # 1MB
        for _ in range(10): # 10MB total
            yield secrets.token_bytes(chunk_size)

    return StreamingResponse(
        generate_data(),
        media_type="application/octet-stream",
        headers={"Content-Disposition": "attachment; filename=speedtest.bin"}
    )

@router.post("/speedtest/upload")
async def speedtest_upload(
    file: UploadFile = File(...),
    client: Client = Depends(get_current_client)
):
    """Receives data to measure upload speed and discards it immediately."""
    # Simplemente leemos el archivo para medir el tiempo de transferencia
    bytes_received = 0
    while True:
        chunk = await file.read(1024 * 1024) # Leer en chunks de 1MB
        if not chunk:
            break
        bytes_received += len(chunk)
    
    return {"status": "SUCCESS", "received": bytes_received}

@router.get("/tickets/{ticket_id}/messages", response_model=List[TicketMessage])
async def get_ticket_messages(
    ticket_id: int,
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Retrieve all messages for a specific ticket if owned by the client."""
    ticket = session.get(SupportTicket, ticket_id)
    if not ticket or ticket.client_id != client.id:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
        
    return session.exec(
        select(TicketMessage)
        .where(TicketMessage.ticket_id == ticket_id)
        .order_by(TicketMessage.created_at.asc())
    ).all()

@router.post("/tickets/{ticket_id}/messages")
async def send_ticket_message(
    ticket_id: int,
    message: str = Form(...),
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Post a new message to a ticket."""
    ticket = session.get(SupportTicket, ticket_id)
    if not ticket or ticket.client_id != client.id:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    
    new_msg = TicketMessage(
        ticket_id=ticket_id,
        sender_type="CLIENT",
        sender_id=client.id,
        sender_name=client.full_name,
        message=message
    )
    session.add(new_msg)
    
    # Update ticket meta
    ticket.is_read_by_staff = False # Notify Staff
    ticket.is_read_by_client = True # Client just sent it
    ticket.status = "OPEN" # Re-open if it was responded
    ticket.updated_at = datetime.utcnow()
    session.add(ticket)
    
    session.commit()
    return {"status": "success"}

@router.put("/tickets/{ticket_id}/mark-read")
async def client_mark_ticket_read(
    ticket_id: int,
    client: Client = Depends(get_current_client),
    session: Session = Depends(get_session)
):
    """Marca un ticket como leído por el cliente."""
    ticket = session.get(SupportTicket, ticket_id)
    if ticket and ticket.client_id == client.id:
        ticket.is_read_by_client = True
        session.add(ticket)
        session.commit()
    return {"status": "OK"}


@router.get("/invoices/{invoice_id}/html", response_class=HTMLResponse)
async def get_client_invoice_html(
    invoice_id: int,
    token: Optional[str] = Query(None),
    sig: Optional[str] = Query(None),
    expires: Optional[int] = Query(None),
    session: Session = Depends(get_session)
):
    """Genera una vista HTML imprimible de la factura, permitiendo Token JWT o Firma Temporal."""
    # 1. Autenticación: Token o Firma
    client_id = None
    if token:
        payload = verify_token(token)
        if payload and payload.get("type") == "CLIENT":
            client_id = payload["id"]
    
    if not client_id and sig and expires:
        # Intentamos validar por firma (requiere saber el dueño de la factura primero)
        inv_tmp = session.get(Invoice, invoice_id)
        if inv_tmp:
            if verify_download_signature(f"inv_{invoice_id}", inv_tmp.client_id, sig, expires):
                client_id = inv_tmp.client_id

    if not client_id:
        raise HTTPException(status_code=401, detail="Autorización insuficiente para ver este recurso")

    # 2. Cargar factura y validar propiedad
    inv = session.get(Invoice, invoice_id)
    if not inv or inv.client_id != client_id:
        return HTMLResponse(content="<h1>404 - Factura no encontrada</h1>", status_code=404)
    
    client = session.get(Client, client_id)
    if not client:
        return HTMLResponse(content="<h1>404 - Cliente no vinculado</h1>", status_code=404)
    
    # Cargar configuraciones de factura
    configs = session.exec(select(SystemConfig)).all()
    cfg = {c.key: c.value for c in configs}
    
    comp_name = cfg.get("invoice_name", "OMNI_ISP C.A.")
    comp_rif  = cfg.get("invoice_rif", "J-50123456-0")
    comp_addr = cfg.get("invoice_address", "Barquisimeto, Edo. Lara")
    comp_tel  = cfg.get("invoice_phone", "0412-000-0000")
    comp_mail = cfg.get("invoice_email", "facturacion@omni.net")
    comp_logo = cfg.get("invoice_logo", "")
    comp_note = cfg.get("invoice_notes", "Esta es una factura digital emitida automáticamente por el sistema Omni-ISP Engine v2.0.")

    # Estilos del documento (Reusando template profesional)
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Factura {inv.serial_number}</title>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; margin: 0; padding: 40px; background: #fff; }}
            .invoice-box {{ max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0, 0, 0, .15); font-size: 16px; line-height: 24px; color: #555; position: relative; }}
            .watermark {{ position: absolute; top: 40%; left: 20%; font-size: 100px; opacity: 0.1; transform: rotate(-45deg); font-weight: bold; pointer-events: none; }}
            .header {{ display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }}
            .logo-container {{ display: flex; align-items: center; gap: 15px; }}
            .logo-img {{ max-width: 150px; max-height: 60px; object-fit: contain; }}
            .logo-text {{ font-size: 32px; font-weight: 900; color: #10b981; letter-spacing: -1px; }}
            .info-row {{ display: flex; justify-content: space-between; margin-bottom: 20px; }}
            .info-col {{ flex: 1; }}
            table {{ width: 100%; line-height: inherit; text-align: left; border-collapse: collapse; margin-top: 20px; }}
            table th {{ background: #f8f9fa; border-bottom: 2px solid #eee; padding: 12px; font-weight: bold; text-transform: uppercase; font-size: 12px; }}
            table td {{ padding: 12px; border-bottom: 1px solid #eee; vertical-align: top; }}
            .total-section {{ margin-top: 30px; border-top: 2px solid #10b981; padding-top: 20px; text-align: right; }}
            .total-row {{ font-size: 18px; margin-bottom: 8px; }}
            .grand-total {{ font-size: 24px; font-weight: 900; color: #10b981; margin-top: 10px; }}
            .footer {{ margin-top: 50px; text-align: center; font-size: 12px; color: #999; border-top: 1px solid #eee; padding-top: 20px; }}
            @media print {{ .no-print {{ display: none; }} }}
        </style>
    </head>
    <body onload="if(window.location.search.includes('print')) window.print()">
        <div class="invoice-box">
            <div class="watermark" style="color: {'#10b981' if inv.status == 'PAID' else '#ef4444'}">
                {inv.status}
            </div>
            
            <div class="header">
                <div>
                     <div class="logo-container">
                        {f'<img src="{comp_logo}" class="logo-img" alt="Logo">' if comp_logo else f'<div class="logo-text">{comp_name}</div>'}
                    </div>
                    <p><strong>{comp_name}</strong><br>
                    RIF: {comp_rif}<br>
                    {comp_addr}<br>
                    {comp_tel} | {comp_mail}</p>
                </div>
                <div style="text-align: right;">
                    <h2 style="margin:0; color: #10b981;">FACTURA DIGITAL</h2>
                    <p><strong>N° {inv.serial_number}</strong><br>
                    Emisión: {inv.created_at.strftime('%d/%m/%Y')}<br>
                    Vencimiento: {inv.due_date.strftime('%d/%m/%Y')}</p>
                </div>
            </div>

            <div class="info-row">
                <div class="info-col">
                    <strong>CLIENTE:</strong><br>
                    {client.full_name}<br>
                    C.I./RIF: {client.dni}<br>
                    Dir: {client.address or 'Sin dirección registrada'}
                </div>
                <div class="info-col" style="text-align: right;">
                    <strong>PERIODO:</strong> {inv.period}<br>
                    <strong>ESTADO:</strong> <span style="color: {'#10b981' if inv.status == 'PAID' else '#ef4444'}">{inv.status}</span>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Descripción</th>
                        <th style="text-align: center;">Cant.</th>
                        <th style="text-align: right;">Monto (USD)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Servicio de Internet Banda Ancha - Plan Mensual</td>
                        <td style="text-align: center;">1</td>
                        <td style="text-align: right;">${inv.usd_amount:,.2f}</td>
                    </tr>
                </tbody>
            </table>

            <div class="total-section">
                <div class="total-row">Subtotal: <strong>${inv.usd_amount:,.2f} USD</strong></div>
                <div class="total-row" style="color: #666; font-size: 14px;">
                    Tasa BCV del día: <strong>{inv.tasa_bcv:,.4f} Bs/$</strong>
                </div>
                <div class="grand-total">
                    Total a Pagar: Bs. {inv.bs_amount:,.2f}
                </div>
            </div>

            <div class="footer">
                <p>{comp_note}</p>
                <div class="no-print" style="margin-top: 20px;">
                    <button onclick="window.print()" style="padding: 10px 20px; background: #10b981; color: #fff; border: none; border-radius: 8px; cursor: pointer;">Imprimir o Guardar PDF</button>
                </div>
                <p style="margin-top:20px; font-size: 10px;">ID Operación: {inv.id} | Hash: {hash(inv.serial_number)}</p>
            </div>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)
