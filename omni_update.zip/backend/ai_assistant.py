import asyncio
from datetime import datetime
from typing import Dict, Any
from sqlmodel import Session, select
from backend.models import Client, Router, SupportTicket
from backend.mikrotik_driver import MikroTikDriver
from backend.database import engine

class NeuralAssistant:
    @staticmethod
    async def perform_neural_scan(client_id: int) -> Dict[str, Any]:
        """Runs a real-time diagnostic scan for a specific client."""
        with Session(engine) as session:
            client = session.get(Client, client_id)
            if not client:
                return {"error": "Client not found"}
            
            router = session.get(Router, client.router_id)
            if not router:
                return {"error": "Target router not found"}
            
            # Fetch real-time telemetry from hardware
            telemetry = await MikroTikDriver.get_client_telemetry(router, client.ip_address)
            
            # Record diagnostic in DB (optional logging)
            client.last_signal_dbm = telemetry.get("signal_dbm")
            client.last_latency_ms = telemetry.get("latency_ms")
            session.add(client)
            session.commit()
            
            return {
                "client_name": client.full_name,
                "telemetry": telemetry,
                "recommendation": NeuralAssistant.generate_recommendation(telemetry)
            }

    @staticmethod
    def generate_recommendation(telemetry: Dict[str, Any]) -> str:
        """Heuristic logic to provide guidance based on technical stats."""
        dbm = telemetry.get("signal_dbm", 0)
        latency = telemetry.get("latency_ms", 0)
        
        if dbm < -30:
            return "ALERTA_FISICA: Señal extremadamente baja. Posible cable de fibra dañado o desconectado."
        if latency > 150:
            return "ALERTA_CONGESTION: Latencia inestable. Verificar procesos de descarga en segundo plano o interferencia Wi-Fi."
        return "SISTEMA_NOMINAL: La conexión física es estable. El problema podría ser lógico o de configuración de dispositivo."

    @staticmethod
    async def create_refined_ticket(client_id: int, description: str, ai_refined: str) -> SupportTicket:
        """Automates ticket creation after AI interaction."""
        with Session(engine) as session:
            client = session.get(Client, client_id)
            if not client:
                raise ValueError(f"Client {client_id} not found")

            router = session.get(Router, client.router_id)
            if not router:
                raise ValueError(f"Router {client.router_id} not found for client {client_id}")

            # Re-run scan for final snapshot
            telemetry = await MikroTikDriver.get_client_telemetry(router, client.ip_address)

            # Generar ticket_number único (campo requerido UNIQUE)
            last_ticket = session.exec(select(SupportTicket).order_by(SupportTicket.id.desc())).first()
            seq = (last_ticket.id + 1) if last_ticket else 1
            ticket_number = f"TIC-{seq:05d}"

            ticket = SupportTicket(
                ticket_number=ticket_number,
                client_id=client_id,
                subject=f"AI_REFINE: {ai_refined[:50]}...",
                description=description,
                refined_issue=ai_refined,
                signal_dbm=telemetry.get("signal_dbm"),
                latency_ms=telemetry.get("latency_ms"),
                is_router_online=(telemetry.get("status") == "ONLINE")
            )

            # Asignación automática de prioridad
            if telemetry.get("signal_dbm") and telemetry["signal_dbm"] < -32 or telemetry.get("status") == "OFFLINE":
                ticket.priority = "CRITICAL"

            session.add(ticket)
            session.commit()
            session.refresh(ticket)
            return ticket
