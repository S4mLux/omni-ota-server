import asyncio
from sqlmodel import SQLModel, create_engine, Session, select
from backend.models import Router, Plan, Client
from backend.database import DATABASE_URL, engine

# Create the engine
# No es necesario crear el engine aquí pues ya viene de backend.database

def init_db():
    print("[OMNI] Initializing SQLite Neural Database...")
    SQLModel.metadata.create_all(engine)
    
    with Session(engine) as session:
        # Initial Plans
        if not session.exec(select(Plan)).first():
            print("[OMNI] Seeding default service plans...")
            p1 = Plan(name="Alien-Basic", download_limit=50, upload_limit=20, price=29.99)
            p2 = Plan(name="Alien-Pro", download_limit=200, upload_limit=100, price=59.99)
            p3 = Plan(name="Hyper-Drive", download_limit=1000, upload_limit=500, price=99.99)
            session.add_all([p1, p2, p3])
            session.commit()
        
        # Initial Core Routers
        if not session.exec(select(Router)).first():
            print("[OMNI] Seeding core network nodes...")
            # LEGACY SEEDS REMOVED TO PREVENT ADMIN CREDENTIAL CONFLICTS
            pass

        # Test Client (Commander XAE-12)
        from datetime import datetime, timedelta
        from backend.models import Invoice, DailyConsumption
        
        existing_client = session.exec(select(Client).where(Client.dni == "XAE-12")).first()
        if not existing_client:
            print("[OMNI] Seeding royal client: Commander XAE-12...")
            plan = session.exec(select(Plan).where(Plan.name == "Hyper-Drive")).first()
            router = session.exec(select(Router).where(Router.role == "EDGE")).first()
            
            client = Client(
                full_name="Commander XAE-12",
                dni="XAE-12",
                email="commander@omni.space",
                phone="+1 (555) OMNI-01",
                ip_address="10.0.0.12",
                plan_id=plan.id,
                router_id=router.id,
                status="ACTIVE"
            )
            session.add(client)
            session.commit()
            session.refresh(client)

            # Seed Invoices
            print("[OMNI] Seeding royal invoices...")
            session.add(Invoice(client_id=client.id, amount=99.99, status="PAID", period="MAR-2026", due_date=datetime.now() - timedelta(days=30), paid_at=datetime.now() - timedelta(days=32)))
            session.add(Invoice(client_id=client.id, amount=99.99, status="PENDING", period="APR-2026", due_date=datetime.now() + timedelta(days=15)))

            # Seed Consumption (Last 7 days)
            print("[OMNI] Seeding neural consumption logs...")
            import random
            for i in range(7):
                session.add(DailyConsumption(
                    client_id=client.id, 
                    download_mb=random.uniform(5000, 25000), 
                    upload_mb=random.uniform(500, 2000),
                    date=datetime.now() - timedelta(days=i)
                ))
            
            session.commit()
    print("[OMNI] Initialization complete. All systems nominal.")

if __name__ == "__main__":
    init_db()
