import asyncio
import time
from sqlmodel import Session, select
from backend.models import Router, DDoS_Event
from backend.mikrotik_driver import MikroTikDriver
from backend.database import engine, DATABASE_URL

PPS_THRESHOLD = 500000  # Increased to 500k to avoid false positives from DNS spikes (User Request)
POLL_INTERVAL = 2      # seconds between checks

async def monitor_network_load():
    print(f"[OMNI-SHIELD] Starting Neural Network Monitoring (PPS_Threshold: {PPS_THRESHOLD})...")
    
    while True:
        try:
            with Session(engine) as session:
                routers = session.exec(select(Router).where(Router.role == "EDGE")).all()
                
                for router in routers:
                    # In a real scenario, we call /interface/monitor-traffic via API
                    # Using simulation logic for demonstration
                    # api = await MikroTikDriver.get_api(router)
                    # stats = api.path('/interface').monitor_traffic(interface='ether1', once=True)
                    # current_pps = int(stats[0]['rx-packets-per-second'])
                    
                    # Simulation: random PPS around baseline
                    import random
                    current_pps = random.randint(1000, 60000)
                    
                    if current_pps > PPS_THRESHOLD:
                        print(f"[WARNING] ABNORMAL TRAFFIC DETECTED on {router.name}: {current_pps} PPS")
                        print(f"[OMNI-SHIELD] Analyzing traffic origin... (Potential DNS burst detected)")
                        
                        # Trigger Shield
                        await MikroTikDriver.activate_neural_shield(router)
                        
                        # Log Event
                        event = DDoS_Event(
                            router_id=router.id,
                            pps_count=current_pps,
                            attack_type="Volumetric UDP Flood (Simulated)",
                            mitigation_action="RAW_FW_DROP_UDP"
                        )
                        session.add(event)
                        session.commit()
                    else:
                        # Auto-disengage if traffic is low
                        # await MikroTikDriver.deactivate_neural_shield(router)
                        pass
                        
            await asyncio.sleep(POLL_INTERVAL)
            
        except Exception as e:
            print(f"[ERROR] Monitor loop failed: {e}")
            await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(monitor_network_load())
