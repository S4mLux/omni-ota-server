import asyncio
from backend.database import engine
from sqlmodel import Session, select
from backend.models import PaymentReceipt
from backend.billing_api import approve_receipt, ReviewReceiptSchema

async def main():
    with Session(engine) as session:
        receipt = session.exec(select(PaymentReceipt).where(PaymentReceipt.reference_number == "SIMULACION")).first()
        if not receipt:
            print("No se encontro el recibo de simulacion.")
            return
        
        print(f"Aprobando recibo #{receipt.id} para cliente ID: {receipt.client_id}...")
        await approve_receipt(
            receipt.id, 
            ReviewReceiptSchema(reviewer="ROOT_SYSTEM", notes="Prueba de restauracion"), 
            session=session
        )
        print("PAGO APROBADO Y RESTAURACION DISPARADA")

if __name__ == "__main__":
    asyncio.run(main())
