import asyncio
from backend.database import engine
from sqlmodel import Session, select
from backend.models import Client, Router
from backend.mikrotik_driver import MikroTikDriver

async def test_suspension():
    with Session(engine) as session:
        client = session.exec(select(Client).where(Client.full_name == "ADM")).first()
        router = session.get(Router, client.router_id)
        
        print(f"Probando suspensión para {client.full_name} ({client.ip_address}) en {router.name}")
        
        # Resetear status para que el engine lo intente
        client.status = "ACTIVE"
        session.add(client)
        session.commit()
        
        # Intentar suspensión manual
        res = await MikroTikDriver.suspend_dhcp_client(router, client.ip_address)
        print(f"Resultado final: {res}")

if __name__ == "__main__":
    asyncio.run(test_suspension())
