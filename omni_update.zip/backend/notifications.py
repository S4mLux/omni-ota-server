import json
from datetime import datetime
from typing import List, Dict, Any
from sqlmodel import Session, select
from backend.models import SystemConfig, Staff, NotificationLog
from backend.websocket import manager

class NotificationDispatcher:
    """
    Handles event-based notifications filtered by the notification_matrix.
    """
    
    @staticmethod
    def get_matrix(session: Session) -> Dict[str, Dict[str, bool]]:
        cfg = session.exec(select(SystemConfig).where(SystemConfig.key == "notification_matrix")).first()
        if cfg:
            try:
                return json.loads(cfg.value)
            except:
                return {}
        return {}

    @staticmethod
    async def dispatch(event_type: str, message: str, session: Session, client_id: int = None, metadata: dict = None):
        """
        Dispatches a notification to all relevant roles according to the matrix.
        """
        matrix = NotificationDispatcher.get_matrix(session)
        
        # Matrix structure: { role: { event_type: bool } }
        # Example: { "ADMIN": { "payment_received": true }, "TECH": { "onu_registered": true } }
        
        roles_to_notify = []
        for role, events in matrix.items():
            if events.get(event_type):
                roles_to_notify.append(role.upper())
        
        if not roles_to_notify:
            return

        # Find all staff members. We filter in Python for more flexible matching.
        all_staff = session.exec(select(Staff)).all()
        
        target_staff = []
        for staff in all_staff:
            staff_pos = staff.position.upper()
            # Check if any target role matches the staff position
            # e.g. "ADMIN" matches "ADMINISTRADOR"
            if any(target_role in staff_pos for target_role in roles_to_notify):
                target_staff.append(staff)
        
        for staff in target_staff:
            # For now, we simulate sending or log it.
            # In a real scenario, this would trigger WhatsApp, Email, or Web Push.
            print(f"[NOTIFICATION] Sent to {staff.full_name} ({staff.position}): {message}")
            
            # Log the notification if it's for a specific client
            if client_id:
                log = NotificationLog(
                    client_id=client_id,
                    type=event_type,
                    channel="SYSTEM",
                    status="SENT",
                    phone_number=staff.phone or "INTERNAL",
                    message_body=f"[{event_type.upper()}] {message}",
                    created_at=datetime.utcnow(),
                    sent_at=datetime.utcnow()
                )

                session.add(log)
        
        # BROADCAST to connected staff via WebSockets
        await manager.broadcast({
            "type": "NOTIFICATION",
            "event": event_type,
            "message": message,
            "client_id": client_id,
            "metadata": metadata or {},
            "timestamp": datetime.utcnow().isoformat()
        })

        session.commit()

# Trigger points for events (Matching frontend keys in EVENT_TYPES)
EVENTS = {
    "PAYMENT_RECEIVED": "PAGO_REPORTADO",
    "SIGNAL_ALTERED": "SIGNAL_ALERT",
    "NEW_CLIENT": "CLIENTE_NUEVO",
    "PLAN_CHANGED": "CAMBIO_PLAN",
    "CLIENT_SUSPENDED": "CLIENT_SUSPENDED",
    "ONU_REGISTERED": "ONU_REGISTRADA",
    "ONU_DISCONNECTED": "ONU_DESCONECTADA",
    "PPPOE_CONNECTED": "PPPOE_CONNECTED",
    "PPPOE_DISCONNECTED": "PPPOE_DISCONNECTED"
}
