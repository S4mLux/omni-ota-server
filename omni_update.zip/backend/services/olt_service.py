import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlmodel import Session, select
from backend.models import ONU, OLT
from backend.olt_driver import OLTDriver

async def sync_olt_onus_logic(olt_id: int, sync: bool, session: Session):
    """
    Lógica compartida para sincronizar ONUs de una OLT.
    Se usa tanto en la API como en el proceso de fondo.

    IMPORTANTE: La escritura a DB ocurre INMEDIATAMENTE con datos del discovery SNMP,
    sin esperar por detalles individuales (señal, modelo, firmware).
    Los detalles los actualiza el loop de telemetría en main.py de forma continua.
    """
    olt = session.get(OLT, olt_id)
    if not olt:
        return None

    # 1. Discovery: obtener todas las ONUs del hardware via SNMP WALK
    discovered_onus = await OLTDriver.discover_onus(olt)
    unauth_onus = [o for o in discovered_onus if o.get("status") == "unauthenticated"]

    synced_count = 0
    if sync:
        authorized_in_hw = [o for o in discovered_onus if o.get("status") == "authorized"]
        hw_serials = {on["serial_number"].strip().upper() for on in authorized_in_hw}

        # 2. SYNC TO DATABASE — escritura inmediata sin esperar SNMP de detalles
        #    Los detalles (señal, modelo, firmware) los actualiza el telemetry loop.
        def _sync_to_db():
            db_onus = {
                on.serial_number.upper(): on
                for on in session.exec(select(ONU).where(ONU.olt_id == olt.id)).all()
            }

            s_count = 0
            seen_sns = set()
            for hw_onu in authorized_in_hw:
                sn = hw_onu["serial_number"].strip().upper()
                
                if sn in seen_sns:
                    print(f"[SYNC WARNING] Serial Number duplicado ignorado: {sn}")
                    continue
                seen_sns.add(sn)
                
                oper = hw_onu.get("oper_status", "ONLINE")
                status = "ONLINE" if oper == "ONLINE" else "OFFLINE"
                exists = db_onus.get(sn)

                if not exists:
                    # ONU nueva — registrar con datos básicos del discovery
                    new_onu = ONU(
                        olt_id=olt.id,
                        pon_port=hw_onu["pon_port"],
                        onu_index=hw_onu["onu_index"],
                        serial_number=sn,
                        vlan=100,
                        status=status,
                    )
                    session.add(new_onu)
                    print(f"[SYNC] Nueva ONU registrada: {sn} en puerto {hw_onu['pon_port']}:{hw_onu['onu_index']}")
                else:
                    # ONU existente — actualizar posición y estado operativo
                    exists.olt_id = olt.id
                    exists.pon_port = hw_onu["pon_port"]
                    exists.onu_index = hw_onu["onu_index"]
                    exists.status = status
                    session.add(exists)

                s_count += 1

            # Marcar OFFLINE las que ya no están en hardware
            for sn_db, db_on in db_onus.items():
                if sn_db not in hw_serials:
                    db_on.status = "OFFLINE"
                    session.add(db_on)

            session.commit()
            return s_count

        synced_count = await asyncio.to_thread(_sync_to_db)
        print(f"[SYNC] OLT {olt.name}: {synced_count} ONUs sincronizadas a DB ({len(authorized_in_hw)} en hardware)")

    return {
        "olt_name": olt.name,
        "unauth": unauth_onus,
        "discovered": discovered_onus,
        "synced": synced_count
    }
