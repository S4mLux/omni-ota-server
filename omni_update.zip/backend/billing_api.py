"""
Billing API — Facturación completa con tasa BCV, comprobantes, activación/corte automático
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Response
from fastapi.responses import HTMLResponse
from sqlmodel import Session, select, func
from typing import List, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel
import os, shutil, json, urllib.parse

from backend.models import (
    Invoice, PaymentReceipt, Client, Router, BcvRate,
    MikrotikPendingChange, generate_invoice_serial, ONU, OLT,
    NotificationLog, Plan
)
from backend.database import get_session
from backend.bcv_driver import BCVDriver
from backend.mikrotik_driver import MikroTikDriver
from backend.olt_driver import OLTDriver
from backend.notifications import NotificationDispatcher, EVENTS
import backend.suspension_engine as suspension_engine


router = APIRouter(prefix="/api/v2/billing", tags=["billing"])

UPLOAD_DIR = "uploads/receipts"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.get("/suspension-engine/status")
async def get_suspension_engine_status():
    """
    DEBUG: Muestra las tareas de suspensión activas en el motor event-driven.
    Útil para verificar que los cortes estén programados correctamente.
    """
    tasks = suspension_engine.get_active_tasks_info()
    return {
        "active_tasks": len(tasks),
        "tasks": tasks,
        "message": f"{len(tasks)} suspensión(es) programada(s) en el motor."
    }


@router.get("/dashboard-stats")
async def get_dashboard_stats(session: Session = Depends(get_session)):
    pending_invoices = session.exec(select(Invoice).where(Invoice.status == "PENDING", Invoice.deleted_at == None)).all()
    pending_receipts = session.exec(select(PaymentReceipt).where(PaymentReceipt.status == "PENDIENTE")).all()
    return {
        "pending_invoices_count": len(pending_invoices),
        "pending_receipts_count": len(pending_receipts)
    }


@router.get("/stats/revenue-history")
async def get_revenue_history(days: int = 30, session: Session = Depends(get_session)):
    """Retorna el historial de ingresos agrupado por día (últimos N días) para las gráficas BI."""
    from_date = datetime.utcnow() - timedelta(days=days)
    invoices = session.exec(
        select(Invoice).where(
            Invoice.status == "PAID",
            Invoice.paid_at >= from_date,
            Invoice.deleted_at == None
        ).order_by(Invoice.paid_at)
    ).all()

    # Agrupar por día
    daily: dict = {}
    for inv in invoices:
        if not inv.paid_at:
            continue
        day_key = inv.paid_at.strftime("%Y-%m-%d")
        if day_key not in daily:
            daily[day_key] = {"date": day_key, "usd": 0.0, "bs": 0.0, "count": 0}
        daily[day_key]["usd"]   = round(daily[day_key]["usd"]   + (inv.usd_amount or 0), 2)
        daily[day_key]["bs"]    = round(daily[day_key]["bs"]    + (inv.bs_amount  or 0), 2)
        daily[day_key]["count"] += 1

    # Rellenar días sin ingresos para que la gráfica sea continua
    result = []
    for i in range(days):
        d = (datetime.utcnow() - timedelta(days=days - 1 - i)).strftime("%Y-%m-%d")
        result.append(daily.get(d, {"date": d, "usd": 0.0, "bs": 0.0, "count": 0}))

    total_usd = round(sum(r["usd"] for r in result), 2)
    return {"history": result, "total_usd": total_usd, "days": days}


@router.get("/stats/onu-health")
async def get_onu_health(session: Session = Depends(get_session)):
    """Retorna la distribución de estados de ONUs para el Pie Chart de salud de red."""
    onus = session.exec(select(ONU)).all()
    online  = sum(1 for o in onus if o.status == "ONLINE")
    offline = sum(1 for o in onus if o.status == "OFFLINE")
    warning = sum(1 for o in onus if o.status == "WARNING")
    unknown = len(onus) - online - offline - warning
    return {
        "total": len(onus),
        "breakdown": [
            {"name": "Online",  "value": online,  "color": "#10b981"},
            {"name": "Offline", "value": offline, "color": "#ef4444"},
            {"name": "Warning", "value": warning, "color": "#f59e0b"},
            {"name": "Unknown", "value": unknown, "color": "#6b7280"},
        ]
    }


# ─────────────────────────────────────────────
# TASA BCV
# ─────────────────────────────────────────────

@router.get("/bcv-rate")
async def get_bcv_rate(session: Session = Depends(get_session)):
    """Retorna la tasa BCV del día (desde DB o scraping fresco)"""
    # Purgar registros con tasa 0.0 guardados por error
    bad_rates = session.exec(select(BcvRate).where(BcvRate.usd_rate <= 1.0)).all()
    for bad in bad_rates:
        session.delete(bad)
    if bad_rates:
        session.commit()

    rate = await BCVDriver.get_or_fetch_rate(session)
    last = session.exec(select(BcvRate).order_by(BcvRate.date.desc())).first()
    return {
        "rate": rate,
        "date": last.date.isoformat() if last else datetime.utcnow().isoformat(),
        "source": last.source if last else "EMERGENCY_FALLBACK",
        "formatted": f"Bs. {rate:,.2f}"
    }

@router.post("/bcv-rate/refresh")
async def refresh_bcv_rate(session: Session = Depends(get_session)):
    """Fuerza una actualización de la tasa BCV — intenta scraping real, usa emergencia si falla"""
    rate = await BCVDriver.fetch_rate()

    if not rate or rate <= 1.0:
        # Si el scraping falla, usar tasa de emergencia actualizada
        from backend.bcv_driver import BCVDriver as BCV
        rate = BCV.EMERGENCY_RATE

    # Actualizar o crear registro del día
    today = datetime.utcnow().date()
    existing = session.exec(
        select(BcvRate).where(BcvRate.date >= datetime(today.year, today.month, today.day))
    ).first()
    if existing:
        existing.usd_rate = rate
        existing.source = "BCV_MANUAL"
        session.add(existing)
    else:
        session.add(BcvRate(usd_rate=rate, source="BCV_MANUAL"))
    session.commit()
    return {"rate": rate, "formatted": f"Bs. {rate:,.2f}", "message": "Tasa actualizada correctamente"}



# ─────────────────────────────────────────────
# FACTURAS
# ─────────────────────────────────────────────

@router.get("/invoices")
async def list_invoices(
    status: Optional[str] = None,
    client_id: Optional[int] = None,
    period: Optional[str] = None,
    session: Session = Depends(get_session)
):
    query = select(Invoice).where(Invoice.deleted_at == None)
    if status:
        query = query.where(Invoice.status == status)
    if client_id:
        query = query.where(Invoice.client_id == client_id)
    if period:
        query = query.where(Invoice.period == period)
    invoices = session.exec(query.order_by(Invoice.created_at.desc())).all()
    
    # Enriquecer con datos del cliente
    result = []
    for inv in invoices:
        client = session.get(Client, inv.client_id)
        result.append({
            **inv.dict(),
            "client_name": client.full_name if client else "N/A",
            "client_dni": client.dni if client else "",
        })
    return result


@router.get("/client-bill-info/{client_id}")
async def get_client_bill_info(client_id: int, session: Session = Depends(get_session)):
    """
    Retorna el monto del plan y la descripción sugerida para pre-llenar la factura manual.
    """
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    
    plan = session.get(Plan, client.plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found for this client")
        
    return {
        "client_name": client.full_name,
        "amount_usd": plan.price,
        "plan_name": plan.name,
        "description": f"Servicio Mensual Internet - Plan {plan.name} ({datetime.utcnow().strftime('%B %Y')})"
    }

@router.post("/invoices/generate/{client_id}")
async def generate_invoice(client_id: int, session: Session = Depends(get_session)):
    """Genera la factura del mes actual para un cliente"""
    client = session.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    
    from backend.models import Plan
    plan = session.get(Plan, client.plan_id)
    if not plan:
        raise HTTPException(status_code=400, detail="El cliente no tiene plan asignado")

    # Tasa BCV del día
    tasa = await BCVDriver.get_or_fetch_rate(session)
    now = datetime.utcnow()
    period = f"{now.strftime('%b').upper()}-{now.year}"

    # Verificar si ya existe una factura para este período
    existing = session.exec(
        select(Invoice).where(Invoice.client_id == client_id, Invoice.period == period, Invoice.deleted_at == None)
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Ya existe una factura para {period}")

    # Generar serial único
    last_inv = session.exec(select(Invoice).order_by(Invoice.id.desc())).first()
    seq = (last_inv.id + 1) if last_inv else 1
    serial = generate_invoice_serial(now.year, seq)

    usd_amount = plan.price
    bs_amount = round(usd_amount * tasa, 2)

    invoice = Invoice(
        serial_number=serial,
        client_id=client_id,
        amount=usd_amount,
        usd_amount=usd_amount,
        tasa_bcv=tasa,
        bs_amount=bs_amount,
        period=period,
        due_date=datetime(now.year, now.month, 28),
        status="PENDING"
    )
    session.add(invoice)
    session.commit()
    session.refresh(invoice)
    return invoice

class ManualInvoiceSchema(BaseModel):
    client_id: int
    amount_usd: float
    concept: str
    custom_period: Optional[str] = None
    due_date: Optional[datetime] = None
    cut_off_date: Optional[datetime] = None
    due_date_offset_days: Optional[int] = 7

@router.post("/invoices/manual")
async def create_manual_invoice(body: ManualInvoiceSchema, session: Session = Depends(get_session)):
    """Genera una factura manual a demanda para cargos extra o reconexiones"""
    client = session.get(Client, body.client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
        
    tasa = await BCVDriver.get_or_fetch_rate(session)
    now = datetime.utcnow()
    period = body.custom_period or f"EXTRA-{now.strftime('%b').upper()}-{now.year}"
    
    # Generar serial único
    last_inv = session.exec(select(Invoice).order_by(Invoice.id.desc())).first()
    seq = (last_inv.id + 1) if last_inv else 1
    serial = generate_invoice_serial(now.year, seq)

    bs_amount = round(body.amount_usd * tasa, 2)

    # Lógica de fechas
    if body.due_date:
        due_date = body.due_date
    else:
        due_date = now + timedelta(days=body.due_date_offset_days or 7)

    if body.cut_off_date:
        # Validación profesional: Corte debe ser después del vencimiento
        if body.cut_off_date <= due_date:
            raise HTTPException(status_code=400, detail="La fecha de corte debe ser posterior a la fecha de vencimiento")
        cut_off_date = body.cut_off_date
    else:
        # Por defecto corte es 1 día después del vencimiento si no se especifica
        cut_off_date = due_date + timedelta(days=1)

    invoice = Invoice(
        serial_number=serial,
        client_id=body.client_id,
        amount=body.amount_usd,
        usd_amount=body.amount_usd,
        tasa_bcv=tasa,
        bs_amount=bs_amount,
        period=period,
        due_date=due_date,
        cut_off_date=cut_off_date,
        status="PENDING",
        notes=body.concept
    )
    session.add(invoice)
    session.commit()
    session.refresh(invoice)

    # ⚡ Programar el corte automático en el motor event-driven
    import asyncio
    asyncio.create_task(
        suspension_engine.schedule_suspension(invoice.id, cut_off_date)
    )

    return invoice



@router.post("/invoices/generate-batch")
async def generate_batch_invoices(session: Session = Depends(get_session)):
    """Genera facturas del mes para TODOS los clientes ACTIVOS o MIGRADOS"""
    clients = session.exec(
        select(Client).where(Client.status.in_(["ACTIVE", "MIGRATED"]))
    ).all()
    tasa = await BCVDriver.get_or_fetch_rate(session)
    now = datetime.utcnow()
    period = f"{now.strftime('%b').upper()}-{now.year}"
    
    created, skipped = 0, 0
    last_inv = session.exec(select(Invoice).order_by(Invoice.id.desc())).first()
    seq = (last_inv.id + 1) if last_inv else 1

    for client in clients:
        from backend.models import Plan
        plan = session.get(Plan, client.plan_id)
        if not plan:
            skipped += 1
            continue
        existing = session.exec(
            select(Invoice).where(Invoice.client_id == client.id, Invoice.period == period, Invoice.deleted_at == None)
        ).first()
        if existing:
            skipped += 1
            continue
        
        serial = generate_invoice_serial(now.year, seq)
        seq += 1
        invoice = Invoice(
            serial_number=serial,
            client_id=client.id,
            amount=plan.price,
            usd_amount=plan.price,
            tasa_bcv=tasa,
            bs_amount=round(plan.price * tasa, 2),
            period=period,
            due_date=datetime(now.year, now.month, 28),
            status="PENDING"
        )
        session.add(invoice)
        created += 1

    session.commit()
    return {"created": created, "skipped": skipped, "period": period, "tasa_bcv": tasa}

class DeleteInvoiceSchema(BaseModel):
    justification: str
    deleted_by: str

@router.post("/invoices/{invoice_id}/delete")
async def delete_invoice(
    invoice_id: int,
    body: DeleteInvoiceSchema,
    session: Session = Depends(get_session)
):
    """Borra una factura con justificativo obligatorio (soft delete)"""
    inv = session.get(Invoice, invoice_id)
    if not inv:
        raise HTTPException(status_code=404, detail="Factura no encontrada")
    if inv.status == "PAID":
        raise HTTPException(status_code=400, detail="No se puede borrar una factura ya pagada")
    
    inv.deleted_at = datetime.utcnow()
    inv.deleted_by = body.deleted_by
    inv.delete_justification = body.justification
    inv.status = "CANCELLED"
    session.add(inv)
    session.commit()

    # Cancelar tarea de suspensión si estaba programada
    import asyncio
    asyncio.create_task(suspension_engine.cancel_suspension(invoice_id))

    return {"status": "CANCELLED", "invoice_id": invoice_id}



# ─────────────────────────────────────────────
# COMPROBANTES DE PAGO
# ─────────────────────────────────────────────

@router.post("/receipts")
async def submit_receipt(
    invoice_id: int = Form(...),
    client_id: int = Form(...),
    bank: str = Form(...),
    reference_number: str = Form(...),
    amount_paid_bs: float = Form(...),
    notes: Optional[str] = Form(None),
    photo: Optional[UploadFile] = File(None),
    session: Session = Depends(get_session)
):
    """El cliente (o cobrador) sube comprobante de pago"""
    photo_path = None
    if photo:
        fname = f"receipt_{invoice_id}_{int(datetime.utcnow().timestamp())}{os.path.splitext(photo.filename)[1]}"
        fpath = os.path.join(UPLOAD_DIR, fname)
        with open(fpath, "wb") as f:
            shutil.copyfileobj(photo.file, f)
        photo_path = fpath

    # Calcular USD si hay tasa
    tasa = await BCVDriver.get_or_fetch_rate(session)
    usd_equiv = round(amount_paid_bs / tasa, 2) if tasa > 0 else None

    receipt = PaymentReceipt(
        invoice_id=invoice_id,
        client_id=client_id,
        bank=bank,
        reference_number=reference_number,
        amount_paid_bs=amount_paid_bs,
        amount_paid_usd=usd_equiv,
        photo_path=photo_path,
        notes=notes,
        status="PENDIENTE"
    )
    session.add(receipt)
    session.commit()
    session.refresh(receipt)
    return receipt

@router.get("/receipts")
async def list_receipts(
    status: Optional[str] = None,
    session: Session = Depends(get_session)
):
    query = select(PaymentReceipt)
    if status:
        query = query.where(PaymentReceipt.status == status)
    return session.exec(query.order_by(PaymentReceipt.submitted_at.desc())).all()

class ReviewReceiptSchema(BaseModel):
    reviewer: str
    notes: Optional[str] = None

@router.post("/receipts/{receipt_id}/approve")
async def approve_receipt(
    receipt_id: int,
    body: ReviewReceiptSchema,
    session: Session = Depends(get_session)
):
    """Aprovación → factura PAID + restauración del servicio (si estaba cortado)"""
    receipt = session.get(PaymentReceipt, receipt_id)
    if not receipt:
        raise HTTPException(status_code=404, detail="Comprobante no encontrado")
    if receipt.status != "PENDIENTE":
        raise HTTPException(status_code=400, detail=f"El comprobante ya fue procesado: {receipt.status}")

    receipt.status = "APROBADO"
    receipt.reviewed_by = body.reviewer
    receipt.review_notes = body.notes
    receipt.reviewed_at = datetime.utcnow()
    session.add(receipt)

    # Cancelar tarea de suspensión pendiente (si el cliente pagó antes del corte)
    import asyncio
    asyncio.create_task(suspension_engine.cancel_suspension(receipt.invoice_id))

    # Marcar factura como pagada
    invoice = session.get(Invoice, receipt.invoice_id)
    if invoice:
        invoice.status = "PAID"
        invoice.paid_at = datetime.utcnow()
        session.add(invoice)

    # Restaurar servicio si el cliente está MOROSO/SUSPENDED
    client = session.get(Client, receipt.client_id)
    if client and client.status in ("MOROSO", "SUSPENDED", "DEBTOR"):
        router_obj = session.get(Router, client.router_id)
        if router_obj:
            if client.connection_type == "PPPOE" and client.pppoe_user:
                await MikroTikDriver.restore_pppoe_client(router_obj, client.pppoe_user)
            elif client.connection_type == "DHCP":
                prev_list = client.prev_address_list
                
                # SAFETY FALLBACK: Si no hay lista previa o es basura (como '1'), usamos el perfil del plan actual
                if not prev_list or prev_list == "1" or prev_list == "True":
                    plan = session.get(Plan, client.plan_id)
                    prev_list = plan.mikrotik_profile if plan else "default"
                    print(f"[RECOVERY] Cliente {client.full_name} tenia lista invalida ({client.prev_address_list}). Usando fallback: {prev_list}")
                
                await MikroTikDriver.restore_dhcp_client(router_obj, client.ip_address, prev_list)

        
        # RESTAURAR OLT
        if client.onu_id:
            onu = session.get(ONU, client.onu_id)
            if onu:
                olt = session.get(OLT, onu.olt_id)
                if olt:
                    await OLTDriver.restore_onu(olt, onu.pon_port, onu.onu_index)
        
        client.status = "ACTIVE"
        client.prev_address_list = None
        session.add(client)
        
        # DISPATCH NOTIFICATION
        await NotificationDispatcher.dispatch(
            EVENTS["PAYMENT_RECEIVED"],
            f"Pago aprobado para {client.full_name}. Monto: Bs. {receipt.amount_paid_bs:,.2f}. Servicio restaurado.",
            session,
            client_id=client.id
        )
    
    session.commit()
    return {"status": "APROBADO", "service_restored": True}

@router.post("/receipts/{receipt_id}/reject")
async def reject_receipt(
    receipt_id: int,
    body: ReviewReceiptSchema,
    session: Session = Depends(get_session)
):
    """Rechazo de comprobante → servicio sigue cortado"""
    receipt = session.get(PaymentReceipt, receipt_id)
    if not receipt:
        raise HTTPException(status_code=404, detail="Comprobante no encontrado")

    receipt.status = "RECHAZADO"
    receipt.reviewed_by = body.reviewer
    receipt.review_notes = body.notes
    receipt.reviewed_at = datetime.utcnow()
    session.add(receipt)
    session.commit()
    return {"status": "RECHAZADO"}


# ─────────────────────────────────────────────
# CORTE MASIVO POR MORA
# ─────────────────────────────────────────────

@router.post("/suspend-overdue")
async def suspend_overdue_clients(
    days_overdue: int = 5,
    session: Session = Depends(get_session)
):
    """
    Busca facturas vencidas > N días y corta el servicio de los clientes.
    DHCP → address-list = MOROSOS
    PPPoE → deshabilitado
    """
    now = datetime.utcnow()
    grace_cutoff = now - timedelta(days=days_overdue)
    
    # Buscamos facturas que cumplan cualquiera de estas:
    # 1. Tienen cut_off_date explícito y ya pasó.
    # 2. No tienen cut_off_date y su due_date + periodo de gracia ya pasó.
    from sqlmodel import or_, and_
    overdue = session.exec(
        select(Invoice).where(
            Invoice.status == "PENDING",
            Invoice.deleted_at == None,
            or_(
                and_(Invoice.cut_off_date != None, Invoice.cut_off_date < now),
                and_(Invoice.cut_off_date == None, Invoice.due_date < grace_cutoff)
            )
        )
    ).all()

    suspended = []
    for invoice in overdue:
        client = session.get(Client, invoice.client_id)
        if not client or client.status == "MOROSO":
            continue
        
        router_obj = session.get(Router, client.router_id)
        success = False
        if router_obj:
            if client.connection_type == "PPPOE" and client.pppoe_user:
                success = await MikroTikDriver.suspend_pppoe_client(router_obj, client.pppoe_user)
            elif client.connection_type == "DHCP":
                # Guardar el address-list previo antes de cambiar
                client.prev_address_list = client.address_list or ""
                success = await MikroTikDriver.suspend_dhcp_client(router_obj, client.ip_address, client.prev_address_list)
        
        if not success:
            # Guardar como cambio pendiente si falla
            pending = MikrotikPendingChange(
                router_id=client.router_id,
                action="SUSPEND_DHCP" if client.connection_type == "DHCP" else "SUSPEND_PPPOE",
                payload=json.dumps({"ip": client.ip_address, "user": client.pppoe_user}),
                description=f"Corte por mora: {client.full_name}",
                created_by="SISTEMA_AUTOMATICO"
            )
            session.add(pending)

        # CORTAR OLT
        if client.onu_id:
            onu = session.get(ONU, client.onu_id)
            if onu:
                olt = session.get(OLT, onu.olt_id)
                if olt:
                    await OLTDriver.suspend_onu(olt, onu.pon_port, onu.onu_index)

        client.status = "MOROSO"
        session.add(client)
        suspended.append(client.full_name)

        # DISPATCH NOTIFICATION
        await NotificationDispatcher.dispatch(
            EVENTS["CLIENT_SUSPENDED"],
            f"Servicio suspendido por mora para {client.full_name}. Factura vencida.",
            session,
            client_id=client.id
        )

    session.commit()
    return {"suspended": len(suspended), "clients": suspended}

# ─────────────────────────────────────────────
# NOTIFICACIONES PRE-CORTE
# ─────────────────────────────────────────────

@router.get("/notifications/logs")
async def list_notification_logs(session: Session = Depends(get_session)):
    """Historial de mensajes enviados"""
    return session.exec(select(NotificationLog).order_by(NotificationLog.created_at.desc())).all()

@router.post("/notifications/overdue-reminders")
async def send_overdue_reminders(session: Session = Depends(get_session)):
    """
    Busca facturas vencidas en el rango de gracia y envía avisos digitales.
    Etapa 1: 3 días después del vencimiento (Soft)
    Etapa 2: 1 día antes del corte (Límite)
    """
    now = datetime.utcnow()
    
    # Parámetros desde SystemConfig
    grace_limit = 5 # Días para corte definitivo
    cfg = session.exec(select(SystemConfig).where(SystemConfig.key == "overdue_days_cutoff")).first()
    if cfg: grace_limit = int(cfg.value)

    # Buscar facturas PENDING
    pending_invoices = session.exec(
        select(Invoice).where(Invoice.status == "PENDING", Invoice.deleted_at == None)
    ).all()
    
    sent_count = 0
    for inv in pending_invoices:
        client = session.get(Client, inv.client_id)
        if not client or client.status == "SUSPENDED": continue
        
        days_diff = (now - inv.due_date).days
        
        # Etapa 1: Recordatorio suave (Día 2-3 de mora)
        if 2 <= days_diff <= 3:
            await _send_simulated_notice(session, client, inv, "PRE_CUT_WARNING")
            sent_count += 1
            
        # Etapa 2: Ultimátum (Día grace_limit - 1)
        elif days_diff == (grace_limit - 1):
            await _send_simulated_notice(session, client, inv, "FINAL_NOTICE")
            sent_count += 1
            
    session.commit()
    return {"status": "SUCCESS", "notifications_sent": sent_count}

async def _send_simulated_notice(session: Session, client: Client, invoice: Invoice, type: str):
    """Genera el mensaje y lo registra en el log (simulación)"""
    # Evitar duplicados para el mismo tipo/factura hoy
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    existing = session.exec(
        select(NotificationLog).where(
            NotificationLog.invoice_id == invoice.id,
            NotificationLog.type == type,
            NotificationLog.created_at >= today_start
        )
    ).first()
    if existing: return

    msg_map = {
        "PRE_CUT_WARNING": f"Hola {client.full_name}, te recordamos que tu pago por ${invoice.usd_amount} presenta un retraso. Evita la suspensión del servicio pagando antes de que venza tu periodo de gracia.",
        "FINAL_NOTICE": f"⚠️ AVISO FINAL: {client.full_name}, tu servicio será suspendido a la medianoche por falta de pago. Reporta tu comprobante ahora para evitar cargos de reconexión.",
        "RECONNECTION": f"¡Listo! {client.full_name}, hemos verificado tu pago. Tu servicio ha sido restaurado automáticamente. Gracias por preferir Omni-ISP."
    }
    
    log = NotificationLog(
        client_id=client.id,
        invoice_id=invoice.id,
        type=type,
        phone_number=client.phone or "N/A",
        message_body=msg_map.get(type, "Aviso de cobranza")
    )
    session.add(log)
    # Aquí se dispararía el API de WhatsApp (Twilio/Wpp-Gateway)
    # await WhatsAppBridge.send(log.phone_number, log.message_body)

@router.get("/invoices/{invoice_id}/html", response_class=HTMLResponse)
async def get_invoice_html(invoice_id: int, session: Session = Depends(get_session)):
    """Genera una factura HTML premium con QR dinámico y diseño enterprise."""
    inv = session.get(Invoice, invoice_id)
    if not inv:
        return HTMLResponse(content="<h1>404 - Factura no encontrada</h1>", status_code=404)

    client = session.get(Client, inv.client_id)
    if not client:
        return HTMLResponse(content="<h1>404 - Cliente no vinculado</h1>", status_code=404)

    configs = session.exec(select(SystemConfig)).all()
    cfg = {c.key: c.value for c in configs}

    comp_name = cfg.get("invoice_name", "OMNI-ISP C.A.")
    comp_rif  = cfg.get("invoice_rif",  "J-50123456-0")
    comp_addr = cfg.get("invoice_address", "Barquisimeto, Edo. Lara")
    comp_tel  = cfg.get("invoice_phone",   "0412-000-0000")
    comp_mail = cfg.get("invoice_email",   "facturacion@omni.net")
    comp_logo = cfg.get("invoice_logo",    "")
    comp_note = cfg.get("invoice_notes",   "Factura digital emitida por Omni-ISP Engine v2.0")

    is_paid    = inv.status == "PAID"
    status_color = "#10b981" if is_paid else "#ef4444"
    status_label = "PAGADO" if is_paid else inv.status

    # QR con datos de la factura
    qr_data = urllib.parse.quote(
        f"Factura:{inv.serial_number}|Cliente:{client.full_name}|Monto:${inv.usd_amount:.2f}|Estado:{inv.status}"
    )
    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=120x120&color=10b981&bgcolor=0a0a0a&data={qr_data}"

    logo_html = (
        f'<img src="{comp_logo}" style="max-height:52px;object-fit:contain;" alt="Logo">'
        if comp_logo else
        f'<span style="font-size:28px;font-weight:900;color:#10b981;letter-spacing:-1px;">{comp_name}</span>'
    )

    paid_badge = (
        f'<div style="position:absolute;top:32px;right:32px;background:#10b98122;border:2px solid #10b981;'
        f'color:#10b981;font-size:11px;font-weight:800;letter-spacing:3px;padding:6px 18px;'
        f'border-radius:4px;transform:rotate(3deg);font-family:monospace;">✓ PAGADO</div>'
        if is_paid else ""
    )

    html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Factura {inv.serial_number} — {comp_name}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Inter',sans-serif;background:#f0f4f8;color:#1a1a2e;padding:40px 20px}}
  .page{{max-width:820px;margin:auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.15)}}
  .header{{background:linear-gradient(135deg,#0a0a1a 0%,#0f2027 50%,#0a1628 100%);padding:40px;position:relative;overflow:hidden}}
  .header::before{{content:'';position:absolute;top:-40px;right:-40px;width:200px;height:200px;background:radial-gradient(circle,#10b98133,transparent);border-radius:50%}}
  .header-grid{{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;position:relative;z-index:1}}
  .comp-info{{color:#fff}}
  .comp-meta{{color:#6b7280;font-size:12px;line-height:1.8;margin-top:8px;font-family:'JetBrains Mono',monospace}}
  .invoice-meta{{text-align:right;color:#fff}}
  .inv-label{{font-size:10px;letter-spacing:4px;color:#10b981;font-family:'JetBrains Mono',monospace;text-transform:uppercase}}
  .inv-serial{{font-size:22px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#fff;margin:4px 0}}
  .inv-date{{font-size:11px;color:#9ca3af;font-family:'JetBrains Mono',monospace}}
  .status-badge{{display:inline-block;padding:5px 14px;border-radius:20px;font-size:10px;font-weight:800;
    letter-spacing:2px;margin-top:10px;font-family:'JetBrains Mono',monospace;
    background:{status_color}22;border:1px solid {status_color};color:{status_color}}}
  .body{{padding:36px 40px}}
  .parties{{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:32px}}
  .party-card{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:20px}}
  .party-label{{font-size:9px;letter-spacing:3px;color:#10b981;font-weight:700;margin-bottom:10px;font-family:'JetBrains Mono',monospace}}
  .party-name{{font-size:15px;font-weight:700;color:#1a1a2e;margin-bottom:4px}}
  .party-detail{{font-size:12px;color:#64748b;line-height:1.7}}
  table{{width:100%;border-collapse:collapse;margin-bottom:24px}}
  thead tr{{background:#f1f5f9}}
  th{{padding:12px 16px;font-size:10px;letter-spacing:2px;color:#64748b;font-weight:700;text-align:left;border-bottom:2px solid #e2e8f0}}
  td{{padding:14px 16px;font-size:13px;border-bottom:1px solid #f1f5f9;color:#374151}}
  .totals-qr{{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:end}}
  .totals{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:24px}}
  .total-row{{display:flex;justify-content:space-between;font-size:13px;color:#64748b;margin-bottom:10px}}
  .total-row strong{{color:#374151}}
  .bcv-row{{display:flex;justify-content:space-between;font-size:11px;color:#9ca3af;
    background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;margin:12px 0;font-family:'JetBrains Mono',monospace}}
  .grand-line{{border-top:2px solid #10b981;margin:16px 0 12px}}
  .grand-total{{display:flex;justify-content:space-between;align-items:center}}
  .grand-label{{font-size:13px;font-weight:700;color:#374151}}
  .grand-amount{{font-size:26px;font-weight:900;color:#10b981;font-family:'JetBrains Mono',monospace}}
  .qr-block{{background:#0a0a1a;border-radius:12px;padding:16px;text-align:center;min-width:152px}}
  .qr-block img{{border-radius:8px;display:block;margin:0 auto}}
  .qr-label{{font-size:8px;letter-spacing:2px;color:#10b981;margin-top:8px;font-family:'JetBrains Mono',monospace}}
  .footer{{background:#f8fafc;border-top:1px solid #e2e8f0;padding:24px 40px;display:flex;justify-content:space-between;align-items:center;gap:16px}}
  .footer-note{{font-size:11px;color:#9ca3af;line-height:1.6;max-width:480px}}
  .print-btn{{background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;padding:12px 28px;
    border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;font-family:'Inter',sans-serif}}
  .print-btn:hover{{opacity:.9}}
  @media print{{body{{background:#fff;padding:0}}.page{{box-shadow:none;border-radius:0}}.print-btn{{display:none}}}}
</style>
</head>
<body onload="if(window.location.search.includes('print'))window.print()">
<div class="page">
  <div class="header">
    {paid_badge}
    <div class="header-grid">
      <div class="comp-info">
        {logo_html}
        <div class="comp-meta">
          RIF: {comp_rif}<br>
          {comp_addr}<br>
          {comp_tel} &nbsp;·&nbsp; {comp_mail}
        </div>
      </div>
      <div class="invoice-meta">
        <div class="inv-label">Factura Digital</div>
        <div class="inv-serial">{inv.serial_number}</div>
        <div class="inv-date">Emisión: {inv.created_at.strftime('%d/%m/%Y')}</div>
        <div class="inv-date">Vence: {inv.due_date.strftime('%d/%m/%Y %H:%M') if inv.due_date else '—'}</div>
        <div class="status-badge">{status_label}</div>
      </div>
    </div>
  </div>

  <div class="body">
    <div class="parties">
      <div class="party-card">
        <div class="party-label">▸ Emisor</div>
        <div class="party-name">{comp_name}</div>
        <div class="party-detail">RIF: {comp_rif}<br>{comp_addr}<br>{comp_tel}</div>
      </div>
      <div class="party-card">
        <div class="party-label">▸ Cliente</div>
        <div class="party-name">{client.full_name}</div>
        <div class="party-detail">
          C.I./RIF: {client.dni}<br>
          {client.address or 'Sin dirección registrada'}<br>
          Período: <strong>{inv.period}</strong>
        </div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Descripción del Servicio</th>
          <th style="text-align:center">Cant.</th>
          <th style="text-align:right">Precio (USD)</th>
          <th style="text-align:right">Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <strong>Servicio de Internet Banda Ancha</strong><br>
            <span style="font-size:11px;color:#9ca3af">Plan Mensual — {inv.period}{' · ' + (inv.notes or '') if inv.notes else ''}</span>
          </td>
          <td style="text-align:center">1</td>
          <td style="text-align:right;font-family:'JetBrains Mono',monospace">${inv.usd_amount:,.2f}</td>
          <td style="text-align:right;font-family:'JetBrains Mono',monospace;font-weight:700">${inv.usd_amount:,.2f}</td>
        </tr>
      </tbody>
    </table>

    <div class="totals-qr">
      <div class="totals">
        <div class="total-row"><span>Subtotal USD</span><strong>${inv.usd_amount:,.2f}</strong></div>
        <div class="total-row"><span>Impuesto (0%)</span><strong>$0.00</strong></div>
        <div class="bcv-row">
          <span>Tasa BCV aplicada</span>
          <strong>Bs. {inv.tasa_bcv:,.4f} / $</strong>
        </div>
        <div class="grand-line"></div>
        <div class="grand-total">
          <span class="grand-label">Total a Pagar</span>
          <span class="grand-amount">Bs. {inv.bs_amount:,.2f}</span>
        </div>
      </div>
      <div class="qr-block">
        <img src="{qr_url}" width="120" height="120" alt="QR Factura">
        <div class="qr-label">VERIFICAR FACTURA</div>
      </div>
    </div>
  </div>

  <div class="footer">
    <div class="footer-note">
      {comp_note}<br>
      <span style="font-family:'JetBrains Mono',monospace;font-size:10px;opacity:.6">
        ID: {inv.id} &nbsp;·&nbsp; Ref: {abs(hash(inv.serial_number)) % 999999:06d}
      </span>
    </div>
    <button class="print-btn" onclick="window.print()">🖨 Imprimir / PDF</button>
  </div>
</div>
</body>
</html>"""
    return HTMLResponse(content=html_content)
