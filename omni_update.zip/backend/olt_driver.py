"""
OLT Driver — SNMP primario para lectura, SSH/Telnet para escritura.
Compatible con VSOL V1600D y OLTs GPON genéricas.
"""
from collections import defaultdict
import time
import re
import asyncio
import socket
from typing import List, Dict, Any, Optional
from backend.models import OLT, ONU

# Semáforo para sincronizar acceso por OLT
_locks: Dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)

# Cache de sysObjectID por OLT (clave=olt.id, valor=(resultado, timestamp))
# Evita hacer SNMP GET del sysObjID para cada ONU en el loop de telemetría
_SYS_OBJ_CACHE: Dict[int, tuple] = {}  # {olt_id: (value, ts)}
_SYS_OBJ_TTL = 300  # 5 minutos


# ─────────────────────────────────────────────
# SNMP ENGINE POOL — un engine reutilizable por OLT IP
# Elimina el leak de sockets que causa "too many file descriptors"
# ─────────────────────────────────────────────

_SNMP_ENGINES: Dict[str, Any] = {}          # ip -> SnmpEngine singleton
_SNMP_SEMAPHORE: Optional[asyncio.Semaphore] = None  # max concurrent SNMP ops

def _get_snmp_semaphore() -> asyncio.Semaphore:
    """Semáforo global lazy-init (máx 15 SNMP simultáneos en toda la app)."""
    global _SNMP_SEMAPHORE
    if _SNMP_SEMAPHORE is None:
        _SNMP_SEMAPHORE = asyncio.Semaphore(15)
    return _SNMP_SEMAPHORE

def _get_or_create_engine(ip: str) -> Any:
    """Devuelve un SnmpEngine singleton por IP. Crea uno nuevo si no existe."""
    from pysnmp.hlapi.v3arch.asyncio import SnmpEngine
    if ip not in _SNMP_ENGINES:
        _SNMP_ENGINES[ip] = SnmpEngine()
    return _SNMP_ENGINES[ip]

def _reset_engine(ip: str) -> None:
    """Fuerza la recreación del engine si quedó en mal estado."""
    from pysnmp.hlapi.v3arch.asyncio import SnmpEngine
    try:
        if ip in _SNMP_ENGINES:
            _SNMP_ENGINES[ip].close_dispatcher()
    except Exception:
        pass
    _SNMP_ENGINES[ip] = SnmpEngine()


async def _snmp_get(olt: "OLT", oid: str, timeout: int = 7, retries: int = 1) -> Optional[str]:
    """GET SNMP reutilizando engine singleton por OLT — pysnmp 7.x."""
    sem = _get_snmp_semaphore()
    async with sem:
        try:
            from pysnmp.hlapi.v3arch.asyncio import (
                UdpTransportTarget, ContextData,
                ObjectType, ObjectIdentity, get_cmd
            )
            auth = _build_snmp_auth(olt)
            if auth is None:
                return None

            engine = _get_or_create_engine(olt.ip_address)
            transport = await UdpTransportTarget.create(
                (olt.ip_address, 161), timeout=timeout, retries=retries
            )

            errorIndication, errorStatus, errorIndex, varBinds = await get_cmd(
                engine, auth, transport, ContextData(),
                ObjectType(ObjectIdentity(oid))
            )

            if errorIndication:
                # Timeout / network error → reset engine para próxima llamada
                if "timeout" in str(errorIndication).lower() or "no response" in str(errorIndication).lower():
                    _reset_engine(olt.ip_address)
                return f"ERROR: {errorIndication}"
            if errorStatus:
                return f"ERROR: {errorStatus}"

            val = str(varBinds[0][1])
            return val if val not in ("No Such Object", "No Such Instance", "") else None

        except Exception as e:
            # Ante cualquier excepción reset el engine por si quedó corrupto
            try:
                _reset_engine(olt.ip_address)
            except Exception:
                pass
            return f"EXCEPTION: {str(e)}"


async def _snmp_get_fast(olt: "OLT", oid: str) -> Optional[str]:
    """GET SNMP con timeout corto (3s, sin retries) para telemetría de detalle."""
    return await _snmp_get(olt, oid, timeout=3, retries=0)


async def _snmp_set(olt: "OLT", oid: str, value: int) -> bool:
    """SET SNMP reutilizando engine singleton — pysnmp 7.x."""
    sem = _get_snmp_semaphore()
    async with sem:
        try:
            from pysnmp.hlapi.v3arch.asyncio import (
                UdpTransportTarget, ContextData,
                ObjectType, ObjectIdentity, set_cmd, Integer32
            )
            auth = _build_snmp_auth(olt)
            if auth is None:
                return False

            engine = _get_or_create_engine(olt.ip_address)
            transport = await UdpTransportTarget.create(
                (olt.ip_address, 161), timeout=5, retries=1
            )

            errorIndication, errorStatus, errorIndex, varBinds = await set_cmd(
                engine, auth, transport, ContextData(),
                ObjectType(ObjectIdentity(oid), Integer32(value))
            )

            if errorIndication or errorStatus:
                _reset_engine(olt.ip_address)
                return False
            return True
        except Exception as e:
            print(f"[SNMP SET ERROR] {olt.ip_address} oid={oid}: {e}")
            try:
                _reset_engine(olt.ip_address)
            except Exception:
                pass
            return False


async def _snmp_walk(olt: "OLT", base_oid: str) -> List[Dict[str, str]]:
    """WALK SNMP reutilizando engine singleton — pysnmp 7.x."""
    results = []
    sem = _get_snmp_semaphore()
    async with sem:
        try:
            from pysnmp.hlapi.v3arch.asyncio import (
                UdpTransportTarget, ContextData,
                ObjectType, ObjectIdentity, next_cmd
            )
            auth = _build_snmp_auth(olt)
            if auth is None:
                return results

            engine = _get_or_create_engine(olt.ip_address)
            transport = await UdpTransportTarget.create(
                (olt.ip_address, 161), timeout=5, retries=1
            )
            current_oid = ObjectType(ObjectIdentity(base_oid))

            while True:
                errorIndication, errorStatus, _, varBinds = await next_cmd(
                    engine, auth, transport, ContextData(), current_oid
                )
                if errorIndication or errorStatus:
                    if errorIndication and ("timeout" in str(errorIndication).lower() or "no response" in str(errorIndication).lower()):
                        _reset_engine(olt.ip_address)
                    break
                for varBind in varBinds:
                    oid_str = str(varBind[0])
                    val_obj = varBind[1]
                    if not oid_str.startswith(base_oid):
                        return results
                    results.append({
                        "oid": oid_str,
                        "value": str(val_obj),
                        "raw_value": val_obj.asOctets() if hasattr(val_obj, "asOctets") else val_obj,
                    })
                    current_oid = ObjectType(ObjectIdentity(oid_str))
                else:
                    continue
                break

        except Exception as e:
            print(f"[SNMP WALK ERROR] {olt.ip_address} base={base_oid}: {e}")
            try:
                _reset_engine(olt.ip_address)
            except Exception:
                pass
    return results


def _build_snmp_auth(olt: "OLT"):
    """Construye el objeto de autenticación SNMP según versión (pysnmp 7.x)."""
    from pysnmp.hlapi.v3arch.asyncio import (
        CommunityData, UsmUserData,
        usmHMACMD5AuthProtocol, usmHMACSHAAuthProtocol,
        usmDESPrivProtocol, usmAesCfb128Protocol
    )
    version = (olt.snmp_version or "v2c").lower()
    if version in ("v1", "v2c"):
        model = 0 if version == "v1" else 1
        return CommunityData(olt.snmp_community or "public", mpModel=model)
    elif version == "v3":
        auth_map = {"MD5": usmHMACMD5AuthProtocol, "SHA": usmHMACSHAAuthProtocol}
        priv_map = {"DES": usmDESPrivProtocol, "AES": usmAesCfb128Protocol}
        return UsmUserData(
            userName=olt.snmp_username or "",
            authKey=olt.snmp_auth_password or "",
            privKey=olt.snmp_priv_password or "",
            authProtocol=auth_map.get(olt.snmp_auth_protocol or "MD5", usmHMACMD5AuthProtocol),
            privProtocol=priv_map.get(olt.snmp_priv_protocol or "DES", usmDESPrivProtocol),
        )
    return None


async def _get_olt_branch(olt: "OLT") -> bool:
    """Detecta si la OLT es rama C-Data/37950, con cache de 5 minutos por OLT."""
    now = time.time()
    cached = _SYS_OBJ_CACHE.get(olt.id)
    if cached and (now - cached[1]) < _SYS_OBJ_TTL:
        return cached[0]

    sys_obj = await _snmp_get(olt, "1.3.6.1.2.1.1.2.0", timeout=5, retries=1)
    is_cdata = bool(sys_obj and "37950" in sys_obj)
    _SYS_OBJ_CACHE[olt.id] = (is_cdata, now)
    return is_cdata


# ─────────────────────────────────────────────

# VSOL / GENERIC GPON OIDs (Branch 17409 - Standard VSOL)
OID_VSOL_ONU_TABLE      = "1.3.6.1.4.1.17409.2.3.1.1"
OID_VSOL_ONU_SN         = "1.3.6.1.4.1.17409.2.3.1.1.1.3"
OID_VSOL_ONU_STATUS   = "1.3.6.1.4.1.17409.2.3.1.1.1.10"
OID_VSOL_ONU_MODEL    = "1.3.6.1.4.1.17409.2.3.1.1.1.1"
OID_VSOL_ONU_FIRMWARE = "1.3.6.1.4.1.17409.2.3.1.1.1.5"
OID_VSOL_ONU_REBOOT   = "1.3.6.1.4.1.17409.2.3.1.1.1.15"
OID_VSOL_PON_TX_POWER   = "1.3.6.1.4.1.17409.2.3.1.1.1.8" 
OID_SYS_OBJ_ID          = "1.3.6.1.2.1.1.2.0"
OID_VSOL_ONU_DISTANCE   = "1.3.6.1.4.1.17409.2.3.1.1.1.10"

# C-DATA / VSOL (Branch 37950 - Newer firmware V1600GS)
OID_CDATA_ONU_SN        = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.5"
OID_CDATA_ONU_STATUS    = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.13"
# gOnuDetailInfoTable (VSOL V1600 / C-Data enterprise 37950) — columnas por PON.ONU
OID_CDATA_ONU_MODEL     = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.17"   # gOnuDetailInfoModel
OID_CDATA_ONU_MAIN_VER  = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.25"   # gOnuDetailInfoMainVer
OID_CDATA_ONU_DETAIL_VER = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.4"  # gOnuDetailInfoVersion
OID_CDATA_ONU_RX_POWER  = "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.7" # Real-time Rx Power (string)
OID_CDATA_ONU_TX_POWER  = "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.6" # Real-time Tx Power (string)
OID_CDATA_ONU_TEMP      = "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.8" # Real-time Temp (string)
OID_CDATA_ONU_VOLTAGE   = "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.9" # Real-time Voltage (string)
OID_CDATA_ONU_DISTANCE  = "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.10"
OID_CDATA_UNAUTH_SN     = "1.3.6.1.4.1.37950.1.1.6.1.1.2.1.5"
OID_CDATA_ONU_REBOOT    = "1.3.6.1.4.1.37950.1.1.5.12.1.25.1.4"
OID_CDATA_ONU_FACTORY   = "1.3.6.1.4.1.37950.1.1.5.12.1.25.1.3"

# Older VSOL Branch (17409)
OID_VSOL_ONU_REBOOT     = "1.3.6.1.4.1.17409.2.3.1.2.1.1.4"
OID_VSOL_ONU_FACTORY    = "1.3.6.1.4.1.17409.2.3.1.2.1.1.3"

# Generic OIDs
OID_SYS_OBJ_ID          = "1.3.6.1.2.1.1.2.0"
OID_SYS_DESCR           = "1.3.6.1.2.1.1.1.0"
OID_IF_TABLE            = "1.3.6.1.2.1.2.2.1.2"


class OLTDriver:

    # ─────────────────────────────────────────
    # SNMP — Primitivas
    # ─────────────────────────────────────────

    @staticmethod
    async def snmp_get(olt: OLT, oid: str) -> Optional[str]:
        return await _snmp_get(olt, oid)

    @staticmethod
    async def snmp_walk(olt: OLT, base_oid: str) -> List[Dict[str, str]]:
        return await _snmp_walk(olt, base_oid)

    # ─────────────────────────────────────────
    # STATUS — Ping / SNMP sysDescr
    # ─────────────────────────────────────────

    @staticmethod
    async def probe_status(olt: OLT) -> bool:
        """Sondea si la OLT responde: primero SNMP sysDescr, luego ping."""
        val = await OLTDriver.snmp_get(olt, OID_SYS_DESCR)
        if val:
            return True
        # Fallback ping
        def _ping():
            import subprocess
            try:
                r = subprocess.run(
                    ["ping", "-n", "1", "-w", "2000", olt.ip_address],
                    capture_output=True, text=True, timeout=5
                )
                return r.returncode == 0
            except Exception:
                return False
        return await asyncio.to_thread(_ping)

    # ─────────────────────────────────────────
    # DISCOVERY — SNMP WALK de ONUs
    # ─────────────────────────────────────────

    @staticmethod
    async def scan_unauthenticated_onus(olt: OLT) -> List[Dict[str, Any]]:
        """
        Descubre ONUs no autorizadas usando SNMP walk.
        Para equipos VSOL usa el árbol propietario.
        Retorna la misma estructura que antes (pon_port, onu_index, serial_number, status).
        """
        async with _locks[olt.id]:
            onus = await _discover_onus(olt)
            return [o for o in onus if o.get("status") == "unauthenticated"]

    @staticmethod
    async def get_all_authorized_onus(olt: OLT) -> List[Dict[str, Any]]:
        """
        Escanea todas las ONUs autorizadas en el hardware via SNMP.
        Compatible VSOL + fallback a SSH/Telnet si SNMP no responde.
        """
        async with _locks[olt.id]:
            onus = await _discover_onus(olt)
            return [o for o in onus if o.get("status") == "authorized"]

    @staticmethod
    async def discover_onus(olt: OLT) -> List[Dict[str, Any]]:
        """Devuelve todas las ONUs descubiertas en hardware, autorizadas y no autorizadas."""
        async with _locks[olt.id]:
            return await _discover_onus(olt)

    # ─────────────────────────────────────────
    # SEÑALES — SNMP
    # ─────────────────────────────────────────

    @staticmethod
    async def get_onu_signal(olt: OLT, pon_port: int, onu_index: int) -> Optional[float]:
        """Obtiene potencia Rx de la ONU via SNMP (Detección de rama)."""
        sys_obj = await _snmp_get(olt, OID_SYS_OBJ_ID)
        is_cdata = sys_obj and "37950" in sys_obj
        
        oid = f"{OID_CDATA_ONU_RX_POWER if is_cdata else OID_VSOL_ONU_RX_POWER}.{pon_port}.{onu_index}"
        raw = await OLTDriver.snmp_get(olt, oid)
        
        if raw:
            try:
                # En V1600GS (37950), el valor viene como string directo "-23.44"
                val = float(raw)
                if is_cdata:
                    # Si es valor absoluto muy alto, probablemente necesita escalamiento
                    # Pero en esta rama parece venir directo.
                    return round(val, 2)
                else:
                    return round(val / 100.0, 2) if abs(val) > 100 else val
            except Exception: pass
        return None

    @staticmethod
    async def get_onu_ifindex(olt: OLT, pon_port: int, onu_index: int) -> Optional[int]:
        """Busca el ifIndex de una ONU basado en su nombre (ej. GPON01ONU2)."""
        # Formato esperado en V1600GS: GPON0[PON]ONU[IDX] -> Ej: GPON01ONU2
        # OJO: Depende de la OLT. En VSOL suele ser as.
        target_name = f"GPON0{pon_port}ONU{onu_index}"
        rows = await OLTDriver.snmp_walk(olt, "1.3.6.1.2.1.2.2.1.2")
        for row in rows:
            if row["value"] == target_name:
                return int(row["oid"].split(".")[-1])
        return None

    @staticmethod
    async def get_onu_details(olt: OLT, pon_port: int, onu_index: int, cached_ifindex: int = None) -> Dict[str, Any]:
        """Diagnóstico completo de una ONU detectando rama de forma optimizada (paralelo)."""
        details: Dict[str, Any] = {
            "signal_dbm": None, "tx_power": None,
            "temp": None, "voltage": None,
            "distance": None, "status_msg": "Unknown",
            "rx_octets": None, "tx_octets": None,
            "model": None, "firmware": None, "snmp_ifindex": None
        }

        try:
            # Global 15s timeout so the endpoint never hangs the frontend
            details = await asyncio.wait_for(
                OLTDriver._get_onu_details_inner(olt, pon_port, onu_index, cached_ifindex),
                timeout=15.0
            )
        except asyncio.TimeoutError:
            print(f"[ONU DETAILS TIMEOUT] OLT {olt.ip_address} ONU {pon_port}:{onu_index} — SNMP timed out after 15s")
            details["status_msg"] = "Timeout"
        except Exception as e:
            print(f"[ONU DETAILS ERROR] {e}")

        return details

    @staticmethod
    async def _get_onu_details_inner(olt: OLT, pon_port: int, onu_index: int, cached_ifindex: int = None) -> Dict[str, Any]:
        """Internal: actual SNMP work for get_onu_details.
        Uses cached sysObjectID branch detection and fast SNMP GETs (3s, 0 retries)
        to keep each ONU poll well under the 15s global timeout.
        """
        details: Dict[str, Any] = {
            "signal_dbm": None, "tx_power": None,
            "temp": None, "voltage": None,
            "distance": None, "status_msg": "Unknown",
            "rx_octets": None, "tx_octets": None,
            "model": None, "firmware": None, "snmp_ifindex": None
        }

        # Cache de branch — evita 1 SNMP GET por ONU (ahorra 21+ requests por ciclo)
        is_cdata = await _get_olt_branch(olt)

        oids = {
            "rx":         "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.7" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.8",
            "tx":         "1.3.6.1.4.1.37950.1.1.6.1.1.3.1.6" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.9",
            "dist":       "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.10" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.10",
            "status":     "1.3.6.1.4.1.37950.1.1.6.1.1.4.1.13" if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.10",
            "model_name": OID_CDATA_ONU_MODEL if is_cdata else "1.3.6.1.4.1.17409.2.3.1.1.1.2",
            "fw":         OID_CDATA_ONU_MAIN_VER if is_cdata else OID_VSOL_ONU_FIRMWARE,
        }

        # 6 GETs en paralelo con timeout=3s, retries=0 → ~3-4s total (vs 14s+ antes)
        rx_raw, tx_raw, dist_raw, status_raw, model_raw, fw_raw = await asyncio.gather(
            _snmp_get_fast(olt, f"{oids['rx']}.{pon_port}.{onu_index}"),
            _snmp_get_fast(olt, f"{oids['tx']}.{pon_port}.{onu_index}"),
            _snmp_get_fast(olt, f"{oids['dist']}.{pon_port}.{onu_index}"),
            _snmp_get_fast(olt, f"{oids['status']}.{pon_port}.{onu_index}"),
            _snmp_get_fast(olt, f"{oids['model_name']}.{pon_port}.{onu_index}"),
            _snmp_get_fast(olt, f"{oids['fw']}.{pon_port}.{onu_index}"),
        )

        def ok(v): return v and "ERROR" not in v and "EXCEPTION" not in v

        try:
            if ok(rx_raw):
                details["signal_dbm"] = float(rx_raw) if is_cdata else float(rx_raw) / 100.0
            if ok(tx_raw):
                details["tx_power"] = float(tx_raw) if is_cdata else float(tx_raw) / 100.0
            if ok(dist_raw):
                details["distance"] = float(dist_raw)
        except Exception:
            pass

        def clean_snmp_str(s):
            if not s or "ERROR" in s or "EXCEPTION" in s:
                return None
            s = s.strip().replace('"', '')
            if all(c in "0123456789ABCDEFabcdef " for c in s) and len(s) > 4:
                try:
                    parts = s.split()
                    return "".join(chr(int(p, 16)) for p in parts if p).strip()
                except Exception:
                    pass
            return s

        details["model"] = clean_snmp_str(model_raw)
        details["firmware"] = clean_snmp_str(fw_raw)

        # Usar cached_ifindex directamente — no hacer SNMP WALK por ifIndex
        ifIndex = cached_ifindex
        details["snmp_ifindex"] = ifIndex if status_raw == "1" else None
        details["status_msg"] = "Online" if status_raw == "1" else "Offline"

        # Contadores de tráfico solo si ya tenemos un ifIndex cacheado
        if status_raw == "1" and ifIndex:
            rx_t, tx_t = await asyncio.gather(
                _snmp_get_fast(olt, f"1.3.6.1.2.1.2.2.1.10.{ifIndex}"),
                _snmp_get_fast(olt, f"1.3.6.1.2.1.2.2.1.16.{ifIndex}"),
            )
            try:
                details["rx_octets"] = int(rx_t) if ok(rx_t) else None
                details["tx_octets"] = int(tx_t) if ok(tx_t) else None
            except Exception:
                pass

        return details

    # ─────────────────────────────────────────
    # SSH CLIENT — Para operaciones de escritura
    # ─────────────────────────────────────────

    @staticmethod
    async def get_ssh_client(olt: OLT, retries: int = 1):
        """Crea cliente SSH (solo para operaciones de escritura)."""
        import paramiko

        def _connect():
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                client.connect(
                    hostname=olt.ip_address,
                    port=olt.ssh_port or 22,
                    username=olt.username,
                    password=olt.password,
                    timeout=8,
                    banner_timeout=10,
                    look_for_keys=False,
                    allow_agent=False
                )
                return client
            except Exception as e:
                print(f"[OLT SSH] {olt.name} failed: {e}")
                return None

        for attempt in range(retries + 1):
            client = await asyncio.to_thread(_connect)
            if client:
                return client
            if attempt < retries:
                await asyncio.sleep(1.5)
        return None

    @staticmethod
    def _telnet_send(ip: str, port: int, username: str, password: str,
                     commands: List[str], timeout: int = 10) -> str:
        """Telnet simple para operaciones de escritura como fallback."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((ip, port))
            out = sock.recv(1024).decode("utf-8", errors="ignore")
            sock.send((username + "\n").encode()); time.sleep(0.5)
            out += sock.recv(1024).decode("utf-8", errors="ignore")
            sock.send((password + "\n").encode()); time.sleep(0.5)
            out += sock.recv(1024).decode("utf-8", errors="ignore")
            for cmd in commands:
                sock.send((cmd + "\n").encode()); time.sleep(0.5)
                out += sock.recv(2048).decode("utf-8", errors="ignore")
            sock.close()
            return out
        except Exception as e:
            return f"Telnet error: {e}"

    # ─────────────────────────────────────────
    # OPERACIONES DE ESCRITURA (SSH → Telnet)
    # ─────────────────────────────────────────

    @staticmethod
    async def authorize_onu(olt: OLT, pon_port: int, onu_index: int,
                            sn: str, vlan: int = 100) -> bool:
        async with _locks[olt.id]:
            # Intentar SSH primero
            client = await OLTDriver.get_ssh_client(olt)
            if client:
                try:
                    def _do_ssh(cl, pp, oi, s, v):
                        import paramiko
                        shell = cl.invoke_shell()
                        def sw(cmd, w=0.6):
                            shell.send(cmd + "\n"); time.sleep(w)
                        sw("config")
                        sw(f"interface gpon-olt_1/1/{pp}")
                        sw(f"ont add {oi} sn-auth {s} ont-lineprofile-id 1 ont-srvprofile-id 1", 1.0)
                        sw(f"ont port native-vlan {oi} 1 eth 1 vlan {v}")
                        sw("exit")
                        sw(f"service-port 100 vlan {v} gpon 1/1/{pp} ont {oi} gemport 1 multi-service user-vlan {v}", 1.0)
                        sw("write", 1.5)
                    await asyncio.to_thread(_do_ssh, client, pon_port, onu_index, sn, vlan)
                    return True
                except Exception as e:
                    print(f"[OLT AUTHORIZE SSH] {olt.name}: {e}")
                finally:
                    await asyncio.to_thread(client.close)
            # Fallback Telnet
            cmds = [
                "config",
                f"interface gpon-olt_1/1/{pon_port}",
                f"ont add {onu_index} sn-auth {sn} ont-lineprofile-id 1 ont-srvprofile-id 1",
                f"ont port native-vlan {onu_index} 1 eth 1 vlan {vlan}",
                "exit",
                f"service-port 100 vlan {vlan} gpon 1/1/{pon_port} ont {onu_index} gemport 1 multi-service user-vlan {vlan}",
                "write"
            ]
            out = await asyncio.to_thread(
                OLTDriver._telnet_send, olt.ip_address, 23,
                olt.username, olt.password, cmds
            )
            return "error" not in out.lower()

    @staticmethod
    async def suspend_onu(olt: OLT, pon_port: int, onu_index: int) -> bool:
        async with _locks[olt.id]:
            client = await OLTDriver.get_ssh_client(olt)
            if client:
                try:
                    def _do(cl, pp, oi):
                        sh = cl.invoke_shell()
                        sh.send("config\n"); time.sleep(0.5)
                        sh.send(f"interface gpon-olt_1/1/{pp}\n"); time.sleep(0.5)
                        sh.send(f"ont deactivate {oi}\n"); time.sleep(1.0)
                        sh.send("write\n"); time.sleep(1.0)
                    await asyncio.to_thread(_do, client, pon_port, onu_index)
                    return True
                except Exception as e:
                    print(f"[OLT SUSPEND SSH] {olt.name}: {e}")
                finally:
                    await asyncio.to_thread(client.close)
            cmds = ["config", f"interface gpon-olt_1/1/{pon_port}",
                    f"ont deactivate {onu_index}", "write"]
            out = await asyncio.to_thread(
                OLTDriver._telnet_send, olt.ip_address, 23,
                olt.username, olt.password, cmds
            )
            return "error" not in out.lower()

    @staticmethod
    async def restore_onu(olt: OLT, pon_port: int, onu_index: int) -> bool:
        async with _locks[olt.id]:
            client = await OLTDriver.get_ssh_client(olt)
            if client:
                try:
                    def _do(cl, pp, oi):
                        sh = cl.invoke_shell()
                        sh.send("config\n"); time.sleep(0.5)
                        sh.send(f"interface gpon-olt_1/1/{pp}\n"); time.sleep(0.5)
                        sh.send(f"ont activate {oi}\n"); time.sleep(1.0)
                        sh.send("write\n"); time.sleep(1.0)
                    await asyncio.to_thread(_do, client, pon_port, onu_index)
                    return True
                except Exception as e:
                    print(f"[OLT RESTORE SSH] {olt.name}: {e}")
                finally:
                    await asyncio.to_thread(client.close)
            cmds = ["config", f"interface gpon-olt_1/1/{pon_port}",
                    f"ont activate {onu_index}", "write"]
            out = await asyncio.to_thread(
                OLTDriver._telnet_send, olt.ip_address, 23,
                olt.username, olt.password, cmds
            )
            return "error" not in out.lower()

    @staticmethod
    async def reboot_onu(olt: OLT, pon_port: int, onu_index: int) -> bool:
        """Reinicia la ONU via SNMP (Detección de rama)."""
        sys_obj = await _snmp_get(olt, OID_SYS_OBJ_ID)
        is_cdata = sys_obj and "37950" in sys_obj
        oid_base = OID_CDATA_ONU_REBOOT if is_cdata else OID_VSOL_ONU_REBOOT
        # Valor 1 = Reboot
        return await _snmp_set(olt, f"{oid_base}.{pon_port}.{onu_index}", 1)

    @staticmethod
    async def factory_reset_onu(olt: OLT, pon_port: int, onu_index: int) -> bool:
        """Restaura la ONU a valores de fábrica via SNMP (Detección de rama)."""
        sys_obj = await _snmp_get(olt, OID_SYS_OBJ_ID)
        is_cdata = sys_obj and "37950" in sys_obj
        oid_base = OID_CDATA_ONU_FACTORY if is_cdata else OID_VSOL_ONU_FACTORY
        # Valor 1 = Restore Factory
        return await _snmp_set(olt, f"{oid_base}.{pon_port}.{onu_index}", 1)

    # ─────────────────────────────────────────
    # PUERTOS PON — SNMP IF-MIB
    # ─────────────────────────────────────────

    @staticmethod
    async def get_port_states(olt: OLT) -> List[Dict[str, Any]]:
        """Lee estado de interfaces via SNMP IF-MIB."""
        OID_IF_DESCR   = "1.3.6.1.2.1.2.2.1.2"
        OID_IF_OPER    = "1.3.6.1.2.1.2.2.1.8"  # ifOperStatus 1=up

        descr_rows = await OLTDriver.snmp_walk(olt, OID_IF_DESCR)
        oper_rows  = await OLTDriver.snmp_walk(olt, OID_IF_OPER)

        oper_map = {}
        for row in oper_rows:
            idx = row["oid"].split(".")[-1]
            oper_map[idx] = row["value"]

        ports = []
        for row in descr_rows:
            idx   = row["oid"].split(".")[-1]
            name  = row["value"]
            
            # Filtrar interfaces virtuales (ONUs, VLANs, etc.)
            u_name = name.upper()
            if any(x in u_name for x in ("ONU", "ONT", "VLAN", "NULL", "VIRTUAL")):
                continue
                
            oper  = oper_map.get(idx, "2")
            ptype = "sfp" if any(x in u_name for x in ("PON", "SFP", "GPON")) else "rj45"
            ports.append({
                "label":  name,
                "type":   ptype,
                "status": "up" if oper == "1" else "down"
            })

        if not ports:
            # Fallback estático
            ports = [
                {"label": "GE1",  "type": "rj45", "status": "up"},
                {"label": "PON1", "type": "sfp",  "status": "up"},
                {"label": "PON2", "type": "sfp",  "status": "up"},
            ]
        return ports

    @staticmethod
    async def get_pon_optical_info(olt: OLT, pon_port: int) -> Dict[str, Any]:
        """Info óptica del SFP PON via SNMP, detectando la rama del hardware."""
        info: Dict[str, Any] = {}
        
        # Detectar rama para usar el OID correcto
        sys_obj = await _snmp_get(olt, OID_SYS_OBJ_ID)
        is_cdata = sys_obj and "37950" in sys_obj
        
        # Seleccionar OID base según la rama
        # Nota: 37950 suele usar OIDs de temperatura/voltaje también, por ahora solo Tx Power
        oid_base = OID_CDATA_ONU_TX_POWER if is_cdata else OID_VSOL_PON_TX_POWER
        
        # El índice para el SFP PON suele ser {oid_base}.{pon_port}.0 o similar
        # En la rama 37950, a veces es diferente, pero probaremos la convención detectada
        res = await OLTDriver.snmp_get(olt, f"{oid_base}.{pon_port}.0")
        
        if res and not res.startswith("ERROR"):
            try:
                v = float(res)
                # Normalización típica: si es muy alto, dividir por 100 (ej: 235 -> 2.35 dBm)
                info["tx_power"] = round(v / 100.0, 2) if abs(v) > 100 else v
            except Exception:
                pass
        return info


# ─────────────────────────────────────────────
# ONU DISCOVERY — funciones internas
# ─────────────────────────────────────────────

def _format_serial(val: Any) -> str:
    """Normaliza el número de serie desde SNMP (soporta Hex y String)"""
    if not val: return ""
    # Si es bytes (pysnmp lo entrega así a veces)
    if isinstance(val, bytes):
        # Si parece ser texto ASCII puro
        try:
            decoded = val.decode('ascii').strip().replace('\x00', '')
            if len(decoded) >= 8 and decoded.isalnum():
                return decoded.upper()
        except: pass
        # Si no, convertir a HEX (formato estándar de ONUs)
        return val.hex().upper()
    
    s_val = str(val).strip().replace('\x00', '')
    # Si viene como string de hex "0x4857..."
    if s_val.startswith('0x'):
        return s_val[2:].upper()
    
    return s_val.upper()

async def _discover_onus(olt: "OLT") -> List[Dict[str, Any]]:
    """
    Descubre ONUs via SNMP WALK detectando la rama del fabricante (VSOL/C-Data).
    """
    onus: Dict[tuple, Dict[str, Any]] = {}
    
    # Detectar rama vía sysObjectID
    sys_obj = await _snmp_get(olt, OID_SYS_OBJ_ID)
    is_cdata_branch = sys_obj and "37950" in sys_obj
    
    if is_cdata_branch:
        # Rama 37950 (C-Data / New VSOL)
        sn_rows = await _snmp_walk(olt, OID_CDATA_ONU_SN)
        for row in sn_rows:
            parts = row["oid"].split(".")
            if len(parts) >= 2:
                try:
                    pon, idx = int(parts[-2]), int(parts[-1])
                    sn = _format_serial(row.get("raw_value") or row["value"])
                    if sn:
                        onus[(pon, idx)] = {"pon_port": pon, "onu_index": idx, "serial_number": sn, "status": "authorized"}
                except ValueError: pass

        
        status_rows = await _snmp_walk(olt, OID_CDATA_ONU_STATUS)
        for row in status_rows:
            parts = row["oid"].split(".")
            if len(parts) >= 2:
                try:
                    pon, idx = int(parts[-2]), int(parts[-1])
                    if (pon, idx) in onus:
                        # 1 = Online, others = Offline. Since it is in OID_CDATA_ONU_SN, it is authorized.
                        onus[(pon, idx)]["status"] = "authorized"
                        onus[(pon, idx)]["oper_status"] = "ONLINE" if row["value"] == "1" else "OFFLINE"
                except ValueError: pass
                
        # También buscar en la tabla de autodescubrimiento para ONUs realmente no autorizadas
        unauth_rows = await _snmp_walk(olt, OID_CDATA_UNAUTH_SN)
        for row in unauth_rows:
            parts = row["oid"].split(".")
            if len(parts) >= 2:
                try:
                    pon, idx = int(parts[-2]), int(parts[-1])
                    sn = row["value"].strip().replace('\x00', '').upper()
                    if sn and (pon, idx) not in onus:
                        onus[(pon, idx)] = {"pon_port": pon, "onu_index": idx, "serial_number": sn, "status": "unauthenticated"}
                except ValueError: pass
    else:
        # Rama 17409 (VSOL Standard)
        sn_rows = await _snmp_walk(olt, OID_VSOL_ONU_SN)
        for row in sn_rows:
            parts = row["oid"].split(".")
            if len(parts) >= 2:
                try:
                    pon, idx = int(parts[-2]), int(parts[-1])
                    sn = _format_serial(row.get("raw_value") or row["value"])
                    if sn and sn not in ("NO SUCH OBJECT", "NO SUCH INSTANCE"):
                        onus[(pon, idx)] = {"pon_port": pon, "onu_index": idx, "serial_number": sn, "status": "authorized"}
                except ValueError: pass

        status_rows = await _snmp_walk(olt, OID_VSOL_ONU_STATUS)
        for row in status_rows:
            parts = row["oid"].split(".")
            if len(parts) >= 2:
                try:
                    pon, idx = int(parts[-2]), int(parts[-1])
                    if (pon, idx) in onus:
                        onus[(pon, idx)]["status"] = "authorized"
                        onus[(pon, idx)]["oper_status"] = "ONLINE" if row["value"] == "1" else "OFFLINE"
                except ValueError: pass

    # Debug logs para identificar duplicados o errores de puerto
    for k, v in onus.items():
        print(f"[DEBUG OLT] Found ONU at {k[0]}:{k[1]} -> SN: {v['serial_number']} | Status: {v.get('status')} | Oper: {v.get('oper_status', '???')}")

    result = list(onus.values())


    # 3. Fallback Telnet si SNMP no devolvió nada
    if not result:
        print(f"[OLT DISCOVERY] SNMP vacío para {olt.ip_address} — intentando Telnet")
        try:
            # Telnet es síncrono, lo corremos en un hilo para no bloquear el loop
            def _telnet_call():
                return OLTDriver._telnet_send(
                    olt.ip_address, 23, olt.username, olt.password,
                    ["config", "onu search 1", "exit"]
                )
            out = await asyncio.to_thread(_telnet_call)
            for line in out.splitlines():
                m = re.search(r"pon (\d+) onu (\d+) sn ([A-Za-z0-9]+) (Online|Offline)", line)
                if m:
                    result.append({
                        "pon_port": int(m.group(1)),
                        "onu_index": int(m.group(2)),
                        "serial_number": m.group(3).upper(),
                        "status": "authorized",
                        "oper_status": "ONLINE" if m.group(4) == "Online" else "OFFLINE"
                    })

        except Exception as e:
            print(f"[OLT TELNET FALLBACK] {olt.ip_address}: {e}")

    print(f"[OLT DISCOVERY] {olt.ip_address}: {len(result)} ONUs encontradas")
    return result
