"""
In-memory TTL cache + per-OLT asyncio locks for ONU SNMP detail fetches.
Reduces duplicate SNMP work when multiple clients poll the same ONU.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, Optional

TTL_SECONDS = 4.0

_cache: Dict[int, tuple[float, Dict[str, Any]]] = {}
_olt_locks: Dict[int, asyncio.Lock] = {}


def get_olt_snmp_lock(olt_id: int) -> asyncio.Lock:
    if olt_id not in _olt_locks:
        _olt_locks[olt_id] = asyncio.Lock()
    return _olt_locks[olt_id]


def cache_get(onu_id: int) -> Optional[Dict[str, Any]]:
    row = _cache.get(onu_id)
    if not row:
        return None
    expires_at, payload = row
    if time.monotonic() > expires_at:
        _cache.pop(onu_id, None)
        return None
    return dict(payload)


def cache_set(onu_id: int, payload: Dict[str, Any]) -> None:
    _cache[onu_id] = (time.monotonic() + TTL_SECONDS, dict(payload))


def cache_delete(onu_id: int) -> None:
    _cache.pop(onu_id, None)
