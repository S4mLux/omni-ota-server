import os
import json
import httpx
import subprocess
import shutil
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlmodel import Session, select
from typing import Dict, Any

from .database import get_session
from .auth_api import get_current_user
from .models import Staff, SystemConfig

router = APIRouter(prefix="/api/v2/system/updates", tags=["System Updates"])

VERSION_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "version.json")
UPDATE_SCRIPT = "/opt/omniISP/update.sh"

def get_local_version() -> dict:
    if os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, "r") as f:
            return json.load(f)
    return {"version": "1.0.0", "build_date": "Unknown"}

def parse_version(v: str) -> tuple:
    # "1.2.3" -> (1, 2, 3)
    try:
        return tuple(map(int, v.strip("v").split(".")))
    except:
        return (0, 0, 0)

@router.get("/config")
async def get_updater_config(
    session: Session = Depends(get_session),
    current_user: Staff = Depends(get_current_user)
):
    if current_user.permissions != "*":
        raise HTTPException(status_code=403, detail="Not authorized")
        
    config_url = session.exec(select(SystemConfig).where(SystemConfig.key == "update_server_url")).first()
    config_enabled = session.exec(select(SystemConfig).where(SystemConfig.key == "auto_update_enabled")).first()
    config_time = session.exec(select(SystemConfig).where(SystemConfig.key == "auto_update_time")).first()
    
    return {
        "update_server_url": config_url.value if config_url else "https://tu-usuario.github.io/omni-updates",
        "auto_update_enabled": config_enabled.value == "true" if config_enabled else False,
        "auto_update_time": config_time.value if config_time else "03:00"
    }

from pydantic import BaseModel
class UpdaterConfigPayload(BaseModel):
    update_server_url: str
    auto_update_enabled: bool = False
    auto_update_time: str = "03:00"

@router.post("/config")
async def set_updater_config(
    payload: UpdaterConfigPayload,
    session: Session = Depends(get_session),
    current_user: Staff = Depends(get_current_user)
):
    if current_user.permissions != "*":
        raise HTTPException(status_code=403, detail="Not authorized")
        
    # URL
    config_url = session.exec(select(SystemConfig).where(SystemConfig.key == "update_server_url")).first()
    if not config_url:
        config_url = SystemConfig(key="update_server_url", value=payload.update_server_url)
        session.add(config_url)
    else:
        config_url.value = payload.update_server_url

    # Auto Update Enabled
    config_enabled = session.exec(select(SystemConfig).where(SystemConfig.key == "auto_update_enabled")).first()
    if not config_enabled:
        config_enabled = SystemConfig(key="auto_update_enabled", value="true" if payload.auto_update_enabled else "false")
        session.add(config_enabled)
    else:
        config_enabled.value = "true" if payload.auto_update_enabled else "false"

    # Auto Update Time
    config_time = session.exec(select(SystemConfig).where(SystemConfig.key == "auto_update_time")).first()
    if not config_time:
        config_time = SystemConfig(key="auto_update_time", value=payload.auto_update_time)
        session.add(config_time)
    else:
        config_time.value = payload.auto_update_time

    session.commit()
    return {"status": "ok"}


@router.get("/check")
async def check_for_updates(
    session: Session = Depends(get_session),
    current_user: Staff = Depends(get_current_user)
):
    if current_user.permissions != "*":
        raise HTTPException(status_code=403, detail="Not authorized")

    # Obtener URL del servidor de actualizaciones
    config = session.exec(select(SystemConfig).where(SystemConfig.key == "update_server_url")).first()
    update_url = config.value if config else "https://tu-usuario.github.io/omni-updates"

    local_info = get_local_version()
    local_version = local_info.get("version", "1.0.0")

    manifest_url = f"{update_url.rstrip('/')}/omni-update.json"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(manifest_url)
            resp.raise_for_status()
            remote_info = resp.json()
    except Exception as e:
        return {
            "configured_url": update_url,
            "status": "error",
            "message": f"No se pudo conectar al servidor de actualizaciones: {str(e)}",
            "local_version": local_version
        }

    remote_version = remote_info.get("latest_version", "1.0.0")
    
    update_available = parse_version(remote_version) > parse_version(local_version)

    return {
        "status": "ok",
        "configured_url": update_url,
        "local_version": local_version,
        "update_available": update_available,
        "remote_info": remote_info
    }


def download_and_install_background(download_url: str):
    import time
    zip_path = "/var/tmp/omni_update.zip"
    
    try:
        # Descargar el archivo
        with httpx.stream("GET", download_url, follow_redirects=True) as r:
            r.raise_for_status()
            with open(zip_path, "wb") as f:
                for chunk in r.iter_bytes(chunk_size=8192):
                    f.write(chunk)
                    
        # Esperar 2 segundos para que la API responda al frontend antes del reinicio suicida
        time.sleep(2)
        
        # Extraer siempre el script de actualización más reciente del propio zip
        import zipfile
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                if "update.sh" in zf.namelist():
                    with open(UPDATE_SCRIPT, 'wb') as f_out:
                        f_out.write(zf.read("update.sh"))
        except Exception as e:
            print(f"[OTA] Failed to extract update.sh from zip: {e}")

        # Ejecutar el script de instalación
        if os.path.exists(UPDATE_SCRIPT):
            subprocess.Popen(["sudo", "bash", UPDATE_SCRIPT], start_new_session=True)
            
    except Exception as e:
        print(f"[OTA UPDATE ERROR] {e}")


@router.post("/install")
async def install_update(
    background_tasks: BackgroundTasks,
    session: Session = Depends(get_session),
    current_user: Staff = Depends(get_current_user)
):
    if current_user.permissions != "*":
        raise HTTPException(status_code=403, detail="Not authorized")

    # Repetimos la verificación para obtener la URL
    config = session.exec(select(SystemConfig).where(SystemConfig.key == "update_server_url")).first()
    if not config:
        raise HTTPException(status_code=400, detail="Servidor de actualizaciones no configurado")
        
    manifest_url = f"{config.value.rstrip('/')}/omni-update.json"
    
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(manifest_url)
            resp.raise_for_status()
            remote_info = resp.json()
    except Exception:
        raise HTTPException(status_code=500, detail="No se pudo obtener el manifiesto de la actualización")

    download_url = remote_info.get("download_url")
    if not download_url:
        raise HTTPException(status_code=400, detail="El manifiesto no contiene una URL de descarga")

    # Iniciar la descarga e instalación en segundo plano (para poder devolver una respuesta HTTP exitosa)
    background_tasks.add_task(download_and_install_background, download_url)

    return {"status": "ok", "message": "Descargando actualización. El sistema se reiniciará en breve."}

async def auto_check_and_install(session: Session) -> bool:
    """Internal function to be called by the background loop."""
    config_url = session.exec(select(SystemConfig).where(SystemConfig.key == "update_server_url")).first()
    update_url = config_url.value if config_url else "https://tu-usuario.github.io/omni-updates"

    local_info = get_local_version()
    local_version = local_info.get("version", "1.0.0")

    manifest_url = f"{update_url.rstrip('/')}/omni-update.json"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(manifest_url)
            resp.raise_for_status()
            remote_info = resp.json()
    except Exception as e:
        print(f"[AUTO-UPDATE] Error checking manifest: {e}")
        return False

    remote_version = remote_info.get("latest_version", "1.0.0")
    update_available = parse_version(remote_version) > parse_version(local_version)

    if update_available:
        download_url = remote_info.get("download_url")
        if download_url:
            print(f"[AUTO-UPDATE] Update {remote_version} found! Starting background installation...")
            from backend.websocket import manager
            import datetime
            await manager.broadcast({
                "type": "NOTIFICATION",
                "event": "SISTEMA_ACTUALIZACION",
                "message": f"Actualización automática {remote_version} encontrada. Instalando en segundo plano...",
                "timestamp": datetime.datetime.utcnow().isoformat()
            })
            import threading
            threading.Thread(target=download_and_install_background, args=(download_url,)).start()
            return True
            
    return False
