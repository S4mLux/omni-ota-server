from datetime import datetime
from typing import List, Optional
from sqlmodel import Field, SQLModel, Index
import uuid

# ─────────────────────────────────────────────
# INFRASTRUCTURE
# ─────────────────────────────────────────────

class Router(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    ip_address: str = Field(index=True)
    username: str
    password: str
    api_port: int = Field(default=8728)
    connection_mode: str = Field(default="API")  # API or REST
    role: str = Field(default="EDGE")             # EDGE, CORE, DISTRIBUTION
    status: str = Field(default="ONLINE")
    last_seen: datetime = Field(default_factory=datetime.utcnow)
    
    # SNMP Config
    snmp_community: str = Field(default="public")
    snmp_version: str = Field(default="v2c")
    snmp_port: int = Field(default=161)

    # Hardware Info
    brand: str = Field(default="mikrotik")  # mikrotik, huawei, cisco, arista, juniper, fortigate
    model: str = Field(default="auto")      # exact model name

class RouterCreate(SQLModel):
    name: str
    ip_address: str
    username: str
    password: str
    api_port: int = 8728
    connection_mode: str = "API"
    role: str = "EDGE"
    snmp_community: str = "public"
    snmp_version: str = "v2c"
    snmp_port: int = 161
    brand: str = "mikrotik"
    model: str = "auto"

class OLT(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    ip_address: str = Field(index=True)
    username: str = Field(default="admin")
    password: str = Field(default="admin")
    ssh_port: int = Field(default=22)
    snmp_community: str = Field(default="public")
    snmp_version: str = Field(default="v2c")
    snmp_username: Optional[str] = None
    snmp_auth_protocol: Optional[str] = None  # MD5, SHA
    snmp_auth_password: Optional[str] = None
    snmp_priv_protocol: Optional[str] = None  # DES, AES
    snmp_priv_password: Optional[str] = None
    auto_learn_enabled: bool = Field(default=False)
    model: str = Field(default="VSOL_GPON")
    status: str = Field(default="ONLINE")
    last_seen: datetime = Field(default_factory=datetime.utcnow)

class ONU(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    olt_id: int = Field(foreign_key="olt.id", index=True)
    pon_port: int
    onu_index: int
    serial_number: str = Field(index=True, unique=True)
    vlan: int = Field(default=100)
    
    # Información de hardware
    model: Optional[str] = Field(default=None)
    firmware: Optional[str] = Field(default=None)
    
    # Telemetría
    signal_dbm: Optional[float] = Field(default=None)
    signal_dbm_prev: Optional[float] = None  # Variación previa para alertas
    tx_power: Optional[float] = None
    distance: Optional[float] = None
    
    # Métricas de Ancho de Banda
    bandwidth_rx: float = Field(default=0.0) # Mbps
    bandwidth_tx: float = Field(default=0.0) # Mbps
    last_rx_octets: Optional[int] = None
    last_tx_octets: Optional[int] = None
    last_stats_time: Optional[datetime] = None
    
    status: str = Field(default="OFFLINE")
    last_seen: datetime = Field(default_factory=datetime.utcnow)
    intensive_monitoring_until: Optional[datetime] = Field(default=None)
    snmp_ifindex: Optional[int] = None

class OLTCreate(SQLModel):
    name: str
    ip_address: str
    username: str = "admin"
    password: str = "admin"
    ssh_port: int = 22
    snmp_version: str = "v2c"
    snmp_community: str = "public"
    snmp_username: Optional[str] = None
    snmp_auth_protocol: Optional[str] = None
    snmp_auth_password: Optional[str] = None
    snmp_priv_protocol: Optional[str] = None
    snmp_priv_password: Optional[str] = None
    auto_learn_enabled: bool = False
    model: str = "VSOL_GPON"

# ─────────────────────────────────────────────
# NETWORK PLANS
# ─────────────────────────────────────────────

class Plan(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(unique=True)
    download_limit: int      # Mbps
    upload_limit: int        # Mbps
    price: float             # USD
    burst_limit: Optional[int] = None
    priority: int = Field(default=8)
    mikrotik_profile: str = Field(default="default")
    mikrotik_rate_limit: Optional[str] = Field(default=None)

# ─────────────────────────────────────────────
# CLIENTS
# ─────────────────────────────────────────────

class Client(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    full_name: str = Field(index=True)
    dni: str = Field(index=True, unique=True)
    email: str = Field(index=True)
    phone: str
    address: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None

    # Network
    ip_address: Optional[str] = Field(default=None, index=True, unique=True)
    mac_address: Optional[str] = Field(default=None, index=True)
    onu_serial: Optional[str] = Field(default=None, index=True)
    plan_id: int = Field(foreign_key="plan.id")
    router_id: int = Field(foreign_key="router.id")
    onu_id: Optional[int] = Field(default=None, foreign_key="onu.id")

    # Signal & Telemetry
    last_signal_dbm: Optional[float] = None
    last_latency_ms: Optional[float] = None

    # Status
    status: str = Field(default="ACTIVE", index=True)          # ACTIVE, SUSPENDED, DEBTOR, MOROSO
    connection_type: str = Field(default="DHCP", index=True)   # PPPOE, DHCP
    prev_address_list: Optional[str] = Field(default=None)     # guardamos el address-list anterior antes de cortar

    # PPPoE
    pppoe_user: Optional[str] = Field(default=None)
    pppoe_pass: Optional[str] = None

    # Portal Access
    portal_user: Optional[str] = Field(default=None, index=True)
    portal_password: Optional[str] = Field(default=None)

    # DHCP
    dhcp_server: Optional[str] = Field(default="all")
    address_list: Optional[str] = Field(default=None)

    auto_reconnect: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    __table_args__ = (
        Index("idx_client_network", "ip_address", "mac_address"),
    )

# ─────────────────────────────────────────────
# SALES (Captación de clientes por vendedor)
# ─────────────────────────────────────────────

class Sale(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

    # Datos del prospecto
    full_name: str = Field(index=True)
    dni: str = Field(index=True)
    phone: str
    email: Optional[str] = None
    address: str
    lat: Optional[float] = None
    lng: Optional[float] = None
    cedula_photo_path: Optional[str] = None   # ruta local del archivo

    # Servicio solicitado
    plan_id: Optional[int] = Field(default=None, foreign_key="plan.id")
    connection_type: str = Field(default="DHCP")   # DHCP, PPPOE
    router_id: Optional[int] = Field(default=None, foreign_key="router.id")

    # Staff
    seller_id: Optional[int] = Field(default=None, foreign_key="staff.id")
    installer_id: Optional[int] = Field(default=None, foreign_key="staff.id")

    # Flujo
    status: str = Field(default="NUEVO", index=True)
    # NUEVO → PENDIENTE_INSTALACION → INSTALANDO → INSTALADO → ACTIVO → CANCELADO

    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# INSTALLATIONS (Registro fotográfico del instalador)
# ─────────────────────────────────────────────

class Installation(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sale_id: int = Field(foreign_key="sale.id", index=True, unique=True)

    # Técnico
    installer_id: Optional[int] = Field(default=None, foreign_key="staff.id")

    # Potencia NAP (caja de distribución)
    nap_photo_path: Optional[str] = None
    nap_signal_written: Optional[str] = None      # valor escrito por el técnico, e.g. "-18.5"
    nap_signal_photo_path: Optional[str] = None

    # Potencia interior (en casa del cliente)
    indoor_photo_path: Optional[str] = None
    indoor_signal_written: Optional[str] = None
    indoor_signal_photo_path: Optional[str] = None

    # ONU con cableado y Serial
    onu_cabling_photo_path: Optional[str] = None
    onu_serial_photo_path: Optional[str] = None
    onu_serial_written: Optional[str] = None

    # Cédula del cliente (confirmación presencial)
    client_cedula_photo_path: Optional[str] = None

    # Vinculación MikroTik
    mikrotik_lease_id: Optional[str] = None       # ID del lease dinámico vinculado
    mikrotik_secret_user: Optional[str] = None    # PPPoE user creado/vinculado

    # Estado
    status: str = Field(default="PENDIENTE")
    # PENDIENTE → EN_PROCESO → COMPLETADA → FALLIDA

    completed_at: Optional[datetime] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# BILLING — Facturas
# ─────────────────────────────────────────────

class Invoice(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    serial_number: str = Field(index=True, unique=True)  # FAC-2026-0001
    client_id: int = Field(foreign_key="client.id", index=True)

    # Montos
    amount: float = Field(default=0.0)         # campo legado para compatibilidad con DB vieja
    usd_amount: float
    tasa_bcv: float = Field(default=0.0)       # tasa del día de emisión
    bs_amount: float = Field(default=0.0)      # calculado: usd * tasa_bcv

    # Estado
    status: str = Field(default="PENDING", index=True)
    # PENDING, PAID, OVERDUE, REJECTED, CANCELLED

    period: str                  # e.g., "ABR-2026"
    due_date: datetime
    cut_off_date: Optional[datetime] = None
    paid_at: Optional[datetime] = None

    # Borrado con justificativo
    deleted_at: Optional[datetime] = None
    deleted_by: Optional[str] = None
    delete_justification: Optional[str] = None

    pdf_path: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    is_shadow: bool = Field(default=False)

# ─────────────────────────────────────────────
# PAYMENT RECEIPTS — Comprobantes de pago
# ─────────────────────────────────────────────

class PaymentReceipt(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    invoice_id: int = Field(foreign_key="invoice.id", index=True)
    client_id: int = Field(foreign_key="client.id", index=True)

    # Datos del comprobante
    bank: str                          # "BANCO DE VENEZUELA", "PROVINCIAL", etc.
    reference_number: str              # Número de referencia bancaria
    amount_paid_bs: float
    amount_paid_usd: Optional[float] = None
    photo_path: Optional[str] = None   # Foto del comprobante
    sender_phone: Optional[str] = None # Teléfono de la cuenta que hace el pago
    notes: Optional[str] = None

    # Verificación
    status: str = Field(default="PENDIENTE", index=True)
    # PENDIENTE, APROBADO, RECHAZADO
    reviewed_by: Optional[str] = None
    review_notes: Optional[str] = None
    reviewed_at: Optional[datetime] = None

    submitted_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# MIKROTIK PENDING CHANGES (cola offline)
# ─────────────────────────────────────────────

class MikrotikPendingChange(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    router_id: int = Field(foreign_key="router.id", index=True)

    action: str          # CREATE_DHCP, CREATE_PPPOE, SUSPEND_DHCP, RESTORE_DHCP, etc.
    payload: str         # JSON serializado de los parámetros
    description: str     # Descripción legible para el operador

    status: str = Field(default="PENDIENTE", index=True)
    # PENDIENTE, APLICADO, CANCELADO, FALLIDO

    created_by: Optional[str] = None
    applied_at: Optional[datetime] = None
    error_msg: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# BCV RATE — Tasa del Banco Central de Venezuela
# ─────────────────────────────────────────────

class BcvRate(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    date: datetime = Field(default_factory=datetime.utcnow, index=True)
    usd_rate: float        # Bs por 1 USD
    source: str = Field(default="BCV")
    raw_text: Optional[str] = None

# ─────────────────────────────────────────────
# TRANSACTIONS
# ─────────────────────────────────────────────

class Transaction(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    client_id: int = Field(foreign_key="client.id", index=True)
    amount: float
    status: str = Field(index=True)
    payment_method: str
    transaction_id: str = Field(unique=True)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    is_shadow: bool = Field(default=False)

# ─────────────────────────────────────────────
# SUPPORT TICKETS
# ─────────────────────────────────────────────

class SupportTicket(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ticket_number: str = Field(index=True, unique=True) # e.g. TIC-8821
    client_id: int = Field(foreign_key="client.id", index=True)
    assigned_tech_id: Optional[int] = Field(default=None, foreign_key="staff.id")
    subject: str
    description: str
    refined_issue: Optional[str] = Field(default=None, nullable=True)
    messages: Optional[str] = Field(default=None, nullable=True) # JSON string for AI chat history
    status: str = Field(default="OPEN", index=True) # OPEN, PENDING_AI, IN_PROGRESS, RESOLVED
    priority: str = Field(default="MEDIUM") # LOW, MEDIUM, HIGH, CRITICAL
    signal_dbm: Optional[float] = Field(default=None, nullable=True)
    latency_ms: Optional[float] = Field(default=None, nullable=True)
    is_router_online: bool = Field(default=True)
    photo_path: Optional[str] = Field(default=None, nullable=True) # Foto del daño o estado de ONU
    is_read_by_staff: bool = Field(default=False)
    is_read_by_client: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class TicketMessage(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    ticket_id: int = Field(foreign_key="supportticket.id", index=True)
    sender_type: str = Field(index=True) # "CLIENT" | "STAFF"
    sender_id: int # client.id o staff.id
    sender_name: str
    message: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# DDoS EVENTS
# ─────────────────────────────────────────────

class DDoS_Event(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    router_id: int = Field(foreign_key="router.id")
    pps_count: int
    attack_type: str
    mitigation_action: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# STAFF
# ─────────────────────────────────────────────

class Staff(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    full_name: str = Field(index=True)
    dni: str = Field(index=True, unique=True)
    email: str = Field(index=True, unique=True)
    phone: Optional[str] = None
    address: Optional[str] = None
    position: str = Field(index=True)
    permissions: str = Field(default="*")
    status: str = Field(default="ACTIVE")
    pin: Optional[str] = Field(default=None)   # PIN de 4 dígitos para login
    created_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# DAILY CONSUMPTION
# ─────────────────────────────────────────────

class DailyConsumption(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    client_id: int = Field(foreign_key="client.id", index=True)
    download_mb: float
    upload_mb: float
    date: datetime = Field(default_factory=datetime.utcnow, index=True)

# ─────────────────────────────────────────────
# SYSTEM CONFIG
# ─────────────────────────────────────────────

class SystemConfig(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    key: str = Field(index=True, unique=True)
    value: str
    description: Optional[str] = None
    updated_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# NOTIFICATION LOGS
# ─────────────────────────────────────────────

class NotificationLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    client_id: int = Field(foreign_key="client.id", index=True)
    invoice_id: Optional[int] = Field(default=None, foreign_key="invoice.id", index=True)
    
    type: str = Field(index=True) # PRE_CUT_WARNING, FINAL_NOTICE, RECONNECTION
    channel: str = Field(default="WHATSAPP")
    status: str = Field(default="SENT") # SENT, FAILED
    
    phone_number: str
    message_body: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    sent_at: Optional[datetime] = Field(default_factory=datetime.utcnow)


# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
# MIKROTIK HARDWARE SNAPSHOT
# ─────────────────────────────────────────────

class MikrotikHardwareRecord(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    router_id: int = Field(foreign_key="router.id", index=True)
    
    # "PPPOE_SECRET", "DHCP_LEASE", "PPPOE_ACTIVE"
    record_type: str = Field(index=True)
    
    # Identificadores primarios para emparejamiento
    name: str = Field(index=True)           # username o ip (key principal en mk)
    comment: Optional[str] = Field(default=None, index=True)
    mac_address: Optional[str] = Field(default=None, index=True)
    ip_address: Optional[str] = Field(default=None, index=True)
    
    # Payload completo para debug y recreación
    raw_data: str = Field(default="{}")     # JSON stringified
    
    synced_at: datetime = Field(default_factory=datetime.utcnow)

# ─────────────────────────────────────────────
# ATTENDANCE
# ─────────────────────────────────────────────

class AttendanceLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    staff_id: int = Field(foreign_key="staff.id", index=True)
    action: str = Field(index=True) # "IN", "OUT", "BREAK"
    timestamp: datetime = Field(default_factory=datetime.utcnow, index=True)
    lat: Optional[float] = None
    lng: Optional[float] = None
    device_info: Optional[str] = None

# ─────────────────────────────────────────────
# ONU SIGNAL HISTORY
# ─────────────────────────────────────────────

class ONUSignalHistory(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    onu_id: int = Field(foreign_key="onu.id", index=True)
    signal_dbm: float
    bandwidth_rx: float = Field(default=0.0)
    bandwidth_tx: float = Field(default=0.0)
    timestamp: datetime = Field(default_factory=datetime.utcnow, index=True)


class HardwareMetric(SQLModel, table=True):
    """Historial de telemetría SNMP para routers y hardware (estilo MRTG)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    router_id: int = Field(foreign_key="router.id", index=True)
    timestamp: datetime = Field(default_factory=datetime.utcnow, index=True)
    cpu_load: int
    ram_usage_percent: float
    traffic_in_bytes: int
    traffic_out_bytes: int
    interface_name: str = Field(default="eth1")

def generate_invoice_serial(year: int, sequence: int) -> str:
    """Genera serial único: FAC-2026-00001"""
    return f"FAC-{year}-{str(sequence).zfill(5)}"

