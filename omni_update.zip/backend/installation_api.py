"""
Installation API — Flujo fotográfico de instalación + vinculación MikroTik
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlmodel import Session, select
from typing import Optional
from datetime import datetime
from pydantic import BaseModel
import os, shutil, json

from backend.models import (
    Installation, Sale, Client, Router, Plan,
    Staff, MikrotikPendingChange, ONU
)
from backend.database import get_session
from backend.mikrotik_driver import MikroTikDriver
from backend.notifications import NotificationDispatcher, EVENTS

router = APIRouter(prefix="/api/v2/installations", tags=["installations"])

UPLOAD_DIR = "uploads/installations"
os.makedirs(UPLOAD_DIR, exist_ok=True)


def save_file(upload: UploadFile, prefix: str) -> str:
    ext = os.path.splitext(upload.filename)[1] if upload.filename else ".jpg"
    fname = f"{prefix}_{int(datetime.utcnow().timestamp())}{ext}"
    fpath = os.path.join(UPLOAD_DIR, fname)
    with open(fpath, "wb") as f:
        shutil.copyfileobj(upload.file, f)
    return fpath


# ─────────────────────────────────────────────
# INSTALACIONES
# ─────────────────────────────────────────────

@router.get("")
async def list_installations(
    status: Optional[str] = None,
    session: Session = Depends(get_session)
):
    query = select(Installation)
    if status:
        query = query.where(Installation.status == status)
    return session.exec(query.order_by(Installation.created_at.desc())).all()

@router.get("/pending")
async def get_pending_for_installer(
    installer_id: Optional[int] = None,
    session: Session = Depends(get_session)
):
    """Instalaciones pendientes — vista del instalador"""
    sales_query = select(Sale).where(Sale.status.in_(["PENDIENTE_INSTALACION", "INSTALANDO"]))
    if installer_id:
        sales_query = sales_query.where(Sale.installer_id == installer_id)
    sales = session.exec(sales_query).all()
    
    result = []
    for sale in sales:
        plan = session.get(Plan, sale.plan_id) if sale.plan_id else None
        router_obj = session.get(Router, sale.router_id) if sale.router_id else None
        install = session.exec(select(Installation).where(Installation.sale_id == sale.id)).first()
        result.append({
            **sale.dict(),
            "plan_name": plan.name if plan else None,
            "router_name": router_obj.name if router_obj else None,
            "router_id": router_obj.id if router_obj else None,
            "installation": install.dict() if install else None,
        })
    return result

@router.post("/{sale_id}/start")
async def start_installation(sale_id: int, session: Session = Depends(get_session)):
    """Inicia el proceso de instalación"""
    sale = session.get(Sale, sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")
    
    # Evitar duplicados
    existing = session.exec(select(Installation).where(Installation.sale_id == sale_id)).first()
    if existing:
        return existing
    
    install = Installation(sale_id=sale_id, installer_id=sale.installer_id, status="EN_PROCESO")
    session.add(install)
    sale.status = "INSTALANDO"
    session.add(sale)
    session.commit()
    session.refresh(install)
    return install


@router.post("/{sale_id}/upload-photo")
async def upload_installation_photo(
    sale_id: int,
    photo_type: str = Form(...),  # nap, nap_signal, indoor, indoor_signal, onu_cabling, client_cedula
    signal_value: Optional[str] = Form(None),
    photo: UploadFile = File(...),
    session: Session = Depends(get_session)
):
    """Sube una foto del proceso de instalación"""
    install = session.exec(select(Installation).where(Installation.sale_id == sale_id)).first()
    if not install:
        raise HTTPException(status_code=404, detail="Instalación no iniciada. Llama a /start primero.")
    
    fpath = save_file(photo, f"{sale_id}_{photo_type}")
    
    field_map = {
        "nap": "nap_photo_path",
        "nap_signal": "nap_signal_photo_path",
        "indoor": "indoor_photo_path",
        "indoor_signal": "indoor_signal_photo_path",
        "onu_cabling": "onu_cabling_photo_path",
        "onu_serial": "onu_serial_photo_path",
        "client_cedula": "client_cedula_photo_path",
    }
    signal_map = {
        "nap": "nap_signal_written",
        "indoor": "indoor_signal_written",
        "onu_serial": "onu_serial_written",
    }

    if photo_type in field_map:
        setattr(install, field_map[photo_type], fpath)
    if signal_value and photo_type in signal_map:
        setattr(install, signal_map[photo_type], signal_value)
    
    session.add(install)
    session.commit()
    return {"photo_type": photo_type, "path": fpath, "signal": signal_value}


class LinkMikrotikSchema(BaseModel):
    router_id: int
    connection_type: str  # DHCP or PPPOE
    # DHCP params
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    dhcp_server: Optional[str] = "all"
    # PPPoE params
    pppoe_user: Optional[str] = None
    pppoe_pass: Optional[str] = None
    pppoe_profile: Optional[str] = "default"
    # Link to existing dynamic lease
    existing_lease_id: Optional[str] = None

@router.post("/{sale_id}/link-mikrotik")
async def link_to_mikrotik(
    sale_id: int,
    body: LinkMikrotikSchema,
    session: Session = Depends(get_session)
):
    """
    Vincula la instalación con MikroTik:
    - Crea o vincula un DHCP lease estático
    - O crea un PPPoE secret
    - Crea el cliente en el sistema
    """
    sale = session.get(Sale, sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Venta no encontrada")
    
    install = session.exec(select(Installation).where(Installation.sale_id == sale_id)).first()
    if not install:
        raise HTTPException(status_code=404, detail="Instalación no encontrada")
    
    # Validaciones estrictas: la instalación exige serial PON validado
    if not install.onu_serial_written or not install.onu_serial_photo_path:
        raise HTTPException(
            status_code=400, 
            detail="Falta enviar la foto del Serial PON y escribir el Serial PON. Son obligatorios para corte automatizado en la OLT."
        )

    router_obj = session.get(Router, body.router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router no encontrado")
    
    plan = session.get(Plan, sale.plan_id)
    mikrotik_ok = False
    
    if body.connection_type == "DHCP":
        lease_comment = f"{sale.full_name} | {sale.dni} | {sale.phone}"
        params = {
            "ip-address": body.ip_address,
            "mac-address": body.mac_address or "00:00:00:00:00:00",
            "server": body.dhcp_server or "all",
            "comment": lease_comment,
        }
        mikrotik_ok = await MikroTikDriver.create_dhcp_lease(router_obj, params)
        install.mikrotik_lease_id = body.existing_lease_id or body.ip_address
    
    elif body.connection_type == "PPPOE":
        lease_comment = f"{sale.full_name} | {sale.dni} | {sale.phone}"
        params_ppoe = {
            "name": body.pppoe_user,
            "password": body.pppoe_pass,
            "profile": body.pppoe_profile or (plan.mikrotik_profile if plan else "default"),
            "comment": lease_comment,
        }
        if body.ip_address:
            params_ppoe["remote-address"] = body.ip_address
        mikrotik_ok = await MikroTikDriver.create_pppoe_secret(router_obj, params_ppoe)
        install.mikrotik_secret_user = body.pppoe_user
    
    if not mikrotik_ok:
        # Guardar como cambio pendiente para cuando se restablezca la conexión
        pending = MikrotikPendingChange(
            router_id=body.router_id,
            action=f"CREATE_{body.connection_type}",
            payload=json.dumps(body.dict()),
            description=f"Crear servicio para {sale.full_name} ({sale.dni})",
            created_by="INSTALACION"
        )
        session.add(pending)

    # Buscar si la ONU por serial ya había sido detectada/autorizada en la OLT
    from backend.models import Client, ONU
    onu_obj = session.exec(select(ONU).where(ONU.serial_number == install.onu_serial_written)).first()
    onu_id = onu_obj.id if onu_obj else None

    existing_client = session.exec(select(Client).where(Client.dni == sale.dni)).first()
    if not existing_client:
        new_client = Client(
            full_name=sale.full_name,
            dni=sale.dni,
            email=sale.email or f"{sale.dni}@omni.net",
            phone=sale.phone,
            address=sale.address,
            lat=sale.lat,
            lng=sale.lng,
            ip_address=body.ip_address or "0.0.0.0",
            mac_address=body.mac_address,
            onu_serial=install.onu_serial_written,
            onu_id=onu_id,
            plan_id=sale.plan_id or 1,
            router_id=body.router_id,
            connection_type=body.connection_type,
            pppoe_user=body.pppoe_user,
            pppoe_pass=body.pppoe_pass,
            dhcp_server=body.dhcp_server,
            status="ACTIVE"
        )
        session.add(new_client)
    else:
        # En caso de que el cliente exista y le estemos agregando hardware
        existing_client.onu_serial = install.onu_serial_written
        existing_client.onu_id = onu_id
        session.add(existing_client)

    # DISPATCH NOTIFICATION: Nuevo cliente registrado (via instalación)
    await NotificationDispatcher.dispatch(
        EVENTS["NEW_CLIENT"],
        f"Nuevo cliente registrado tras instalación exitosa: {sale.full_name} ({sale.dni}). Plan ID: {sale.plan_id}.",
        session,
        client_id=existing_client.id if existing_client else None
    )

    # Marcar instalación como completada
    install.status = "COMPLETADA"
    install.completed_at = datetime.utcnow()
    session.add(install)

    sale.status = "INSTALADO"
    sale.updated_at = datetime.utcnow()
    session.add(sale)
    
    session.commit()
    return {
        "status": "COMPLETADA",
        "mikrotik_provisioned": mikrotik_ok,
        "pending_change_created": not mikrotik_ok,
        "client_created": existing_client is None
    }


# ─────────────────────────────────────────────
# COLA DE CAMBIOS PENDIENTES (STANDBY)
# ─────────────────────────────────────────────

@router.get("/pending-changes")
async def list_pending_changes(
    router_id: Optional[int] = None,
    session: Session = Depends(get_session)
):
    query = select(MikrotikPendingChange).where(MikrotikPendingChange.status == "PENDIENTE")
    if router_id:
        query = query.where(MikrotikPendingChange.router_id == router_id)
    return session.exec(query.order_by(MikrotikPendingChange.created_at.asc())).all()

@router.post("/pending-changes/{change_id}/apply")
async def apply_pending_change(change_id: int, session: Session = Depends(get_session)):
    """Intenta aplicar un cambio pendiente al router"""
    change = session.get(MikrotikPendingChange, change_id)
    if not change:
        raise HTTPException(status_code=404, detail="Cambio no encontrado")
    
    router_obj = session.get(Router, change.router_id)
    if not router_obj:
        raise HTTPException(status_code=404, detail="Router no encontrado")
    
    payload = json.loads(change.payload)
    success = False
    
    try:
        if change.action == "CREATE_DHCP":
            success = await MikroTikDriver.create_dhcp_lease(router_obj, payload)
        elif change.action == "CREATE_PPPOE":
            success = await MikroTikDriver.create_pppoe_secret(router_obj, payload)
        elif change.action == "SUSPEND_DHCP":
            success = await MikroTikDriver.suspend_dhcp_client(router_obj, payload.get("ip", ""))
        elif change.action == "SUSPEND_PPPOE":
            success = await MikroTikDriver.suspend_pppoe_client(router_obj, payload.get("user", ""))
        elif change.action == "RESTORE_DHCP":
            success = await MikroTikDriver.restore_dhcp_client(router_obj, payload.get("ip", ""), payload.get("prev_list", ""))
        elif change.action == "RESTORE_PPPOE":
            success = await MikroTikDriver.restore_pppoe_client(router_obj, payload.get("user", ""))
    except Exception as e:
        change.error_msg = str(e)
    
    change.status = "APLICADO" if success else "FALLIDO"
    change.applied_at = datetime.utcnow() if success else None
    session.add(change)
    session.commit()
    return {"status": change.status, "success": success}

@router.delete("/pending-changes/{change_id}")
async def cancel_pending_change(change_id: int, session: Session = Depends(get_session)):
    change = session.get(MikrotikPendingChange, change_id)
    if not change:
        raise HTTPException(status_code=404, detail="Cambio no encontrado")
    change.status = "CANCELADO"
    session.add(change)
    session.commit()
    return {"status": "CANCELADO"}
