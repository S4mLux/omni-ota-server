import sqlite3
import os

db_path = 'omni_isp.db'
if not os.path.exists(db_path):
    print("Base de datos no existe")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Verificar tabla OLT
cursor.execute('SELECT name FROM sqlite_master WHERE type="table" AND name="olt"')
result = cursor.fetchone()
print('Tabla OLT existe:', result is not None)

if result:
    # Verificar columnas
    cursor.execute('PRAGMA table_info(olt)')
    columns = [row[1] for row in cursor.fetchall()]
    print('Columnas en OLT:', columns)

    # Verificar si tiene columnas SNMP
    snmp_columns = ['snmp_version', 'snmp_username', 'snmp_auth_protocol', 'snmp_auth_password', 'snmp_priv_protocol', 'snmp_priv_password']
    missing = [col for col in snmp_columns if col not in columns]
    if missing:
        print('Columnas SNMP faltantes:', missing)
    else:
        print('✓ Todas las columnas SNMP están presentes')

    # Contar registros
    cursor.execute('SELECT COUNT(*) FROM olt')
    count = cursor.fetchone()[0]
    print('Registros en OLT:', count)

    # Mostrar algunos registros
    if count > 0:
        cursor.execute('SELECT id, name, ip_address, snmp_version, snmp_community, snmp_username FROM olt ORDER BY id DESC LIMIT 3')
        rows = cursor.fetchall()
        print('Últimos registros:')
        for row in rows:
            print(f'  ID: {row[0]}, Name: {row[1]}, IP: {row[2]}, SNMP Version: {row[3]}, Community: {row[4]}, Username: {row[5]}')

conn.close()