1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/01~.s39~gw4s1.js","/_next/static/chunks/09t2isllljna7.js","/_next/static/chunks/14d95v2q-d4b-.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/01~.s39~gw4s1.js","/_next/static/chunks/09t2isllljna7.js","/_next/static/chunks/14d95v2q-d4b-.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/01~.s39~gw4s1.js","/_next/static/chunks/09t2isllljna7.js","/_next/static/chunks/14d95v2q-d4b-.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Omni-ISP | Neural Orchestrator"}],["$","meta","1",{"name":"description","content":"Advanced ISP Management System"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"2usAKYOe-ZLrGgLWZtItf"}
