module.exports=[72356,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_mikrotik_page_actions_0gk4by5.js.map