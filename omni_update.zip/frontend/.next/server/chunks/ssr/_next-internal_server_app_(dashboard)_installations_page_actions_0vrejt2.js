module.exports=[53927,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_installations_page_actions_0vrejt2.js.map