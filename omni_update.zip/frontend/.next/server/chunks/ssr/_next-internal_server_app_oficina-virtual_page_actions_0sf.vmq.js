module.exports=[10530,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_oficina-virtual_page_actions_0sf.vmq.js.map