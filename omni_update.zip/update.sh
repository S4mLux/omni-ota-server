#!/bin/bash
# =============================================================
# OmniISP — Actualizador rápido sin reinstalar
# Ejecutar en el servidor Ubuntu: sudo bash /opt/omniISP/update.sh
# =============================================================
set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Iniciando actualización rápida de OmniISP...${NC}"

# Verificar paquete de actualización
if [ ! -f "/var/tmp/omni_update.zip" ]; then
    echo -e "❌ No se encontró /var/tmp/omni_update.zip"
    echo "Sube el archivo de actualización usando SCP antes de ejecutar este script."
    exit 1
fi

APP_DIR="/opt/omniISP"

# 1. Detener servicios
echo "1. Deteniendo servicios..."
systemctl stop omni-backend omni-frontend

# 2. Descomprimir actualización temporalmente
echo "2. Extrayendo actualización..."
cd /var/tmp
rm -rf omni_update_temp
unzip -q omni_update.zip -d omni_update_temp

# 3. Aplicar backend
if [ -d "omni_update_temp/backend" ]; then
    echo "   -> Actualizando Backend..."
    cp -r omni_update_temp/backend/. $APP_DIR/backend/
    
    # Actualizar dependencias si hay cambios
    if [ -f "omni_update_temp/backend/requirements.txt" ]; then
        echo "   -> Verificando dependencias de Python..."
        $APP_DIR/.venv/bin/pip install -r $APP_DIR/backend/requirements.txt -q
    fi
fi

# 4. Aplicar frontend
if [ -d "omni_update_temp/frontend" ]; then
    echo "   -> Actualizando Frontend..."
    cp -r omni_update_temp/frontend/. $APP_DIR/frontend/
fi

# 4.5 Aplicar archivos raiz (version.json, update.sh)
if [ -f "omni_update_temp/version.json" ]; then
    cp omni_update_temp/version.json $APP_DIR/
fi
if [ -f "omni_update_temp/update.sh" ]; then
    cp omni_update_temp/update.sh $APP_DIR/
    chmod +x $APP_DIR/update.sh
fi

# 5. Permisos
echo "3. Ajustando permisos..."
chown -R omni:omni $APP_DIR

# 6. Limpieza y reinicio
echo "4. Reiniciando servicios..."
rm -rf /var/tmp/omni_update_temp
rm -f /var/tmp/omni_update.zip

systemctl start omni-backend omni-frontend
systemctl reload nginx

echo -e "${GREEN}✅ SISTEMA ACTUALIZADO CORRECTAMENTE${NC}"
