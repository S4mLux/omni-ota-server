#!/bin/bash
# =============================================================
# OmniISP — Actualizador seguro con Rollback
# Ejecutar en el servidor Ubuntu: sudo bash /opt/omniISP/update.sh
# =============================================================
set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}Iniciando actualización segura de OmniISP...${NC}"

if [ ! -f "/var/tmp/omni_update.zip" ]; then
    echo -e "${RED}❌ No se encontró /var/tmp/omni_update.zip${NC}"
    exit 1
fi

APP_DIR="/opt/omniISP"
BACKUP_DIR="/var/tmp/omni_backup"
TEMP_DIR="/var/tmp/omni_update_temp"

# Función de Rollback
rollback() {
    echo -e "${RED}⚠️ ERROR DETECTADO. INICIANDO ROLLBACK...${NC}"
    systemctl stop omni-frontend || true
    systemctl stop omni-backend || true
    
    if [ -d "$BACKUP_DIR/backend" ]; then
        echo "Restaurando backend..."
        rm -rf $APP_DIR/backend
        cp -r $BACKUP_DIR/backend $APP_DIR/
    fi
    if [ -d "$BACKUP_DIR/frontend" ]; then
        echo "Restaurando frontend..."
        rm -rf $APP_DIR/frontend
        cp -r $BACKUP_DIR/frontend $APP_DIR/
    fi
    
    chown -R omni:omni $APP_DIR
    
    systemctl start omni-frontend || true
    systemctl start omni-backend || true
    
    echo -e "${YELLOW}🔄 Rollback completado. El sistema ha vuelto a la normalidad.${NC}"
    exit 1
}

# Configurar trap para atrapar cualquier error y lanzar rollback
trap rollback ERR

# 1. Preparación y Backup
echo "1. Creando punto de restauración (Backup)..."
rm -rf $BACKUP_DIR
mkdir -p $BACKUP_DIR

# Detener servicios para evitar corrupciones durante la copia
systemctl stop omni-frontend
systemctl stop omni-backend

if [ -d "$APP_DIR/backend" ]; then
    cp -r $APP_DIR/backend $BACKUP_DIR/
fi
if [ -d "$APP_DIR/frontend" ]; then
    cp -r $APP_DIR/frontend $BACKUP_DIR/
fi

# 2. Descomprimir actualización
echo "2. Extrayendo actualización..."
rm -rf $TEMP_DIR
unzip -q /var/tmp/omni_update.zip -d $TEMP_DIR

# 3. Aplicar backend
if [ -d "$TEMP_DIR/backend" ]; then
    echo "   -> Actualizando Backend..."
    cp -r $TEMP_DIR/backend/. $APP_DIR/backend/
    
    if [ -f "$TEMP_DIR/backend/requirements.txt" ]; then
        echo "   -> Instalando dependencias de Python..."
        $APP_DIR/.venv/bin/pip install -r $APP_DIR/backend/requirements.txt -q
    fi
fi

# 4. Aplicar frontend
if [ -d "$TEMP_DIR/frontend" ]; then
    echo "   -> Actualizando Frontend..."
    cp -r $TEMP_DIR/frontend/. $APP_DIR/frontend/
fi

# 5. Aplicar scripts raiz
if [ -f "$TEMP_DIR/version.json" ]; then
    cp $TEMP_DIR/version.json $APP_DIR/
fi
if [ -f "$TEMP_DIR/update.sh" ]; then
    cp $TEMP_DIR/update.sh $APP_DIR/
    chmod +x $APP_DIR/update.sh
fi

# 6. Permisos y limpieza
echo "3. Ajustando permisos..."
chown -R omni:omni $APP_DIR

echo "4. Limpiando archivos temporales..."
rm -rf $TEMP_DIR
rm -f /var/tmp/omni_update.zip
# Mantenemos el backup temporal por si acaso, se borrará en la próxima actualización

# 7. Reinicio de servicios
# Desactivamos el trap de error momentáneamente por si systemctl da algún warning menor
trap - ERR
echo "5. Reiniciando servicios..."
systemctl start omni-frontend
systemctl start omni-backend
systemctl reload nginx || true

echo -e "${GREEN}✅ SISTEMA ACTUALIZADO CORRECTAMENTE${NC}"
