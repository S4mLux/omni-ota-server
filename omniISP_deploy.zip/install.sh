#!/bin/bash
# =============================================================
# OmniISP — Ubuntu Server 22.04 Installation Script
# Run as root desde la carpeta del paquete:
#   cd /var/tmp/omniISP_deploy && sudo bash install.sh
# =============================================================
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo -e "${BLUE}"
cat << 'EOF'
 ██████╗ ███╗   ███╗███╗   ██╗██╗    ██╗███████╗██████╗
██╔═══██╗████╗ ████║████╗  ██║██║    ██║╚══███╔╝╚════██╗
██║   ██║██╔████╔██║██╔██╗ ██║██║    ██║  ███╔╝   ███╔═╝
██║   ██║██║╚██╔╝██║██║╚██╗██║██║    ██║ ███╔╝   ███╔╝
╚██████╔╝██║ ╚═╝ ██║██║ ╚████║██║    ██║███████╗ ███████╗
 ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═══╝╚═╝    ╚═╝╚══════╝╚══════╝
                    ISP Management Platform
EOF
echo -e "${NC}"

[ "$EUID" -ne 0 ] && err "Este script debe ejecutarse como root: sudo bash install.sh"

# Directorio donde está el script (funciona desde cualquier ubicación)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log "Directorio de instalación: $SCRIPT_DIR"

# Verificar que los archivos necesarios existen
[ -d "$SCRIPT_DIR/backend" ]  || err "No se encontró la carpeta 'backend'. Asegúrate de ejecutar desde la carpeta del paquete."
[ -f "$SCRIPT_DIR/omni-backend.service" ]  || err "No se encontró omni-backend.service en $SCRIPT_DIR"
[ -f "$SCRIPT_DIR/omni-frontend.service" ] || err "No se encontró omni-frontend.service en $SCRIPT_DIR"
[ -f "$SCRIPT_DIR/nginx.conf" ]            || err "No se encontró nginx.conf en $SCRIPT_DIR"

# ── 1. System packages ─────────────────────────────────────────────
log "Actualizando sistema e instalando dependencias del sistema..."
apt-get update -q
apt-get install -y -q \
    python3.11 python3.11-venv python3.11-dev \
    nginx \
    git curl wget \
    snmp snmpd \
    ufw \
    build-essential libssl-dev libffi-dev

# Node.js 20 LTS — siempre desde NodeSource para evitar conflictos con paquetes de Ubuntu
NODE_VER=$(node -v 2>/dev/null | sed 's/v//' | cut -d. -f1 || echo 0)
if [ "$NODE_VER" -lt 18 ]; then
    log "Eliminando restos de Node.js del repositorio Ubuntu (evita conflictos)..."
    # Purge COMPLETO de todos los paquetes relacionados con nodejs de Ubuntu
    apt-get purge -y nodejs libnode-dev libnode72 npm node-* 2>/dev/null || true
    apt-get autoremove -y 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/nodesource.list
    log "Instalando Node.js 20 LTS desde NodeSource..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
    log "Node.js $(node -v) y npm $(npm -v) instalados."
else
    log "Node.js $(node -v) ya está instalado y es compatible."
fi

# ── 2. Create system user ───────────────────────────────────
if ! id -u omni &>/dev/null; then
    log "Creando usuario del sistema 'omni'..."
    useradd -r -s /bin/bash -m -d /opt/omniISP omni
else
    log "Usuario 'omni' ya existe."
fi

# ── 3. Deploy application ───────────────────────────────────
APP_DIR="/opt/omniISP"
log "Preparando directorio $APP_DIR..."
mkdir -p $APP_DIR/uploads/{payments,tickets,installations}
mkdir -p $APP_DIR/frontend

log "Copiando backend..."
cp -r "$SCRIPT_DIR/backend" $APP_DIR/

log "Copiando base de datos..."
if [ -f "$SCRIPT_DIR/omni_isp.db" ]; then
    cp "$SCRIPT_DIR/omni_isp.db" $APP_DIR/
    log "Base de datos existente copiada."
else
    warn "No se encontró omni_isp.db — se creará una base de datos nueva al iniciar."
fi

# Frontend standalone build
if [ -d "$SCRIPT_DIR/frontend" ] && [ -f "$SCRIPT_DIR/frontend/server.js" ]; then
    log "Copiando frontend standalone..."
    cp -r "$SCRIPT_DIR/frontend/." $APP_DIR/frontend/
    log "Frontend copiado."
elif [ -d "$SCRIPT_DIR/frontend/.next/standalone" ]; then
    log "Copiando frontend (formato alternativo)..."
    cp -r "$SCRIPT_DIR/frontend/.next/standalone/." $APP_DIR/frontend/
    cp -r "$SCRIPT_DIR/frontend/.next/static" $APP_DIR/frontend/.next/
    [ -d "$SCRIPT_DIR/frontend/public" ] && cp -r "$SCRIPT_DIR/frontend/public" $APP_DIR/frontend/
    log "Frontend copiado."
else
    err "No se encontró el build del frontend en $SCRIPT_DIR/frontend.\n
  En tu PC Windows, ejecuta primero:\n
    cd frontend && npm run build\n
  Luego transfiere la carpeta frontend/.next/standalone al paquete."
fi

# ── 4. Python virtualenv & deps ─────────────────────────────
log "Creando entorno virtual Python 3.11..."
python3.11 -m venv $APP_DIR/.venv
log "Instalando dependencias Python (puede tardar 1-2 minutos)..."
$APP_DIR/.venv/bin/pip install --upgrade pip -q
$APP_DIR/.venv/bin/pip install -r $APP_DIR/backend/requirements.txt
log "Dependencias Python instaladas."

# ── 5. Permissions ──────────────────────────────────────────
log "Configurando permisos..."
chown -R omni:omni $APP_DIR
chmod -R 755 $APP_DIR
chmod 664 $APP_DIR/omni_isp.db 2>/dev/null || true

# ── 6. Systemd services ─────────────────────────────────────
log "Instalando servicios systemd..."
cp "$SCRIPT_DIR/omni-backend.service"  /etc/systemd/system/
cp "$SCRIPT_DIR/omni-frontend.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable omni-backend omni-frontend
log "Iniciando servicios..."
systemctl start omni-backend || warn "Backend no pudo iniciar — revisa: journalctl -u omni-backend -n 30"
sleep 3
systemctl start omni-frontend || warn "Frontend no pudo iniciar — revisa: journalctl -u omni-frontend -n 30"

# ── 7. Nginx ────────────────────────────────────────────────
log "Configurando Nginx..."
cp "$SCRIPT_DIR/nginx.conf" /etc/nginx/sites-available/omniISP
ln -sf /etc/nginx/sites-available/omniISP /etc/nginx/sites-enabled/omniISP
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
systemctl enable nginx

# ── 8. Firewall ─────────────────────────────────────────────
log "Configurando firewall UFW..."
ufw --force enable
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
warn "Puerto 8000 (API directa) NO está expuesto — solo accesible desde localhost."

# ── Estado final ────────────────────────────────────────────
echo
echo -e "${BLUE}Estado de los servicios:${NC}"
systemctl is-active omni-backend  && echo -e "  omni-backend:  ${GREEN}ACTIVO${NC}" || echo -e "  omni-backend:  ${RED}FALLIDO${NC}"
systemctl is-active omni-frontend && echo -e "  omni-frontend: ${GREEN}ACTIVO${NC}" || echo -e "  omni-frontend: ${RED}FALLIDO${NC}"
systemctl is-active nginx         && echo -e "  nginx:         ${GREEN}ACTIVO${NC}" || echo -e "  nginx:         ${RED}FALLIDO${NC}"

SERVER_IP=$(hostname -I | awk '{print $1}')
echo
echo -e "${GREEN}══════════════════════════════════════════${NC}"
echo -e "${GREEN}   ✅  OMNI-ISP INSTALADO EXITOSAMENTE   ${NC}"
echo -e "${GREEN}══════════════════════════════════════════${NC}"
echo -e "  🌐 Dashboard: ${BLUE}http://$SERVER_IP${NC}"
echo -e "  📋 Ver logs backend:  ${YELLOW}journalctl -u omni-backend -f${NC}"
echo -e "  📋 Ver logs frontend: ${YELLOW}journalctl -u omni-frontend -f${NC}"
echo
