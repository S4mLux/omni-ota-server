globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/l2OOZbNX68rvU785C7pd_/_buildManifest.js",
    "static/l2OOZbNX68rvU785C7pd_/_ssgManifest.js",
    "static/l2OOZbNX68rvU785C7pd_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0537w46l0w0j8.js",
    "static/chunks/1683bx2og-ppu.js",
    "static/chunks/0mstyq17cbf8-.js",
    "static/chunks/00nlt7x_9mi4z.js",
    "static/chunks/turbopack-0m1s681fysr94.js"
  ]
};
