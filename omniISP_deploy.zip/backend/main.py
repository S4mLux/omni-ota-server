import sys
import asyncio
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from fastapi import FastAPI, BackgroundTasks, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect

from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlmodel import Session, select, SQLModel, func
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager
import random
import asyncio
import os
from backend.models import Client, Router, Transaction, SupportTicket, SystemConfig, OLT, ONU, ONUSignalHistory, NotificationLog
from backend.mikrotik_driver import MikroTikDriver, RestApiWrapper
from backend.olt_driver import OLTDriver
from backend.ai_assistant import NeuralAssistant

from backend.database import engine, get_session, DATABASE_URL
from backend.client_api import router as client_router
from backend.admin_api import router as admin_router
from backend.admin_staff_api import router as admin_staff_router
from backend.billing_api import router as billing_router
from backend.sales_api import router as sales_router
from backend.installation_api import router as installation_router
from backend.auth_api import router as auth_router
from backend.hr_api import router as hr_router
from backend.root_api import router as root_router
from backend.search_api import router as search_router

from backend.scheduler import scheduler
from backend.state import ROUTERS_POOL, OLT_STATUS_CACHE
from backend.websocket import manager
from backend.notifications import NotificationDispatcher, EVENTS
from backend.suspension_engine import recover_pending_suspensions


# Tracking for OLT full sync timing
LAST_OLT_SYNC: Dict[int, float] = {}

async def olt_telemetry_loop():
    """Background task to update OLT status every 30 seconds for more responsive monitoring."""
    print("[OMNI] OLT Passive Telemetry loop STARTED")
    from datetime import datetime
    while True:
        try:
            # 1. Get OLTs list
            with Session(engine) as session:
                olts = session.exec(select(OLT)).all()
                # Snapshot OLT data to use outside session
                olt_snapshots = [o.model_copy() for o in olts]
            
            for o_snap in olt_snapshots:
                try:
                    # 1. Quick probe
                    is_online = await OLTDriver.probe_status(o_snap)
                    
                    if is_online:
                        # --- NUEVO: Auto-Sync de ONUs cada 60s (aprox) ---
                        now_ts = asyncio.get_event_loop().time()
                        last_sync = LAST_OLT_SYNC.get(o_snap.id, 0)
                        
                        if now_ts - last_sync > 60:
                            print(f"[AUTO-SYNC] Iniciando sincronización completa para OLT {o_snap.name}")
                            from backend.services.olt_service import sync_olt_onus_logic
                            # Create a new session for the sync task
                            with Session(engine) as sync_session:
                                await sync_olt_onus_logic(o_snap.id, sync=True, session=sync_session)
                            LAST_OLT_SYNC[o_snap.id] = now_ts

                        
                        # 2. Fetch basic ports info (Telemetry)
                        ports = await OLTDriver.get_port_states(o_snap)
                        
                        # 3. Fetch registered ONUs for this OLT
                        with Session(engine) as session:
                            registered_onus = session.exec(select(ONU).where(ONU.olt_id == o_snap.id)).all()
                            # Snapshot ONUs to process in parallel
                            onu_snapshots = [on.model_copy() for on in registered_onus]
                        
                        onus_summary = []
                        if onu_snapshots:
                            # 4. Fetch ONU details in parallel (semaphore=10, cada ONU tarda ~3-4s)
                            semaphore = asyncio.Semaphore(10)
                            
                            async def fetch_onu_details_safe(onu_snap):
                                async with semaphore:
                                    try:
                                        return onu_snap, await OLTDriver.get_onu_details(o_snap, onu_snap.pon_port, onu_snap.onu_index)
                                    except Exception as e:
                                        print(f"[TELEMETRY] Error fetching details for {onu_snap.serial_number}: {e}")
                                        return onu_snap, None

                            results = await asyncio.gather(*[fetch_onu_details_safe(on) for on in onu_snapshots])
                            
                            # 5. Process results and save to DB in a SINGLE TRANSACTION per OLT
                            with Session(engine) as session:
                                for onu_snap, details in results:
                                    if not details: continue
                                    
                                    # Fetch real object from session
                                    onu = session.get(ONU, onu_snap.id)
                                    if not onu: continue
                                    
                                    sig = details.get("signal_dbm")
                                    status_msg = details.get("status_msg", "Unknown")

                                    # Determinar estado: usar status_msg del OID de estado SNMP como fuente primaria.
                                    # Si SNMP falla por completo, preservar estado anterior.
                                    if status_msg == "Online":
                                        new_status = "ONLINE"
                                    elif status_msg == "Offline":
                                        new_status = "OFFLINE"
                                    elif sig is not None:
                                        new_status = "ONLINE" if sig > -35 else "OFFLINE"
                                    else:
                                        new_status = onu.status or "OFFLINE"

                                    now = datetime.utcnow()

                                    # ── Status: siempre actualizar ──
                                    if onu.status != new_status:
                                        cid = session.exec(select(Client.id).where(Client.onu_id == onu.id)).first() or 0
                                        evt = EVENTS["ONU_REGISTERED"] if new_status == "ONLINE" else EVENTS["ONU_DISCONNECTED"]
                                        msg_txt = f"🟢 ONU Reconectada: {onu.serial_number}" if new_status == "ONLINE" else f"🔴 ONU Desconectada: {onu.serial_number}"
                                        await NotificationDispatcher.dispatch(evt, msg_txt, session, client_id=cid)
                                    onu.status = new_status
                                    onu.last_seen = now

                                    # ── Señal y métricas: solo cuando SNMP respondió ──
                                    if sig is not None:
                                        # Delta check
                                        if onu.signal_dbm is not None and onu.signal_dbm_prev is not None:
                                            delta = abs(sig - onu.signal_dbm)
                                            if delta >= 2.5:
                                                cid = session.exec(select(Client.id).where(Client.onu_id == onu.id)).first() or 0
                                                await NotificationDispatcher.dispatch(
                                                    EVENTS["SIGNAL_ALTERED"],
                                                    f"⚠️ Variación de señal: ONU {onu.serial_number} ({onu.signal_dbm} -> {sig} dBm)",
                                                    session, client_id=cid
                                                )

                                        # Bandwidth
                                        rx_octs = details.get("rx_octets")
                                        tx_octs = details.get("tx_octets")
                                        if rx_octs and onu.last_rx_octets and onu.last_stats_time:
                                            dt = (now - onu.last_stats_time).total_seconds()
                                            if dt > 0:
                                                onu.bandwidth_rx = round(((rx_octs - onu.last_rx_octets) * 8) / (dt * 1000000), 2)
                                                onu.bandwidth_tx = round(((tx_octs - onu.last_tx_octets) * 8) / (dt * 1000000), 2)

                                        onu.last_rx_octets = rx_octs
                                        onu.last_tx_octets = tx_octs
                                        onu.last_stats_time = now

                                        if onu.signal_dbm_prev is None:
                                            onu.signal_dbm_prev = sig

                                        onu.signal_dbm = sig
                                        onu.tx_power = details.get("tx_power")
                                        onu.distance = details.get("distance") if details.get("distance") != "Unknown" else None

                                    session.add(onu)

                                    # Snapshot horario e historial de señal (solo si SNMP devolvió señal)
                                    if sig is not None:
                                        is_intensive = onu.intensive_monitoring_until and onu.intensive_monitoring_until > now

                                        last_h = session.exec(
                                            select(ONUSignalHistory)
                                            .where(ONUSignalHistory.onu_id == onu.id)
                                            .order_by(ONUSignalHistory.timestamp.desc())
                                            .limit(1)
                                        ).first()

                                        # Guardar si: es intensivo O pasó 1 hora
                                        if is_intensive or not last_h or (now - last_h.timestamp).total_seconds() >= 3600:
                                            session.add(ONUSignalHistory(
                                                onu_id=onu.id,
                                                signal_dbm=sig,
                                                bandwidth_rx=onu.bandwidth_rx,
                                                bandwidth_tx=onu.bandwidth_tx
                                            ))

                                        # Limpieza automática de datos > 24h
                                        from sqlalchemy import text
                                        session.execute(text("DELETE FROM onusignalhistory WHERE timestamp < datetime('now', '-24 hours')"))

                                        onus_summary.append({
                                            "id": onu.id, "serial_number": onu.serial_number, "signal_dbm": sig,
                                            "bandwidth_rx": onu.bandwidth_rx, "bandwidth_tx": onu.bandwidth_tx,
                                            "pon_port": onu.pon_port, "onu_index": onu.onu_index
                                        })

                                session.commit()

                        
                        # Update Cache
                        OLT_STATUS_CACHE[o_snap.id] = {
                            "data": {
                                "id": f"olt_{o_snap.id}", "name": o_snap.name, "ip": o_snap.ip_address,
                                "status": "ONLINE", "ports": ports, "onus_telemetry": onus_summary,
                                "cpu_load": random.randint(5, 15),
                                "bw_usage": round(random.uniform(10.0, 80.0), 1)
                            },
                            "timestamp": asyncio.get_event_loop().time()
                        }
                    else:
                        OLT_STATUS_CACHE[o_snap.id] = {
                            "data": {"id": f"olt_{o_snap.id}", "name": o_snap.name, "ip": o_snap.ip_address, "status": "OFFLINE", "ports": []},
                            "timestamp": asyncio.get_event_loop().time()
                        }
                        
                except Exception as inner_e:
                    print(f"[TELEMETRY LOOP] Error processing OLT {o_snap.id}: {inner_e}")
            
            await asyncio.sleep(30)
        except Exception as e:
            print(f"[TELEMETRY LOOP ERROR] OLT scanner failed: {e}")
            await asyncio.sleep(30)

async def pppoe_event_loop():
    """Monitorea conexiones/desconexiones PPPoE en tiempo real."""
    print("[OMNI] PPPoE Event monitoring loop STARTED")
    from backend.state import PPPOE_SESSIONS_CACHE
    while True:
        try:
            with Session(engine) as session:
                routers = session.exec(select(Router)).all()
                router_snapshots = [r.model_copy() for r in routers]

            for r in router_snapshots:
                api = await MikroTikDriver.get_api(r)
                if not api: continue
                
                try:
                    loop = asyncio.get_event_loop()
                    if isinstance(api, RestApiWrapper):
                        active = await loop.run_in_executor(None, lambda: api.get("/ppp/active") or [])
                    else:
                        active = await loop.run_in_executor(None, lambda: list(api.path("/ppp/active")))
                    
                    current_users = {str(s.get("name", "")).strip().lower() for s in active}
                    prev_users = PPPOE_SESSIONS_CACHE.get(r.id, set())
                    
                    # Detect New Connections
                    new_users = current_users - prev_users
                    for user in new_users:
                        with Session(engine) as session:
                            client = session.exec(select(Client).where(func.lower(Client.pppoe_user) == user)).first()
                            if client:
                                msg = f"🟢 Cliente Conectado: {client.full_name} ({user})"
                                await NotificationDispatcher.dispatch(EVENTS["PPPOE_CONNECTED"], msg, session, client_id=client.id)
                    
                    # Detect Disconnections
                    gone_users = prev_users - current_users
                    for user in gone_users:
                        with Session(engine) as session:
                            client = session.exec(select(Client).where(func.lower(Client.pppoe_user) == user)).first()
                            if client:
                                msg = f"🔴 Cliente Desconectado: {client.full_name} ({user})"
                                await NotificationDispatcher.dispatch(EVENTS["PPPOE_DISCONNECTED"], msg, session, client_id=client.id)
                    
                    # Update cache
                    PPPOE_SESSIONS_CACHE[r.id] = current_users
                except Exception as e:
                    print(f"[PPPOE PROBE ERROR] {r.name}: {e}")
                finally:
                    if hasattr(api, "close"): api.close()

            await asyncio.sleep(10) # Poll every 10 seconds
        except Exception as e:
            print(f"[PPPOE LOOP ERROR] {e}")
            await asyncio.sleep(10)

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)
    
    # Migración manual para columnas SNMP faltantes
    try:
        import sqlite3
        db_path = "omni_isp.db"
        if os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Verificar columnas existentes
            cursor.execute("PRAGMA table_info(olt)")
            columns = [row[1] for row in cursor.fetchall()]
            
            snmp_columns = [
                ("snmp_version", "TEXT DEFAULT 'v2c'"),
                ("snmp_username", "TEXT"),
                ("snmp_auth_protocol", "TEXT"),
                ("snmp_auth_password", "TEXT"),
                ("snmp_priv_protocol", "TEXT"),
                ("snmp_priv_password", "TEXT")
            ]
            
            for col_name, col_def in snmp_columns:
                if col_name not in columns:
                    try:
                        cursor.execute(f"ALTER TABLE olt ADD COLUMN {col_name} {col_def}")
                        print(f"[MIGRATE] Added column to OLT: {col_name}")
                    except Exception as e:
                        print(f"[MIGRATE] Error adding {col_name} to OLT: {e}")
                else:
                    print(f"[MIGRATE] Column {col_name} already exists")

            # Migración para la tabla ONU (Nuevas columnas de telemetría)
            cursor.execute("PRAGMA table_info(onu)")
            onu_columns = [row[1] for row in cursor.fetchall()]
            
            onu_telemetry_columns = [
                ("signal_dbm_prev", "FLOAT"),
                ("bandwidth_rx", "FLOAT DEFAULT 0.0"),
                ("bandwidth_tx", "FLOAT DEFAULT 0.0"),
                ("last_rx_octets", "BIGINT"),
                ("last_tx_octets", "BIGINT"),
                ("last_stats_time", "DATETIME")
            ]
            
            for col_name, col_def in onu_telemetry_columns:
                if col_name not in onu_columns:
                    try:
                        cursor.execute(f"ALTER TABLE onu ADD COLUMN {col_name} {col_def}")
                        print(f"[MIGRATE] Added column to ONU: {col_name}")
                    except Exception as e:
                        print(f"[MIGRATE] Error adding {col_name} to ONU: {e}")

            # Migración para la tabla ROUTER (Nuevas columnas SNMP)
            cursor.execute("PRAGMA table_info(router)")
            router_columns = [row[1] for row in cursor.fetchall()]
            
            router_snmp_columns = [
                ("snmp_community", "TEXT DEFAULT 'public'"),
                ("snmp_version", "TEXT DEFAULT 'v2c'"),
                ("snmp_port", "INTEGER DEFAULT 161")
            ]
            
            for col_name, col_def in router_snmp_columns:
                if col_name not in router_columns:
                    try:
                        cursor.execute(f"ALTER TABLE router ADD COLUMN {col_name} {col_def}")
                        print(f"[MIGRATE] Added column to ROUTER: {col_name}")
                    except Exception as e:
                        print(f"[MIGRATE] Error adding {col_name} to ROUTER: {e}")

            cursor.execute("PRAGMA table_info(olt)")
            olt_columns = [row[1] for row in cursor.fetchall()]
            if "auto_learn_enabled" not in olt_columns:
                try:
                    cursor.execute("ALTER TABLE olt ADD COLUMN auto_learn_enabled BOOLEAN DEFAULT 0")
                    print("[MIGRATE] Added auto_learn_enabled to olt")
                except Exception as e:
                    print(f"[MIGRATE] Error adding auto_learn_enabled to olt: {e}")
            
            # Migración para tabla invoice y transaction
            cursor.execute("PRAGMA table_info(invoice)")
            invoice_columns = [row[1] for row in cursor.fetchall()]
            if "is_shadow" not in invoice_columns:
                try:
                    cursor.execute("ALTER TABLE invoice ADD COLUMN is_shadow BOOLEAN DEFAULT 0")
                    print("[MIGRATE] Added is_shadow to invoice")
                except Exception as e:
                    print(f"[MIGRATE] Error adding is_shadow to invoice: {e}")
                    
            cursor.execute("PRAGMA table_info('transaction')")
            transaction_columns = [row[1] for row in cursor.fetchall()]
            if "is_shadow" not in transaction_columns:
                try:
                    cursor.execute("ALTER TABLE 'transaction' ADD COLUMN is_shadow BOOLEAN DEFAULT 0")
                    print("[MIGRATE] Added is_shadow to transaction")
                except Exception as e:
                    print(f"[MIGRATE] Error adding is_shadow to transaction: {e}")

            conn.commit()
            conn.close()
            print("[MIGRATE] Migration completed")
    except Exception as e:
        print(f"[MIGRATE] Migration failed: {e}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestiona el ciclo de vida de la aplicación (reemplaza el deprecated on_event)."""
    create_db_and_tables()
    with Session(engine) as session:
        defaults = [
            ("google_maps_api", "", "Google Maps JavaScript API Key"),
            ("bcv_auto_refresh_hours", "1", "Horas entre actualizaciones de tasa BCV"),
            ("overdue_days_cutoff", "5", "Días de mora antes del corte automático"),
            ("company_name", "Omni-ISP", "Nombre de la empresa"),
            ("company_rif", "", "RIF de la empresa"),
        ]
        for key, value, desc in defaults:
            existing = session.exec(select(SystemConfig).where(SystemConfig.key == key)).first()
            if not existing:
                session.add(SystemConfig(key=key, value=value, description=desc))
        session.commit()
    
    # Iniciar motor de automatización (Scheduler)
    await scheduler.start()

    # Iniciar loop de telemetría pasiva para hardware sensible (OLTs)
    asyncio.create_task(olt_telemetry_loop())

    # Iniciar loop de telemetría SNMP para routers (God-Mode MRTG)
    from backend.telemetry_service import poll_hardware_telemetry
    asyncio.create_task(poll_hardware_telemetry())

    # Iniciar monitoreo de eventos PPPoE
    asyncio.create_task(pppoe_event_loop())

    # ⚡ Recuperar suspensiones pendientes (Event-Driven Engine)
    # Reprograma facturas con cut_off_date futuro y ejecuta las ya vencidas
    await recover_pending_suspensions()

    print("[OMNI] Sistema iniciado correctamente")
    yield


app = FastAPI(title="Omni-Architect ISP API", version="2.0.4", lifespan=lifespan)

# Enable CORS for the Alien UI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow any origin in domestic/local ISP deployments
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def network_echo_middleware(request: Request, call_next):
    """Logs request origins with detailed info to solve external access issues."""
    client_ip = request.client.host if request.client else "unknown"
    
    # Simple color-coding prefix if supported, or just clear tags
    tag = "[EXTERNAL]" if client_ip != "127.0.0.1" else "[LOCAL]"
    
    print(f"{tag} Incoming request from {client_ip} -> {request.method} {request.url.path}")
    
    response = await call_next(request)
    return response

app.include_router(client_router)
app.include_router(admin_router)
app.include_router(admin_staff_router)
app.include_router(billing_router)
app.include_router(sales_router)
app.include_router(installation_router)
app.include_router(auth_router)
app.include_router(hr_router)
app.include_router(root_router)
app.include_router(search_router)


# Servir archivos de uploads (fotos de instalación, comprobantes, etc.)
os.makedirs("uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


@app.get("/health")
async def health_check():
    return {"status": "autonomous", "engine": "Omni-V2.0.4", "neural_shield": "ACTIVE"}

@app.websocket("/ws/notifications")
async def websocket_notifications(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection alive, we mostly broadcast TO the client
            data = await websocket.receive_text()
            # If client sends something, we could handle it here
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"[WS ERROR] {e}")
        manager.disconnect(websocket)

@app.post("/payments/webhook")
async def handle_payment(transaction: Transaction, background_tasks: BackgroundTasks, session: Session = Depends(get_session)):
    """Webhook for payment gateway. Triggers sub-2s reconnection."""
    session.add(transaction)
    session.commit()
    
    # Instant Reconnection for the client associated with this payment
    client = session.exec(select(Client).where(Client.id == transaction.client_id)).first()
    if client:
        router = session.get(Router, client.router_id)
        if router and client.auto_reconnect:
            background_tasks.add_task(
                MikroTikDriver.activate_client, 
                router, 
                client.ip_address, 
                client.prev_address_list or ""
            )
            
    return {"status": "PAYMENT_RECEIVED", "reconnection": "QUEUED"}


# --- AI NEURAL ASSISTANT ENDPOINTS ---

@app.get("/ai/diagnostic/{client_id}")
async def run_neural_diagnostic(client_id: int):
    """Triggers a real-time network scan for the client."""
    result = await NeuralAssistant.perform_neural_scan(client_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result

@app.post("/ai/ticket")
async def create_support_ticket(client_id: int, description: str, ai_refined: str):
    """Processes AI output and automates technical ticket creation."""
    ticket = await NeuralAssistant.create_refined_ticket(client_id, description, ai_refined)
    return {"ticket_id": ticket.id, "status": "REGISTERED", "priority": ticket.priority}

@app.get("/api/v2/telemetry/global")
async def get_global_telemetry(session: Session = Depends(get_session)):
    """Provides aggregated network metrics for the dashboard."""
    client_count = session.exec(select(func.count(Client.id))).one()
    
    # Generate simulated but deterministic-feeling stats
    return {
        "throughput_tbps": round(1.1 + random.uniform(0.05, 0.25), 2),
        "active_sessions": f"{client_count / 1000 + 98:.1f}k",
        "ddos_blocks_24h": random.randint(1200, 1600),
        "revenue_predict": f"${8.2 + random.uniform(-0.1, 0.1):.1f}M",
        "system_status": "AUTONOMOUS",
        "neural_shield": "ACTIVE"
    }

@app.get("/api/v2/telemetry/nodes")
async def get_nodes_telemetry(session: Session = Depends(get_session)):
    """Fetches real-time status and traffic for all registered nodes (Routers & OLTs)."""
    routers = session.exec(select(Router)).all()
    olts = session.exec(select(OLT)).all()
    
    async def probe_router(r):
        try:
            api = await MikroTikDriver.get_api(r)
            if api:
                loop = asyncio.get_event_loop()
                if isinstance(api, RestApiWrapper):
                    res_list = await loop.run_in_executor(None, lambda: api.get("/system/resource"))
                    resource = res_list[0] if res_list else {}
                else:
                    res_list = await loop.run_in_executor(None, lambda: list(api.path('/system/resource')))
                    resource = res_list[0] if res_list else {}
                if hasattr(api, 'close'):
                    api.close()
                return {
                    "id": f"router_{r.id}", "name": r.name, "ip": r.ip_address,
                    "status": "ONLINE", "type": "ROUTER", "role": r.role,
                    "cpu_load": int(resource.get('cpu-load', 0)),
                    "ram_total": int(resource.get('total-memory', 0)),
                    "ram_free": int(resource.get('free-memory', 0)),
                    "uptime": resource.get('uptime', 'N/A'),
                    "ros_version": resource.get('version', 'N/A'),
                    "board": resource.get('board-name', 'MikroTik'),
                    "bw_usage": round(random.uniform(5.0, 60.0), 1),
                    "api_port": r.api_port, "connection_mode": r.connection_mode
                }
            return {"id": f"router_{r.id}", "name": r.name, "ip": r.ip_address, "status": "OFFLINE", "type": "ROUTER", "api_port": r.api_port, "connection_mode": r.connection_mode}
        except Exception as e:
            print(f"[TELEMETRY ERROR] {r.name}: {e}")
            return {"id": f"router_{r.id}", "name": r.name, "ip": r.ip_address, "status": "ERROR", "type": "ROUTER", "api_port": r.api_port, "connection_mode": r.connection_mode}

    async def probe_olt(o):
        """Passive probe: only returns from cache to protect VSOL hardware."""
        cached = OLT_STATUS_CACHE.get(o.id)
        if cached:
            return cached["data"]
        
        # Default placeholder if not scanned yet
        return {
            "id": f"olt_{o.id}", "name": o.name, "ip": o.ip_address, 
            "status": "PENDING", "type": "OLT"
        }

    # Gather all node metrics in parallel
    results = await asyncio.gather(
        *(probe_router(r) for r in routers),
        *(probe_olt(o) for o in olts)
    )
    
    return {"nodes": results}
