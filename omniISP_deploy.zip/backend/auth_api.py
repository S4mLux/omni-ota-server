"""
Auth API — Autenticación JWT para Staff y Clientes del portal
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional
import hashlib
import hmac
import json
import base64
import os

from backend.models import Staff, Client, SystemConfig
from backend.database import get_session

router = APIRouter(prefix="/api/v2/auth", tags=["auth"])

SECRET_KEY = os.environ.get("OMNI_SECRET", "omni-isp-secret-key-2024-neural")
TOKEN_HOURS = 8


# ─── Token helpers (pure stdlib, no PyJWT dep requerido) ───────────────

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _decode_b64url(s: str) -> bytes:
    pad = 4 - len(s) % 4
    return base64.urlsafe_b64decode(s + "=" * (pad % 4))

def create_token(payload: dict) -> str:
    """Crea un JWT HS256 simple."""
    header  = _b64url(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    p       = {**payload, "exp": (datetime.utcnow() + timedelta(hours=TOKEN_HOURS)).timestamp()}
    body    = _b64url(json.dumps(p).encode())
    msg     = f"{header}.{body}".encode()
    sig     = _b64url(hmac.new(SECRET_KEY.encode(), msg, hashlib.sha256).digest())
    return f"{header}.{body}.{sig}"

def verify_token(token: str) -> Optional[dict]:
    """Verifica el JWT y retorna el payload o None."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header, body, sig = parts
        msg = f"{header}.{body}".encode()
        expected = _b64url(hmac.new(SECRET_KEY.encode(), msg, hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(_decode_b64url(body))
        if payload.get("exp", 0) < datetime.utcnow().timestamp():
            return None
        return payload
    except Exception:
        return None

def hash_pin(pin: str) -> str:
    return hashlib.sha256(f"{pin}{SECRET_KEY}".encode()).hexdigest()


# ─── Schemas ───────────────────────────────────────────────────────────

class StaffLoginRequest(BaseModel):
    dni: str
    pin: str           # 4-digit PIN o password libre

class ClientLoginRequest(BaseModel):
    dni: str
    password: str      # Cédula completa como password inicial, o personalizada

class LoginResponse(BaseModel):
    token: str
    type: str          # "STAFF" | "CLIENT"
    name: str
    role: str
    id: int


# ─── Endpoints ─────────────────────────────────────────────────────────

@router.post("/staff/login", response_model=LoginResponse)
async def staff_login(req: StaffLoginRequest, session: Session = Depends(get_session)):
    """Login de personal. Busca por DNI, valida PIN (hash o plain para retrocompatibilidad)."""
    staff = session.exec(select(Staff).where(Staff.dni == req.dni.strip())).first()
    if not staff:
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

    # Validar PIN — soporte para PIN en texto plano (legacy) y hash
    stored_pin = staff.pin or ""
    pin_valid = False

    if stored_pin == req.pin:
        pin_valid = True                          # Plain text (legacy / demo)
    elif stored_pin == hash_pin(req.pin):
        pin_valid = True                          # Hash
    elif not stored_pin and req.pin == staff.dni: # Fallback: cédula como PIN inicial
        pin_valid = True

    if not pin_valid:
        raise HTTPException(status_code=401, detail="PIN incorrecto")

    # Neural Lockdown Check
    lockdown = session.exec(select(SystemConfig).where(SystemConfig.key == "system_lockdown_active")).first()
    is_lockdown = lockdown and lockdown.value == "true"
    
    # Solo permitimos ROOT o quien tenga permisos "*" si el lockdown está activo
    is_root = staff.permissions == "*" or staff.position.upper() in ["ROOT", "SUPERADMIN", "DIRECTOR"]
    
    if is_lockdown and not is_root:
        raise HTTPException(status_code=423, detail="SISTEMA BLOQUEADO: Mantenimiento Neural en curso. Solo nivel ROOT tiene acceso.")

    token = create_token({
        "sub":  f"staff:{staff.id}",
        "id":   staff.id,
        "name": staff.full_name,
        "role": staff.position,
        "type": "STAFF",
        "dni":  staff.dni,
    })
    return LoginResponse(
        token=token, type="STAFF",
        name=staff.full_name, role=staff.position, id=staff.id
    )


@router.post("/client/login", response_model=LoginResponse)
async def client_login(req: ClientLoginRequest, session: Session = Depends(get_session)):
    """
    Login de cliente para la oficina virtual.
    Prioridad 1: portal_user / portal_password
    Prioridad 2 (retrocompatibilidad): dni / (dni o pppoe_pass)
    """
    # 1. Intentar por portal_user
    client = session.exec(select(Client).where(Client.portal_user == req.dni.strip())).first()
    
    # 2. Si no, intentar por dni (comportamiento original)
    if not client:
        client = session.exec(select(Client).where(Client.dni == req.dni.strip())).first()

    if not client:
        raise HTTPException(status_code=401, detail="Cliente no encontrado")

    # Validar password
    # 1. Si tiene portal_password, usarlo
    if client.portal_password:
        if req.password != client.portal_password:
            raise HTTPException(status_code=401, detail="Contraseña incorrecta")
    else:
        # 2. Fallback: cédula (default) o pppoe_pass
        valid = (req.password == client.dni) or (req.password == (client.pppoe_pass or ""))
        if not valid:
            raise HTTPException(status_code=401, detail="Contraseña incorrecta")

    token = create_token({
        "sub":    f"client:{client.id}",
        "id":     client.id,
        "name":   client.full_name,
        "role":   "CLIENT",
        "type":   "CLIENT",
        "dni":    client.dni,
        "status": client.status,
    })
    return LoginResponse(
        token=token, type="CLIENT",
        name=client.full_name, role="CLIENT", id=client.id
    )


@router.get("/me")
async def get_me(token: str, session: Session = Depends(get_session)):
    """Retorna el perfil del usuario autenticado dado su token."""
    payload = verify_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")

    if payload.get("type") == "STAFF":
        staff = session.get(Staff, payload["id"])
        if not staff:
            raise HTTPException(status_code=404, detail="Staff no encontrado")
        return {
            "id": staff.id, "name": staff.full_name,
            "role": staff.position, "type": "STAFF",
            "dni": staff.dni, "email": staff.email,
        }
    elif payload.get("type") == "CLIENT":
        client = session.get(Client, payload["id"])
        if not client:
            raise HTTPException(status_code=404, detail="Cliente no encontrado")
        return {
            "id": client.id, "name": client.full_name,
            "role": "CLIENT", "type": "CLIENT",
            "dni": client.dni, "status": client.status,
            "plan": client.plan_id,
        }
    raise HTTPException(status_code=400, detail="Tipo de usuario inválido")


@router.post("/logout")
async def logout():
    """El logout en JWT es client-side (eliminar el token). Este endpoint es para log/audit."""
    return {"status": "logged_out", "message": "Elimina el token del cliente."}


@router.get("/verify")
async def verify(token: str):
    """Verifica si un token es válido. Útil para middleware."""
    payload = verify_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")
    return {"valid": True, "payload": payload}

# ─── Neural Shield Signed Links ──────────────────────────────────────

def generate_download_signature(resource_id: str, client_id: int, expires_in_min: int = 15) -> dict:
    """Genera una firma temporal para un recurso específico."""
    expires = int((datetime.utcnow() + timedelta(minutes=expires_in_min)).timestamp())
    msg = f"{resource_id}:{client_id}:{expires}"
    sig = hmac.new(SECRET_KEY.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return {"sig": sig, "expires": expires}

def verify_download_signature(resource_id: str, client_id: int, sig: str, expires: int) -> bool:
    """Valida que la firma del recurso sea auténtica y no haya expirado."""
    if expires < datetime.utcnow().timestamp():
        return False
    msg = f"{resource_id}:{client_id}:{expires}"
    expected = hmac.new(SECRET_KEY.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig, expected)
